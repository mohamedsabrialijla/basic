<template>
    <div>
         <div class="row">
            <div class="col-12">
                <div class="portlet parcels latest-parcels">
                    <div class="portlet-head">
                        <div class="portlet-head-label">
                            <div class="portlet-head-icon">
                                <i class="icon icon-settings"></i>
                            </div>
                            <h3 class="portlet-head-title">
                                سيكشنات المطعم
                            </h3>
                        </div>

                        <div class="portlet-head-btn">
                            <a href="#" class="btn btn-primary btn-info" @click="getModal()">
                                <i class="icon icon-add icon-text"></i>
                                  اضافة سيكشن
                            </a>
                        </div>

                    </div>
                    <div class="portlet-body">
                        <form>
                            <div class="parcels-content mt-2">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="dtable">
                                            <table class="table d-table">
                                                <thead>
                                                    <th>#</th>
                                                    <th>اسم السيكشن </th>
                                                    <th>رقم السيكشن </th>
                                                    <th>عدد الطاولات </th>
                                                    <th>المساحة </th>
                                                    <th>الحالة </th>
                                                    <th>تاريخ الانشاء </th>
                                                    <th>الاجراءات</th>

                                                </thead>

                                                <tbody>
                                                    <tr v-for="item,index in items.data" :key="item.id">
                                                        <td>{{index+1}}</td>
                                                        <td>{{item.name_floor}}</td>
                                                        <td>{{item.number_floor}}</td>
                                                        <td>{{item.number_table}}</td>
                                                        <td>{{item.space}} متر</td>
                                                        <td>
                                                            <span v-if="item.status =='active'" class="badge badge-pill badge-success">
                                                                {{item.status}}
                                                            </span> 
                                                            <span v-else class="badge badge-pill badge-danger">
                                                                {{item.status}}
                                                            </span> 
                                                        </td>
                                                        <td>{{item.created_at}}</td>
                                                        
                                                        
                                                        <td>
                                                            <a href="#"
                                                                class="btn red-btn btn-icon"
                                                                @click="deleteFloors(item.id)"
                                                                title="" data-original-title="حذف">
                                                                <i class="icon icon-delete"></i>
                                                            </a>

                                                          
 
                                                            <span class="d-inline-block"
                                                                 data-original-title="تعديل">
                                                                <a href="#" class="btn green-btn btn-icon"
                                                                    @click="getModalEdit(item)">
                                                                    <i
                                                                        class="icon icon-pencil-edit-button"></i>
                                                                </a>
                                                            </span>


                                                             <span class="d-inline-block"
                                                                 title="طاولات السيكشن">
                                                                <a href="#" class="btn green-btn btn-icon" @click="getModalTable(item)">
                                                                    <i
                                                                        class="icon icon-product"></i>
                                                                </a>
                                                            </span>

                                                        </td>
                                                    </tr>

                                                    <tr v-if="totalPages == 0">
                                                        <td colspan="6" style="text-align:center">لا يوجد نتائج </td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>


                                            <sliding-pagination v-if="totalPages != 0"
                                              :current="currentPage"
                                              :total="totalPages"
                                              @page-change="pageChangeHandler"
                                            ></sliding-pagination>


                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>






<!-- modal add Floor -->
<div class="modal fade main-modal add-Floor" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-blg" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title d-flex">
                <i class="icon icon-add"></i>
                 {{titleModal}}</h5>
            <button type="button" class="close" @click="closeModal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
             <form  @submit="addEditFloors">
                <div class="row">
                    <div class="alert alert-danger" role="alert" v-if="errors.length">
                        <b style="font-weght">يرجي التاكد من البيانات  :</b>
                        <ul>
                          <li v-for="error in errors">{{ error }}</li>
                        </ul>
                    </div>
                    
                </div>

                <div class="tab-content mt-4" id="myTabContent">
                    <div class="tab-pane fade show active" id="storeInformation"
                        role="tabpanel" aria-labelledby="storeInformation-tab">
                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex">

                               <!--  <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      الفرع

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <select class="form-control select-tag "  v-model="formData.branch_id"  >
                                            <option v-for="branch in branches" v-bind:value="branch.id">{{branch.name}}</option>
                                           
                                        </select>
                                        

                                    </div>
                                </div> -->

                            <div class="form-group col-4">
                                <label for="personalPicture" class="col-12 flex-label" style="font-weight: bold;"> 
                                  صورة السيكشن
                                </label>
                                <div class="col-sm-9">
                                    <div class="avatar-picture">
                                        <div class="image-input image-input-outline"
                                            id="imgUserProfile">
                                            <div id="preview">
                                                <a :href="logo_preview" target="_blank">
                                                    <img v-if="logo_preview" :src="logo_preview" width="100" height="100" />
                                                    <img v-else :src="logo_preview_add" width="100" />
                                                </a>
                                            </div>

                                            <label class="btn" data-toggle="tooltip"
                                                data-placement="top" >

                                                <i class="icon icon-pencil-edit-button"></i>
                                                <input type="file" name="profile_avatar" v-on:change="onFileChange"
                                                    accept=".png, .jpg, .jpeg .pdf">
                                                <input type="button" value="Upload" id="uploadButton" />


                                            </label>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        

                              
                         

                                

                            </div>
                        </div>

                         <div class="row">
                            <div class="col-lg-12 col-12 d-flex">


                                   <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        اسم السيكشن
                                    </label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" 
                                             v-model="formData.name_floor" value=""
                                            placeholder="اسم السيكشن">
                                    </div>
                                </div>


                                
                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        رقم السيكشن
                                    </label>
                                    <div class="col-sm-12">
                                        <input type="number" class="form-control" 
                                             v-model="formData.number_floor" value=""
                                            placeholder="رقم السيكشن">
                                    </div>
                                </div>






                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        عدد الطاولات
                                    </label>
                                    <div class="col-sm-12">
                                        <input type="number" class="form-control"
                                             v-model="formData.number_table" value=""
                                            placeholder="عدد الطاولات">
                                    </div>
                                </div>
                             

                            

                              
                            </div>
                        </div> 




                         <div class="row">
                            <div class="col-lg-12 col-12 d-flex">

                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        مساحة السيكشن (متر)
                                    </label>
                                    <div class="col-sm-12">
                                        <input type="number" class="form-control"
                                            v-model="formData.space" value=""
                                            placeholder="مساحة السيكشن">
                                    </div>
                                </div> 


                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        الحجز الصباحي   (دقيقة)
                                    </label>
                                    <div class="col-sm-12">
                                        <input type="float" class="form-control"
                                            v-model="formData.morning" value=""
                                            placeholder="الحجز الصباحي ">
                                    </div>
                                </div> 



                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        الحجز المسائي  (دقيقة)
                                    </label>
                                    <div class="col-sm-12">
                                        <input type="float" class="form-control"
                                            v-model="formData.evening" value=""
                                            placeholder="الحجز المسائي">
                                    </div>
                                </div> 





                            


                            </div>
                        </div>  


                         <div class="row">
                            <div class="col-lg-12 col-12 d-flex">

                                <div class="form-group col-8">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        مميزات السيكشن
                                    </label>
                                    <div class="col-sm-12">
                                        <div class="col-sm-12 select-tag-wrapper" >
                                        <textarea class="form-control ckeditor"   rows="3"
                                             v-model="formData.features" id="messageContent"
                                            placeholder="مميزات السيكشن"></textarea>
                                        </div>
                                    </div>
                                </div>



                                <div class="product-switch flex-label" style="margin-top:30PX;">     
                                    <label for="activeDisStore">تفعيل</label>
                                </div>


                                <div class="form-group col-6" style="margin-top:30PX;">
                                    <div class="cst-switch">
                                        <input type="checkbox" id="activeDisStore" checked="checked" v-model="formData.status">
                                    </div>
                                </div>




                            </div>  
                        </div>  


                     
          

                        

                    </div>
                </div>

              
                <div class="btn-container">
                    <a class="btn btn-outline-light"  @click="closeModal">الغاء</a>
                    <button type="submit"
                        class="btn btn-primary">حفظ</button>
                </div>
            </form>
        </div>
    </div>
    </div>
</div>

<!-- modal add Table -->
<div class="modal fade main-modal time_work" id="myModalTable" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-blg" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title d-flex">
                <i class="icon icon-clock"></i>
                  طاولات السيكشن </h5>
            <button type="button" class="close" @click="closeModalTable" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <Tables :Item='ItemSelect' v-if="C_active==1"></Tables>
        </div>
    </div>
    </div>
</div>
<!-- end Table modal -->



        <!-- end modal -->
   </div>
</template>
 
 

<script>

    import SlidingPagination from 'vue-sliding-pagination'
    import Tables from './Tables'

       export default {
        components: { SlidingPagination,Tables},
       name : 'Floors',
       data(){
	       	return {
            C_active : 0,
            ItemSelect:{},
            titleModal:'',
            currentPage: 0,
            totalPages: 0,
            items:[],
            languages:[],
            errors: [],
            branches: [],
            ID:'',
            URL:'Floors/createItem',
	       	 
            formData:{
              name_floor:null,
              number_floor:null,
              number_table:null,
              space:null,
              features:null,
              morning:null,
              evening:null,
              status:'active',
	       	 	},
            logo:null,
            logo_preview:null,
            logo_preview_add :'./../assets/companies/img/store-logo.jpg',
		    }
       },
       methods:{
        pageChangeHandler(selectedPage) {
            this.currentPage = selectedPage
            this.getFloors()
        },

         onFileChange(e){
            this.logo = e.target.files[0];
            this.logo_preview = URL.createObjectURL(this.logo);
        },


 
       
        isNumber: function(evt) {
          evt = (evt) ? evt : window.event;
          var charCode = (evt.which) ? evt.which : evt.keyCode;
          if ((charCode > 31 && (charCode < 48 || charCode > 57)) && charCode !== 46) {
            evt.preventDefault();
          } else {
            return true;
          }
        },
 
        getModal(){
            this.resetFloors();
            $('#myModal').modal('show');
            this.titleModal = 'اضافة سيكشن '
        },


        getModalEdit(item){
            this.resetFloors();
            $('#myModal').modal('show');
            this.titleModal = 'تعديل  السيكشن'
            this.ID = item.id
            this.URL = 'Floors/editItem'
            this.getFloorById() 
            
        },

        closeModal(){
            $('#myModal').modal('hide');
            this.URL = 'Floors/createItem'
            this.ID = null
        },

        resetFloors(){
          this.URL = 'Floors/createItem'
          this.formData.name_floor=''
          this.formData.number_floor=''
          this.formData.number_table=''
          this.formData.space=''
          this.formData.status=''
          this.formData.features=''
          this.formData.logo=''
          this.morning=''
          this.evening=''
          this.logo_preview ='./../assets/companies/img/store-logo.jpg'


        },

 
       	addEditFloors(e){

            e.preventDefault();
             const config = {
                    headers: {
                        'content-type': 'multipart/form-data'
                    }
                }


              let form = new FormData();
            form.append('logo', this.logo);
            form.append('name_floor', this.formData.name_floor);
            form.append('number_floor', this.formData.number_floor);
            form.append('number_table', this.formData.number_table);
            form.append('space', this.formData.space);
            form.append('status', this.formData.status);
            form.append('features', this.formData.features);
            form.append('morning', this.formData.morning);
            form.append('evening', this.formData.evening);
            

             if(this.ID != ''){
               form.append('floorID', this.ID);
            }


       		axios.post(this.URL,form,config).then((response)=>{
                if(response.data.items){
                   swal({
                    text: "تم حفظ التغييرات بنجاح",
                    icon: "success",
                    timer: 2000,
                    button: false
                    }); 
                    this.closeModal()
                    this.getFloors()           

                }else{
                    swal({
                    text: response.data.message,
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }       			
       			
       		})
       	},


        getFloors(){
            axios.get('Floors/getAllItems?page='+ this.currentPage).then(response => {
                console.log(response.data)
                if(response.data){
                  let data = response.data.items
                  // console.log(data);
                  this.totalPages=Math.ceil(data.total/data.per_page)
                    this.items = data;
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });
        },


        getFloorById(){
            axios.get('Floors/getById', { params: { ID: this.ID } }).then(response => {
                if(response.data){
                  let data = response.data.items
                  let translations = response.data.items.translations
                   this.formData = data;
                   this.logo_preview = data.logo;

                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });
        },

        deleteFloor(id) {
            swal({
                  title: "Are you sure?",
                  text: "Once deleted, you will not be able to recover this imaginary item!",
                  icon: "warning",
                  buttons: true,
                  dangerMode: true,
                }).then((result) => {
              if (result) {
                axios.delete('Floors/deleteItem/'+id)
                    .then((response)=> {
                            if(response.data.code == 200){
                                swal(
                                  'Deleted!',
                                  'Item deleted successfully',
                                  'success'
                                )
                                this.getFloors()           

                            }else{
                                swal({
                                  icon: 'error',
                                  title: 'Oops...',
                                  text: 'Something went wrong!',
                                })

                            }
                           
                    

                    }).catch(() => {
                        swal({
                          icon: 'error',
                          title: 'Oops...',
                          text: 'Something went wrong!',
                        })
                    })
                }

            })
        },
        

        //here you are function table
           closeModalTable(){
            this.C_active =0
                $('#myModalTable').modal('hide');
            }, 
            getModalTable(item){
                this.C_active =1
                this.ItemSelect = item
                $('#myModalTable').modal('show');
            },



       },

       created(){

            this.languages = JSON.parse(localStorage.getItem("languages"))
            // this.$lang.setLocale('ar')
            // alert(this.$lang.getLocale())
            this.getFloors()

             axios.get('Branch/getAllItems', { params: { pagination: 0 } }).then(response => {
                if(response.data){
                  let data = response.data.items
                  this.branches = data;
                
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });
           
       },
       mounted(){

       }
    }


   
</script>
<style src="vue-sliding-pagination/dist/style/vue-sliding-pagination.css"></style>

<style>
    ol, p, ul {
        line-height: 1.0;
    }


    .c-sliding-pagination__list-element {
        
        padding: 0.5em !important;
        border-radius: 0.6em !important;
        margin: 1px 2px 1px 4px !important;
    }


</style>