<template>
    <div>
         <div class="row">
            <div class="col-12">
                <div class="portlet parcels latest-parcels">
                    <div class="portlet-head">
                        <div class="portlet-head-label">
                            <div class="portlet-head-icon">
                                <i class="icon icon-settings"></i>
                            </div>
                            <h3 class="portlet-head-title">
                                دمج الطاولات
                            </h3>
                        </div> 

                        <div class="portlet-head-btn">
                            <a href="#" class="btn btn-primary btn-info" @click="getModal()">
                                <i class="icon icon-add icon-text"></i>
                                دمج جديد
                            </a>
                        </div>

                    </div>
                    <div class="portlet-body">
                        <form>
                            <div class="parcels-content mt-2">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="dtable">
                                            <table class="table d-table">
                                                <thead>
                                                    <th>#</th>
                                                    <th>السيكشن </th>
                                                    <th>الحالة</th>
                                                    <th>التاريخ</th>
                                                   
                                                    <th>الاجراءات</th>

                                                </thead>

                                                <tbody>
                                                    <tr v-for="item,index in items.data" :key="item.id">
                                                        <td>{{index+1}}</td>
                                                        <td>{{item.floor.name_floor}}</td>
                                                      
                                                        <td>
                                                            <span v-if="item.status =='active'" class="badge badge-pill badge-success">
                                                                {{item.status}}
                                                            </span> 
                                                            <span v-else class="badge badge-pill badge-danger">
                                                                {{item.status}}
                                                            </span> 
                                                        </td>
                                                        <td>{{item.created_at}}</td>
                                                        
                                                        
                                                        <td>
                                                            <a href="#"
                                                                class="btn red-btn btn-icon"
                                                                @click="deleteMerge(item.id)"
                                                                title="" data-original-title="حذف">
                                                                <i class="icon icon-delete"></i>
                                                            </a>

                                                          
 
                                                           <!--  <span class="d-inline-block"
                                                                 data-original-title="تعديل">
                                                                <a href="#" class="btn green-btn btn-icon"
                                                                    @click="getModalEdit(item)">
                                                                    <i
                                                                        class="icon icon-pencil-edit-button"></i>
                                                                </a>
                                                            </span> -->


                                                             <!-- <span class="d-inline-block"
                                                                 title="طاولات السيكشن">
                                                                <a href="#" class="btn green-btn btn-icon" @click="getModalTable(item)">
                                                                    <i
                                                                        class="icon icon-product"></i>
                                                                </a>
                                                            </span> -->

                                                        </td>
                                                    </tr>

                                                    <tr v-if="totalPages == 0">
                                                        <td colspan="6" style="text-align:center">لا يوجد نتائج </td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>


                                            <sliding-pagination v-if="totalPages != 0"
                                              :current="currentPage"
                                              :total="totalPages"
                                              @page-change="pageChangeHandler"
                                            ></sliding-pagination>


                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>






<!-- modal add Floor -->
<div class="modal fade main-modal add-Merge" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-blg" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title d-flex">
                <i class="icon icon-add"></i>
                 {{titleModal}}</h5>
            <button type="button" class="close" @click="closeModal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
             <form  @submit="addEditMerge">
                <div class="row">
                    <div class="alert alert-danger" role="alert" v-if="errors.length">
                        <b style="font-weght">يرجي التاكد من البيانات  :</b>
                        <ul>
                          <li v-for="error in errors">{{ error }}</li>
                        </ul>
                    </div>
                    
                </div>

                <div class="tab-content mt-4" id="myTabContent">
                    <div class="tab-pane fade show active" id="storeInformation"
                        role="tabpanel" aria-labelledby="storeInformation-tab">
                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex">

                                
                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                         السيكشن
                                    </label>
                                    <div class="col-sm-12">
                                        <select class="form-control select-tag "  v-model="formData.floor_id"   @change="getTableByIdFromSelectFloor($event)">
                                            <option v-for="floor in floors" v-bind:value="floor.id"> رقم الطابق  / اسم({{floor.number_floor}}/{{floor.name_floor}})</option>
                                           
                                        </select>
                                    </div>
                                </div>


                              <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      حدد  الطاولات للدمج 
                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <multiselect class="" v-model="formData.tables" tag-placeholder="اختيار " placeholder="ابحث من هنا .." label="name_table" track-by="id" :options="tables" :multiple="true" :taggable="true" ></multiselect>

                                    </div>
                            </div>


                              
                         

                                

                            </div>
                        </div>

                    

                        


                   
          

                        

                    </div>
                </div>

              
                <div class="btn-container">
                    <a class="btn btn-outline-light"  @click="closeModal">الغاء</a>
                    <button type="submit"
                        class="btn btn-primary">حفظ</button>
                </div>
            </form>
        </div>
    </div>
    </div>
</div>



        <!-- end modal -->
   </div>
</template>
 
 

<script>

    import Multiselect from 'vue-multiselect'
    import SlidingPagination from 'vue-sliding-pagination'
    import Tables from './Tables'

       export default {
        components: {Multiselect, SlidingPagination,Tables},
       name : 'Merge',
       data(){
            return {
            C_active : 0,
             tables: [],
            ItemSelect:{},
            titleModal:'دمج الطاولات',
            currentPage: 0,
            totalPages: 0,
            items:[],
            floors:[],
            languages:[],
            errors: [],
            branches: [],
            ID:'',
            URL:'MergeTabel/createItem',
             
            formData:{
              // name_table:null,
              floor_id:null,
               tables: [],
              // number_table:null,
              // personal_number:null,
              // min_personal:null,
              // max_personal:null,
              // status:'active',
                },
            }
       },
       methods:{
        pageChangeHandler(selectedPage) {
            this.currentPage = selectedPage
            this.getMerge()
        },

         onFileChange(e){
            this.logo = e.target.files[0];
            this.logo_preview = URL.createObjectURL(this.logo);
        },

         closeModalTable(){
            this.C_active =0
                $('#myModalTable').modal('hide');
            }, 
            getModalTable(item){
                this.C_active =1
                this.ItemSelect = item
                $('#myModalTable').modal('show');
            },
  
       
        isNumber: function(evt) {
          evt = (evt) ? evt : window.event;
          var charCode = (evt.which) ? evt.which : evt.keyCode;
          if ((charCode > 31 && (charCode < 48 || charCode > 57)) && charCode !== 46) {
            evt.preventDefault();
          } else {
            return true;
          }
        },
 
        getModal(){
            this.resetMerge();
            $('#myModal').modal('show');
            this.titleModal = 'اضافة سيكشن '
        },


        tableLabel(option) {
          return `${option.name_table} - ${option.number_table}`;
        },


        getModalEdit(item){
            this.resetMerge();
            $('#myModal').modal('show');
            this.titleModal = 'تعديل  السيكشن'
            this.ID = item.id
            this.URL = 'MergeTabel/editItem'
            this.getMergeById() 
            
        },

        closeModal(){
            $('#myModal').modal('hide');
            this.URL = 'MergeTabel/createItem'
            this.ID = null
        },

        resetMerge(){
          this.URL = 'MergeTabel/createItem'
          // this.formData.name_table=''
          this.formData.floor_id=''
          // this.formData.number_table=''
          // this.formData.personal_number=''
          // this.formData.min_personal=''
          // this.formData.max_personal=''
          this.formData.tables=[]
          // this.formData.status=''
      


        },

 
        addEditMerge(e){

            e.preventDefault();
             const config = {
                    headers: {
                        'content-type': 'multipart/form-data'
                    }
                }


            let form = new FormData();
            // form.append('name_table', this.formData.name_table);
            form.append('floor_id', this.formData.floor_id);
            // form.append('number_table', this.formData.number_table);
            // form.append('personal_number', this.formData.personal_number);
            // form.append('status', this.formData.status);
            // form.append('min_personal', this.formData.min_personal);
            // form.append('max_personal', this.formData.max_personal);
            form.append('tables', JSON.stringify(this.formData.tables));
            

             if(this.ID != ''){
               form.append('MergeID', this.ID);
            }
 

            axios.post(this.URL,form,config).then((response)=>{
                if(response.data.items){
                   swal({
                    text: "تم حفظ التغييرات بنجاح",
                    icon: "success",
                    timer: 2000,
                    button: false
                    }); 
                    this.closeModal()
                    this.getMerge()           

                }else{
                    swal({
                    text: response.data.message,
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }                   
                
            })
        },


        getMerge(){
            axios.get('MergeTabel/getAllItems?page='+ this.currentPage).then(response => {
                if(response.data){
                     console.log(response)
                  let data = response.data.items
                  this.totalPages=Math.ceil(data.total/data.per_page)
                    this.items = data;
                   
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });
        },


        getMergeById(){
            axios.get('MergeTabel/getById', { params: { ID: this.ID } }).then(response => {
                if(response.data){
                  let data = response.data.items
                  let translations = response.data.items.translations
                   this.formData = data;
                   this.logo_preview = data.logo;

                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });
        },

        deleteMerge(id) {
            swal({
                  title: "Are you sure?",
                  text: "Once deleted, you will not be able to recover this imaginary item!",
                  icon: "warning",
                  buttons: true,
                  dangerMode: true,
                }).then((result) => {
              if (result) {
                axios.delete('MergeTabel/deleteItem/'+id)
                    .then((response)=> {
                            if(response.data.code == 200){
                                swal(
                                  'Deleted!',
                                  'Item deleted successfully',
                                  'success'
                                )
                                this.getMerge()           

                            }else{
                                swal({
                                  icon: 'error',
                                  title: 'Oops...',
                                  text: 'Something went wrong!',
                                })

                            }
                           
                    

                    }).catch(() => {
                        swal({
                          icon: 'error',
                          title: 'Oops...',
                          text: 'Something went wrong!',
                        })
                    })
                }

            })
        }, 

        getTableByIdFromSelectFloor(){
            axios.get('Table/getAllByFloorID?floor_id='+ this.formData.floor_id).then(response => {
                if(response.data){
                  let data = response.data.items
                this.tables = data;
                // console.log(this.tables)
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });
        },       


       },

       created(){

            this.languages = JSON.parse(localStorage.getItem("languages"))
            // this.$lang.setLocale('ar')
            // alert(this.$lang.getLocale())
            this.getMerge()

            axios.get('Floors/getAllItems', { params: { pagination: 0 } }).then(response => {
                if(response.data){
                  let data = response.data.items
                  this.floors = data
                
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });
 









           
       },
       mounted(){

       }
    }


   
</script>
<style src="vue-sliding-pagination/dist/style/vue-sliding-pagination.css"></style>
<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>
<style>

.multiselect__option--highlight {
    background: #3ebdb1 !important;
    outline: none;
    color: #fff;}

    .multiselect__tag {
    background: #3ebdb1;}

    .multiselect__tag-icon:after {
    color: ##33a196;
    }




    ol, p, ul {
        line-height: 1.0;
    }


    .c-sliding-pagination__list-element {
        
        padding: 0.5em !important;
        border-radius: 0.6em !important;
        margin: 1px 2px 1px 4px !important;
    }


</style>