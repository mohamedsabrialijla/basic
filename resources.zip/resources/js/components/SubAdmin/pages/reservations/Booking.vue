<template>
    <div>
         <div class="row">
            <div class="col-12">
                <div class="portlet parcels latest-parcels">
                    <div class="portlet-head">
                        <div class="portlet-head-label">
                            <div class="portlet-head-icon">
                                <i class="icon icon-settings"></i>
                            </div>
                            <h3 class="portlet-head-title">
                                الحجوزات
                            </h3>
                        </div>

                        <div class="portlet-head-btn">
                            <!-- <a href="#" class="btn btn-primary btn-info" @click="getModal()" v-if="products.length != 0 ">
                                <i class="icon icon-add icon-text"></i>
                                  اضافة حجز
                            </a> -->

                            <a href="#" class="btn btn-primary btn-info" @click="getModal()" >
                                <i class="icon icon-add icon-text"></i>
                                  اضافة حجز
                            </a>

                           

                        </div>

                    </div>
                    <div class="portlet-body">
                        <form>
                            <div class="parcels-content mt-2">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="dtable">
                                            <table class="table d-table">
                                                <thead>
                                                    <th>#</th>
                                                    <th>الاسم</th>
                                                    <th>الجوال</th>
                                                    <th>اسم/رقم الطابق</th>
                                                    <th>رقم الطاولة </th>
                                                    <th>الحالة </th>
                                                    <th>حالة الدفع</th>
                                                    <th>تاريخ الانشاء </th>
                                                    <th>الاجراءات</th>

                                                </thead>

                                                <tbody>
                                                    <tr v-for="item,index in items.data" :key="item.id" v-if="items.data">
                                                        <td>{{index+1}}</td>
                                                        <td>{{item.name}}</td>
                                                        <td>{{item.mobile}}</td>
                                                        <td>{{item.floor.name_floor}}/{{item.floor.number_floor}} </td>
                                                        <td>{{item.table.number_table}} </td>
                                                        <td v-if="item.order && item.order.status">
                                                            <span v-if="item.order.status ==1" class="badge badge-pill badge-info">
                                                                {{item.order.status_text}}
                                                            </span> 
                                                            <span v-else-if="item.order.status ==3" class="badge badge-pill badge-danger">
                                                                {{item.order.status_text}}
                                                            </span>

                                                            <span v-else-if="item.order.status ==6 || item.status ==5" class="badge badge-pill badge-success">
                                                                {{item.order.status_text}}
                                                            </span>

                                                            <span v-else-if="item.order.status ==2 || item.status ==4" class="badge badge-pill badge-warning">
                                                                {{item.order.status_text}}
                                                            </span>

                                                        </td> 

                                                        <td v-else>
                                                            <span v-if="item.status ==1" class="badge badge-pill badge-info">
                                                                {{item.status_text}}
                                                            </span> 
                                                            <span v-else-if="item.status ==3" class="badge badge-pill badge-danger">
                                                                {{item.status_text}}
                                                            </span>

                                                            <span v-else-if="item.status ==6 || item.status ==5" class="badge badge-pill badge-success">
                                                                {{item.status_text}}
                                                            </span>

                                                            <span v-else-if="item.status ==2 || item.status ==4" class="badge badge-pill badge-warning">
                                                                {{item.status_text}}
                                                            </span>

                                                        </td>


                                                        <td v-if="item && item.order && item.order.status && item.order.paid ">
                                                            <span v-if="item.order.paid ==1" class="badge badge-pill badge-success">
                                                                {{item.order.paid_text}}
                                                            </span>

                                                            <span v-else-if="item.order.paid ==0 " class="badge badge-pill badge-warning">
                                                                {{item.order.paid_text}}
                                                            </span>

                                                        </td>

                                                        <td v-else>
                                                            غير مدفوع
                                                        </td>



                                                        <td>{{item.created_at}}</td>
                                                        
                                                        
                                                        <td v-if="item && item.order && item.order.paid == 1 ">
                                                            

                                                          
 
                                                            <span class="d-inline-block"
                                                                 data-original-title="تعديل">
                                                                <a href="#" class="btn green-btn btn-icon"
                                                                    @click="getModalEdit(item)">
                                                                    <i
                                                                        class="icon icon-pencil-edit-button"></i>
                                                                </a> 
                                                            </span>


                                                            

                                                          



                                                            <a href="#" class="btn btn-primary btn-info" @click="getModalPrint(item.id)">
                                                                <i class="icon icon icon-text"></i>
                                                              طباعة الفاتورة
                                                            </a> 

                                                            <img :src="getImageUrl('generated_qr_code.png')" alt="Image" id="qr_code"  width="2px"  />
                                                                 


                                                        </td>

                                                        <td v-if="item && !item.order || item && item.order && item.order.paid != 1 ">
                                                            
                                                            <a href="#"
                                                                class="btn red-btn btn-icon"
                                                                @click="deleteBooking(item.id)"
                                                                title="" data-original-title="حذف">
                                                                <i class="icon icon-delete"></i>
                                                            </a>

                                                          
 
                                                            <span class="d-inline-block"
                                                                 data-original-title="تعديل">
                                                                <a href="#" class="btn green-btn btn-icon"
                                                                    @click="getModalEdit(item)">
                                                                    <i
                                                                        class="icon icon-pencil-edit-button"></i>
                                                                </a> 
                                                            </span>


                                                            

                                                            <router-link  class="btn green-btn btn-icon" 
                                                                 :to="{name:'Basket', params: { booking_id: item.id} }">
                                                                 <i class="icon icon-basket"></i></router-link>



                                                        </td>



                                                    </tr>

                                                    <tr v-if="totalPages == 0">
                                                        <td colspan="6" style="text-align:center">لا يوجد نتائج </td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>


                                            <sliding-pagination v-if="totalPages != 0"
                                              :current="currentPage"
                                              :total="totalPages"
                                              @page-change="pageChangeHandler"
                                            ></sliding-pagination>


                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>






<!-- modal add Booking -->
<div class="modal fade main-modal add-Booking" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-blg" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title d-flex">
                <i class="icon icon-add"></i>
                 {{titleModal}}</h5>
            <button type="button" class="close" @click="closeModal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
             <form  @submit="addEditBooking">
                <div class="row">
                    <div class="alert alert-danger" role="alert" v-if="errors.length">
                        <b style="font-weght">يرجي التاكد من البيانات  :</b>
                        <ul>
                          <li v-for="error in errors">{{ error }}</li>
                        </ul>
                    </div>
                    
                </div>

                <div class="tab-content mt-4" id="myTabContent">
                    <div class="tab-pane fade show active" id="storeInformation"
                        role="tabpanel" aria-labelledby="storeInformation-tab">



                           <div class="row">
                            <div class="col-lg-12 col-12 d-flex">

                              <!--   <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      الفرع

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <select class="form-control select-tag "  v-model="formData.branch_id"  @change="getFloorByIdFromSelectBranch()">
                                            <option v-for="branch in branches" v-bind:value="branch.id">{{branch.name}}</option>
                                           
                                        </select>
                                        

                                    </div>
                                </div> -->


                                
                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                         السيكشن
                                    </label>
                                    <div class="col-sm-12">
                                        <select class="form-control select-tag "  v-model="formData.floor_id"   @change="getTableByIdFromSelectFloor($event)">
                                            <option v-for="floor in floors" v-bind:value="floor.id"> رقم الطابق  / اسم({{floor.number_floor}}/{{floor.name_floor}})</option>
                                           
                                        </select>
                                    </div>
                                </div>


                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      عدد الاشخاص

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <input type="text" class="form-control"
                                            v-model="formData.number_persons" value=""
                                            placeholder="عدد الاشخاص">
                                    </div>
                                </div>

                                 <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        تاريخ الحجز
                                    </label>
                                    <div class="col-sm-12">
                                       <input type="date" class="form-control datepicker" id="startData" v-model="formData.date"
                                        placeholder="تاريخ" 
                                        data-toggle="datepicker"
                                        >
                                    <span class="calendar">
                                        <i class="fa fa-calendar" aria-hidden="true"></i>
                                    </span>
                                    </div>
                                </div> 
                             
                            </div>
                        </div>





                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex">


                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      وقت الحجز

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <input type="time" v-model="formData.time" class="form-control" >
                                    </div>
                                </div>   



                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        الطاولة
                                    </label>
                                    <div class="col-sm-12">
                                        <select class="form-control select-tag "  v-model="formData.table_id"  >
                                            <option v-for="tabel in tables" v-bind:value="tabel.id">رقم الطاولة ({{tabel.number_table}}) / تسع ل ({{tabel.persons_number}}) أشخاص</option>
                                           
                                        </select>
                                    </div>
                                </div>





                           


                               



                             
                            </div>
                        </div>


                     
                         <div class="row">
                            <div class="col-lg-12 col-12 d-flex">


                                     <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      اسم صاحب الحجز

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <input type="text" class="form-control"
                                            v-model="formData.name" value=""
                                            placeholder="اسم صاحب الحجز ">
                                    </div>
                                </div>


                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      رقم جوال صاحب الحجز

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <input type="text" class="form-control"
                                            v-model="formData.mobile" value=""
                                            placeholder="رقم جوال صاحب الحجز ">
                                    </div>
                                </div>


                                  <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        الجنس
                                    </label>
                                    <div class="col-sm-12">
                                       <select class="form-control select-tag "  v-model="formData.gender"  >
                                            <option value="Ms">Ms</option>
                                            <option value="Mrs">Mrs</option>
                                           
                                        </select>
                                    </div>
                                </div> 



                               
                            </div>
                            </div>



                             <div class="row">
                            <div class="col-lg-12 col-12 d-flex">

                                 <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      العنوان

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <input type="text" class="form-control"
                                            v-model="formData.address" value=""
                                            placeholder="العنوان بالتفصيل ">
                                    </div>
                                </div>



                              

                                 <div class="form-group col-4" v-if="ID!=''">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        الحالة
                                    </label>
                                    <div class="col-sm-12">
                                       <select class="form-control select-tag "  v-model="formData.status"  >
                                            <option value="1">جديد</option>
                                            <option value="2">مقبول</option>
                                            <option value="3">مرفوض</option>
                                            <option value="4">جاري التجهيز</option>
                                            <option value="5">مجهز</option>
                                            <option value="6">تم التسليم</option>
                                        
                                            
                                           
                                        </select>
                                    </div>
                                </div> 


                                 




                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        ملاحظات
                                    </label>
                                    <div class="col-sm-12">
                                        <div class="col-sm-12 select-tag-wrapper" >
                                        <textarea class="form-control" rows="3"
                                             v-model="formData.note" id="messageContent"
                                            placeholder="ملاحظات "></textarea>
                                        </div>
                                    </div>
                                </div>

                              
                            </div>
                        </div> 
          

                        

                    </div>
                </div>

              
                <div class="btn-container">
                    <a class="btn btn-outline-light"  @click="closeModal">الغاء</a>
                    <button type="submit"
                        class="btn btn-primary">حفظ</button>
                </div>
            </form>
        </div>
    </div>
    </div>
</div>

<!-- end modal -->





<!-- modal add Booking -->
<div class="modal fade main-modal add-Booking" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-blg" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title d-flex">
                <i class="icon icon-add"></i>
                 {{titleModal}}</h5>
            <button type="button" class="close" @click="closeModal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
             <form  @submit="addEditBooking">
                <div class="row">
                    <div class="alert alert-danger" role="alert" v-if="errors.length">
                        <b style="font-weght">يرجي التاكد من البيانات  :</b>
                        <ul>
                          <li v-for="error in errors">{{ error }}</li>
                        </ul>
                    </div>
                    
                </div>

                <div class="tab-content mt-4" id="myTabContent">
                    <div class="tab-pane fade show active" id="storeInformation"
                        role="tabpanel" aria-labelledby="storeInformation-tab">

                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex">

                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      اسم صاحب الحجز

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <input type="text" class="form-control"
                                            v-model="formData.name" value=""
                                            placeholder="اسم صاحب الحجز ">
                                    </div>
                                </div>


                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      رقم جوال صاحب الحجز

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <input type="text" class="form-control"
                                            v-model="formData.mobile" value=""
                                            placeholder="رقم جوال صاحب الحجز ">
                                    </div>
                                </div>




                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      العنوان

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <input type="text" class="form-control"
                                            v-model="formData.address" value=""
                                            placeholder="العنوان بالتفصيل ">
                                    </div>
                                </div>




                             
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex">

                              <!--   <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      الفرع

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <select class="form-control select-tag "  v-model="formData.branch_id"  @change="getFloorByIdFromSelectBranch()">
                                            <option v-for="branch in branches" v-bind:value="branch.id">{{branch.name}}</option>
                                           
                                        </select>
                                        

                                    </div>
                                </div> -->


                                
                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                         الطابق
                                    </label>
                                    <div class="col-sm-12">
                                        <select class="form-control select-tag "  v-model="formData.floor_id"   @change="getTableByIdFromSelectFloor($event)">
                                            <option v-for="floor in floors" v-bind:value="floor.id"> رقم الطابق  / اسم({{floor.number_floor}}/{{floor.name_floor}})</option>
                                           
                                        </select>
                                    </div>
                                </div>


                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        الطاولة
                                    </label>
                                    <div class="col-sm-12">
                                        <select class="form-control select-tag "  v-model="formData.table_id"  >
                                            <option v-for="tabel in tables" v-bind:value="tabel.id">رقم الطاولة ({{tabel.number_table}}) / تسع ل ({{tabel.persons_number}}) أشخاص</option>
                                           
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      عدد الاشخاص

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <input type="text" class="form-control"
                                            v-model="formData.number_persons" value=""
                                            placeholder="عدد الاشخاص">
                                    </div>
                                </div>
                             
                            </div>
                        </div>

                         <div class="row">
                            <div class="col-lg-12 col-12 d-flex">

                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        الجنس
                                    </label>
                                    <div class="col-sm-12">
                                       <select class="form-control select-tag "  v-model="formData.gender"  >
                                            <option value="Ms">Ms</option>
                                            <option value="Mrs">Mrs</option>
                                           
                                        </select>
                                    </div>
                                </div> 

                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        تاريخ الحجز
                                    </label>
                                    <div class="col-sm-12">
                                       <input type="date" class="form-control datepicker" id="startData" v-model="formData.date"
                                        placeholder="تاريخ" 
                                        data-toggle="datepicker"
                                        >
                                    <span class="calendar">
                                        <i class="fa fa-calendar" aria-hidden="true"></i>
                                    </span>
                                    </div>
                                </div> 

                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      وقت الحجز

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <input type="time" v-model="formData.time" class="form-control" >
                                    </div>
                                </div>   
                            </div>
                            </div>



                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex">


                                 <div class="form-group col-4" v-if="ID!=''">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        الحالة
                                    </label>
                                    <div class="col-sm-12">
                                       <select class="form-control select-tag "  v-model="formData.status"  >
                                            <option value="1">جديد</option>
                                            <option value="2">مقبول</option>
                                            <option value="3">مرفوض</option>
                                            <option value="4">جاري التجهيز</option>
                                            <option value="5">مجهز</option>
                                            <option value="6">تم التسليم</option>
                                        
                                            
                                           
                                        </select>
                                    </div>
                                </div> 
 

                                 




                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        ملاحظات
                                    </label>
                                    <div class="col-sm-12">
                                        <div class="col-sm-12 select-tag-wrapper" >
                                        <textarea class="form-control" rows="3"
                                             v-model="formData.note" id="messageContent"
                                            placeholder="ملاحظات "></textarea>
                                        </div>
                                    </div>
                                </div>

                              
                            </div>
                        </div> 
          

                        

                    </div>
                </div>

              
                <div class="btn-container">
                    <a class="btn btn-outline-light"  @click="closeModal">الغاء</a>
                    <button type="submit"
                        class="btn btn-primary">حفظ</button>
                </div>
            </form>
        </div>
    </div>
    </div>
</div>

<!-- end modal -->






<!-- modal Print -->
<div class="modal fade main-modal myModalPrint" id="myModalPrint" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="width:350px;">
    <div class="modal-dialog modal-dialog-centered modal-blg" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title d-flex">
                <i class="icon icon-basket"></i>
                 فاتورة ضريبية</h5>
                 
            <button type="button" class="close" @click="closeModalPrint" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div> 
        <div class="modal-body">
             <form  >
                <div class="row">
                    <div class="alert alert-danger" role="alert" v-if="errors.length">
                        <b style="font-weght">يرجي التاكد من البيانات  :</b>
                        <ul>
                          <li v-for="error in errors">{{ error }}</li>
                        </ul>
                    </div>
                    
                </div>

               

               
                <canvas id="canvas" width="" height="1000" ></canvas> 
                 <br>

              
           
            </form>
        </div>
    </div>
    </div>
</div>

<!-- end modal Print -->


   </div>
</template>
 
 

<script>

    import SlidingPagination from 'vue-sliding-pagination'

       export default {
        components: { SlidingPagination},
       name : 'Booking',
       data(){
	       	return {
            qr_code:null,
            // paid:null,
            ItemPrint:null,
            C_active : 0,
            ItemSelect:{},
            titleModal:'',
            currentPage: 0,
            totalPages: 0,
            items:[],
            languages:[],
            errors: [],
            branches: [],
            floors: [],
            tables: [],
            products:[],
            ID:'',
            URL:'Booking/createItem',
	       	 
            formData:{
              // branch_id:null,
              name:null,
              mobile:null,
              note:null,
              gender:null,
              floor_id:null,
              table_id:null,
              address:null,
              date:null,
              time:null,
              number_persons:null,
	       	 	},
		    }
       },
       methods:{
        pageChangeHandler(selectedPage) {
            this.currentPage = selectedPage
            this.getBooking()
        },
       
        isNumber: function(evt) {
          evt = (evt) ? evt : window.event;
          var charCode = (evt.which) ? evt.which : evt.keyCode;
          if ((charCode > 31 && (charCode < 48 || charCode > 57)) && charCode !== 46) {
            evt.preventDefault();
          } else {
            return true;
          }
        },

        getModal(){
            this.resetBooking();
            $('#myModal').modal('show');
            this.titleModal = 'اضافة حجز جديد'
        },


        getModalEdit(item){
            this.resetBooking();
            $('#myModal').modal('show');
            this.titleModal = 'تعديل  الحجز'
            this.ID = item.id
            this.URL = 'Booking/editItem'
            this.getBookingById() 
            
        },
        closeModal(){
            $('#myModal').modal('hide');
            this.URL = 'Booking/createItem'
            this.ID = null
        },

        resetBooking(){
          this.URL = 'Booking/createItem'
          // this.formData.branch_id=''
          this.formData.name=''
          this.formData.mobile=''
          this.formData.note=''
          this.formData.address=''
          this.formData.gender=''
          this.formData.floor_id=''
          this.formData.table_id=''
          this.formData.number_persons=''
          this.formData.date=''
          this.formData.time=''

        },


       	addEditBooking(e){

            e.preventDefault();
       		axios.post(this.URL,this.formData).then((response)=>{
                if(response.data.items){
                   swal({
                    text: "تم حفظ التغييرات بنجاح",
                    icon: "success",
                    timer: 2000,
                    button: false
                    }); 
                    this.closeModal()
                    this.getBooking()           

                }else{
                    swal({
                    text: response.data.message,
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }       			
       			
       		})
       	},


        getBooking(){
            axios.get('Booking/getAllItems?page='+ this.currentPage).then(response => {
                if(response.data){
                  let data = response.data.items
                  this.totalPages=Math.ceil(data.total/data.per_page)
                    this.items = data;
                    // console.log(data)
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });
        },


        getBookingById(){
            axios.get('Booking/getById', { params: { ID: this.ID } }).then(response => {
                if(response.data){
                  let data = response.data.items
                  let translations = response.data.items.translations
                   this.formData = data;
                this.getFloorByIdFromSelectBranch()
                this.getTableByIdFromSelectFloor()

                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });
        },

        deleteBooking(id) {


            swal({
                  title: "Are you sure?",
                  text: "Once deleted, you will not be able to recover this imaginary item!",
                  icon: "warning",
                  buttons: true,
                  dangerMode: true,
                }).then((result) => {
              if (result) {
                axios.delete('Booking/deleteItem/'+id)
                    .then((response)=> {
                            if(response.data.code == 200){
                                swal(
                                  'Deleted!',
                                  'Item deleted successfully',
                                  'success'
                                )
                                this.getBooking()           

                            }else{
                                swal({
                                  icon: 'error',
                                  title: 'Oops...',
                                  text: 'Something went wrong!',
                                })

                            }
                           
                    

                    }).catch(() => {
                        swal({
                          icon: 'error',
                          title: 'Oops...',
                          text: 'Something went wrong!',
                        })
                    })
                }

            })
        },



        getFloorByIdFromSelectBranch(){
            // axios.get('Floors/getAllByBranchID?branch_id='+ this.formData.branch_id).then(response => {
            axios.get('Floors/getAllItems?pagination=0').then(response => {
                if(response.data){
                  let data = response.data.items
                  // console.log(data)
                this.floors = data;
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });
        },
        

        getTableByIdFromSelectFloor(){
            axios.get('Table/getAllByFloorID?floor_id='+ this.formData.floor_id).then(response => {
                if(response.data){
                  let data = response.data.items
                this.tables = data;
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });
        },




        //function only for print invoice 
        getModalPrint(ID){
            $('#myModalPrint').modal('show');
            this.titleModal = 'طباعة الفاتورة'
            this.getInvoice(ID)
            // this.Canav()
        },

        closeModalPrint(){
            $('#myModalPrint').modal('hide');
        },


        getInvoice(ID){
            var booking = ID
            axios.get('OrderDetails/getAllItems?booking_id='+booking).then(response => {

                if(response.data){
                if(Array.isArray(response.data.items) && response.data.items.length > 0){
                  let data = response.data.items
                  // console.log(data)
                    this.ItemPrint = data
                    this.qr_code = response.data.items[0].order.qr_code
                    this.Canav()
                }

                }else{
                    swal({
                    text: response.data.message,
                    icon: 'warining',
                    timer: false,
                    button: true
                    }).then((result) => {
                        // this.$router.push('/subadmin/Booking')
                    });
                }
            }).catch((error)=>{

                     swal({
                    text: 'لا يوجد منتجات مضافة  على السلة',
                    icon: 'warining',
                    timer: false,
                    button: true
                    });      
            });
        },
 

        getImageUrl(imageFileName) {
            var baseURL = window.location.protocol + "//" + window.location.host;
          return `${baseURL}/qr_code/${imageFileName}`;
        },


        Canav(){
                let canvas = document.getElementById('canvas') ;
                let ctx = canvas.getContext("2d");
                ctx.font = "30px Arial";
                // canvas.style.hieght='900px';
                
               let img = document.getElementById("scream");
               // let img = document.getElementById("code").children;


               // let img = this.ItemPrint[0].order.qr_code;
               //img.crossOrigin = 'anonymous';

                let order_number = this.ItemPrint[0].order.id 
                this.info_company = this.ItemPrint[0].order.info_company
 
               ctx.drawImage(img, 100,10,100,100);


               ctx.font = "10px Arial";
               ctx.fillText("شركة  - "+this.info_company.name_ar +" - "+ this.info_company.name_ar, 200, 135);
               ctx.fillText("فرع - "+this.info_company.current_session_branch.name, 200, 150);
               ctx.fillText("الرقـــم الضريبي  - "+this.info_company.tax_number, 200, 170);
               ctx.font = "20px Arial";
               ctx.fillText("رقم الطلب : "+ "000"+order_number+"#", 220, 220);


                ctx.font = "12px Arial";
               ctx.fillText("رقم", 300, 250);
               ctx.fillText("الصنف ", 250, 250);
               ctx.fillText("الكمية ", 120, 250);
               ctx.fillText("السعر ", 80, 250);
               ctx.fillText("الاجمالي ", 40, 250);
               

               let products = this.ItemPrint
               let h = 0;
               products.forEach(function(element, index) {

                
                   let hieght = 250 + (index+1) * 30 
                   var product_name = element.product.name
                   // if(product_name.length >20){
                   //  // hieght = hieght + 30 
                   // }
                   ctx.fillText(index+1, 300, hieght);
                   ctx.fillText(product_name.substr(0, 25), 280, hieght);
                   ctx.fillText(element.quentity, 110, hieght);
                   ctx.fillText(element.price, 80, hieght);
                   ctx.fillText(element.total, 40, hieght);
                   h = hieght+50

                        
                });


               

               ctx.fillText("اجمالي الفاتورة  بدون ضريبة ", 250, h);
               ctx.fillText(this.ItemPrint[0].order.total, 40, h);


               ctx.fillText("اجمالي القيمة المضافة  15%  ", 250, h + 30);
               ctx.fillText(this.ItemPrint[0].order.tax , 40, h + 30);

               ctx.fillText("اجمالي الخصومات", 250, h + 60);
               ctx.fillText(this.ItemPrint[0].order.discount , 40, h + 60);


               ctx.fillText("اجمالي الفاتورة مع الضريبة", 250, h + 90);
               ctx.fillText(this.ItemPrint[0].order.total_after_tax - this.ItemPrint[0].order.discount , 40, h + 90);




               let img2 = document.getElementById("qr_code");

               ctx.drawImage(img2, 100,h + 140 ,100,100);


               var ip = this.$store.state.user.userInfo.ip_printer;


                var printer = null;
                var ePosDev = new epson.ePOSDevice();
                ePosDev.connect(ip, 8008, cbConnect);
                     
                              
                function cbConnect(data) {
                    if(data == 'OK') {
                        ePosDev.createDevice('local_printer', ePosDev.DEVICE_TYPE_PRINTER, {'crypto' : true, 'buffer' : false}, cbCreateDevice_printer);
                    } else {
                        console.log(data);
                    }
                }
                    
                function cbCreateDevice_printer(devobj, retcode) {
                        if( retcode == 'OK' ) {
                            printer = devobj;
                            alert('cbCreateDevice_printer');
                            executeAddedCode();
                        } else {
                            console.log(retcode);
                        }
                    }

    
                function executeAddedCode() {
                    //  printer.addTextLang('mul');
                    //  printer.addTextAlign(printer.ALIGN_LEFT);

                        

                        //printer.addText('الطائف,\tفرع قروى !\n');
                        
                        
                        //printer.addBarcode('12345', printer.BARCODE_CODE39, printer.HRI_NONE, printer.FONT_A, 2, 32);
                        //printer.addSymbol('9xdebugger', printer.SYMBOL_QRCODE_MODEL_2, printer.LEVEL_DEFAULT, 3, 0, 0);
                        //
                        try {
                        printer.addImage(ctx, 0, 0,420, 1000, printer.COLOR_1);
                        alert('ok'); 
                        printer.addCut(printer.CUT_FEED);    
                        printer.send();
                        }catch(err) {
                      alert(err.message);
                    }
                }


            },


       // end function print     
       


       },

       created(){

            this.languages = JSON.parse(localStorage.getItem("languages"))
            // this.$lang.setLocale('ar')
            // alert(this.$lang.getLocale())
            this.getBooking()
            this.getFloorByIdFromSelectBranch()
            this.getTableByIdFromSelectFloor()


            axios.get('Branch/getAllItems', { params: { pagination: 0 } }).then(response => {
                if(response.data){
                  let data = response.data.items
                  this.branches = data;
                
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });

 


            axios.get('Product/getAllItems', { params: { pagination: 0 } }).then(response => {
                if(response.data){
                  let data = response.data.items
                  this.products = data;
                
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });


           
       },
       mounted(){

       }
    }


   
</script>
<style src="vue-sliding-pagination/dist/style/vue-sliding-pagination.css"></style>
<style>
    ol, p, ul {
        line-height: 1.0;
    }


    .c-sliding-pagination__list-element {
        
        padding: 0.5em !important;
        border-radius: 0.6em !important;
        margin: 1px 2px 1px 4px !important;
    }


</style>