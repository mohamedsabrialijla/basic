<template>   
    <div>
        <div class="row">
            <div class="col-12">
                <div class="portlet">
                    <div class="cs-breadcrumb">
                        <div class="cs-breadcrumb-right">
                            <i class="icon icon-basket"></i>

                            <ul>
                                <li>المتسوق الشخصي > المنتجات</li>
                            </ul>
                        </div> 
                        <div class="cs-breadcrumb-left">
                            <a href="" data-toggle="modal" data-target=".card-products-modal">
                                <div class="cart" @click="getBasket">
                                    <i class="icon icon-shopping-cart"></i>
                                    <p>سلتي</p>
                                    <div>
                                        <span>{{count_basket}}</span>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div> 

        <div class="row" style="transform: rotateX(45deg) !important;">
            <div class="col-xl-4 col-lg-4 mb-4 mb-lg-0 shopper-filter-grid">
                <div class="">
                    <div class="modal-content">
                        <div class="cs-breadcrumb" style="border-bottom: 1px solid #ccc;">
                            <div class="cs-breadcrumb-right">
                                <i class="icon icon-basket"></i> 
                                <b>السلة</b>
                            </div> 

                           </div>
                        <div class="modal-body">
                                <div class="card-products-wrapper scroll" >
                                    <div class="card-products-inner" v-for="basket in baskets" :key="basket.id" style="background: #f1f0f0;padding: 8px;border: 3px solid #fff;">
                                        <div class="card-products-content" >
                                            <div style="display:flex">
                                                <div class="col-lg-8">
                                                    
                                                    <h6><b>{{basket.product.name}}</b></h6>
                                                </div>
                                                <div class="col-lg-4">
                                                    <span class="delete btn-icon" @click="deleteFromBasket(basket.id)" style="background:#F96868;cursor:pointer">
                                                    <i class="icon icon-delete"></i>
                                                    </span>
                                                </div>    
                                                   
                                            </div>
                                           

                                            <div class="product-price product-option" >
                                                <div class="form-group row" style="margin-top:20px;">
                                                    
                                                    <div class="col-lg-3">
                                                        <div class="product-price-inner">
                                                            <div class="price-item">
                                                                <b>{{basket.product.offer}} ر.س</b>
                                                            </div>
                                                           
                                                        </div>
                                                    </div>

                                                    <div class="col-lg-5" style="margin-top:-16px"> 
                                                        <div class="quantity-inner">
                                                            <div class="coupons-value-quantity coupons-options-amount">
                                                                    <div class="cs-quantity cs-quantity-price">
                                                                        <span class="plus" @click="editQuentity(basket.id,'plus')">
                                                                            <div>+</div>
                                                                        </span>
                                                                        <input type="number" @input="debouncedFunction(basket.id,$event)" 
                                                                            class="input-text" step="1" min="0" v-model="basket.quentity" 
                                                                          title="Qty" size="4" pattern="[0-9]*"
                                                                            inputmode="numeric">
                                                                        <span class="minus" @click="editQuentity(basket.id,'minus')">
                                                                            <div>-</div>
                                                                        </span>
                                                                    </div>
                                                                </div>                                            
                                                        </div>
                                                    </div>

                                                    <div class="col-lg-4">
                                                        <div class="product-price-inner">
                                                            <div class="price-item">
                                                                <b>{{basket.total}} ر.س</b>
                                                            </div>
                                                           
                                                        </div>
                                                    </div>


                                                </div>
                                            </div>




                                      



 
                                            

                                        </div>
                                    </div>

                                </div>



                                 <div class="product-price product-option" >
                                                <div class="form-group row" style="margin-top:20px;">
                                                    
                                                    <div class="col-lg-8">
                                                        <div class="product-price-inner">
                                                            <div class="price-item">
                                                                <b>اجمالي التكلفة الكلية</b>
                                                            </div>
                                                           
                                                        </div>
                                                    </div>

                                                    <div class="col-lg-4">
                                                        <div class="product-price-inner">
                                                            <div class="price-item">
                                                                <b>{{overall_total}} ر.س</b>
                                                            </div>
                                                           
                                                        </div>
                                                    </div>


                                                </div>
                                            </div>






                                <div class="card-products-btns" v-if="baskets.length != 0">
                            
                                    <div class="card-products-action" >
                                        <button class="btn delete-all-item" @click="deleteAllBasket" style="border: 1px solid #F96868;
    background: transparent;
    color: #F96868;
    width: 150px;
    height: 40px;
    border-radius: 0.25rem;
    font-size: 13px;">
                                            إزالة جميع العناصر
                                        </button>
                                        <button class="pay-now btn btn-primary" @click="getModalPayment()">
                                            صفحة الدفع 
                                        </button>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-8 col-lg-8">
                <div class="shopper-product">
                    <form>
                        <div class="top-box-search">
                            
                            <div class="shopper-filter col-md-12" >
                                <div style="display:flex">
                                    <div class="shopper-search-container col-md-6">
                                        <input type="text" class="form-control shopper-search-input"
                                            placeholder="ابحث داخل الأقسام" v-model="keywords">
                                        <button type="submit" class="shopper-search-btn">
                                            <span class="icon-search"></span>
                                        </button> 
                                    </div>

                                     <div class="shopper-search-container col-md-6">
                                       <input type="text" class="form-control" placeholder="ابحث عن منتج"  v-model="keywords_product">
                                        <button type="submit" class="shopper-search-btn">
                                            <span class="icon-search"></span>
                                        </button> 
                                    </div>
                                </div>

                                <form>
                                <div class="shopper-checkbox-container col-md-12" style="display:flex">
                                    <div class="col-md-4" v-for="category in categories" :key="category.id">
                                        <input type="checkbox" :value="category.id" class="" :id="'check_'+category.id"  v-model.number="keywords_checkout"> 
                                        <label class="" for="showAll">{{category.title}}</label>
                                    </div>
                           
                                </div>
                                </form>

                            </div>


            
                        </div>
                    </form>

                    

                    <div class="product-box-wrapper">
                        <div class="product-box" v-for="item in items.data">
                            <div class="product-img">
                                <img :src="item.cover"
                                    alt="">
                                <span class="product-section">{{item.category.title}}</span>
                            </div>
                            <div class="product-name">
                                <a href="shopper-product-details.html">
                                    {{item.name}}
                                </a>
                            </div> 
                            <div class="product-info">
                                <p @click="addToBasket(item.id)" class="btn btn-primary btn-icon" title="اضافة الى السلة" style="cursor: pointer">
                                    <i class="icon icon-basket" ></i>
                                </p>

                                <div class="product-price">
                                    <span class="price">{{item.offer}}</span>
                                    <span class="price-old">{{item.price}} ر.س</span>
                                </div>
                            </div>

                        </div>
 
                    </div>
                </div>
            </div>
        </div>



 <!-- start card product -->
<div class="modal fade main-modal card-products-modal" role="dialog" aria-labelledby="assist" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <i class="icon icon-basket"></i>
                <h5 class="modal-title">منتجات السلة</h5>

                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                    <div class="card-products-wrapper scroll" >
                        <div class="card-products-inner" v-for="basket in baskets" :key="basket.id">
                            <div class="card-products-img">
                                <img :src="basket.product.cover" alt="">
                            </div>
                            <div class="card-products-content" >
                                <h4>{{basket.product.name}}</h4>

                                <div class="product-price product-option" >
                                    <div class="form-group row">
                                        <label class="col-lg-4 flex-label">سعر المنتج</label>
                                        <div class="col-lg-8">
                                            <div class="product-price-inner">
                                                <div class="price-item">
                                                    <p>{{basket.product.offer}} ر.س</p>
                                                    <span class="old-price">{{basket.product.price}} ر.س</span>
                                                </div>
                                               
                                            </div>
                                        </div>
                                    </div>

                                </div>

                                <div class="product-quantity product-option">
                                    <div class="form-group row">
                                        <label class="col-lg-2 flex-label">الكمية</label>
                                        <div class="col-lg-10">
                                            <div class="quantity-inner">
                                                <div class="coupons-value-quantity coupons-options-amount">
                                                        <div class="cs-quantity cs-quantity-price">
                                                            <span class="plus" @click="editQuentity(basket.id,'plus')">
                                                                <div>+</div>
                                                            </span>
                                                            <input type="number" @input="debouncedFunction(basket.id,$event)"
                                                                class="input-text" step="1" min="0" v-model="basket.quentity" 
                                                              title="Qty" size="4" pattern="[0-9]*"
                                                                inputmode="numeric">
                                                            <span class="minus" @click="editQuentity(basket.id,'minus')">
                                                                <div>-</div>
                                                            </span>
                                                        </div>
                                                    </div>


                                                    <div class="product-price product-option" >
                                                        <div class="form-group row">
                                                            <label class="col-lg-4 flex-label">المجموع  </label>
                                                            <div class="col-lg-8">
                                                                <div class="product-price-inner">
                                                                    <div class="price-item">
                                                                        <p>{{basket.total}} ر.س</p>
                                                                        
                                                                    </div>
                                                                   
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>




                                                <div class="product-delete" v-if="paid==0">
                                                    <button>
                                                        <span>إزالة المنتج</span>
                                                        <span class="delete btn-icon" @click="deleteFromBasket(basket.id)">
                                                            <i class="icon icon-delete"></i>
                                                        </span>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>

                    </div>

                    <div class="card-products-btns" v-if="baskets.length != 0">
                        <div class="total-cost">
                            <label>
                                اجمالي التكلفة :
                            </label>
                            <p>{{overall_total}} ر.س</p>
                        </div>

                       

                        <div class="card-products-action" >
                            <button class="btn delete-all-item" @click="deleteAllBasket" >
                                إزالة جميع العناصر
                            </button>
                            <button class="pay-now btn btn-primary" @click="getModalPayment()">
                                صفحة الدفع 
                            </button>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</div>
    <!-- end card product --> 

  








<!-- modal add Payment -->
<div class="modal fade main-modal time_work" id="myModalPayment" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-blg" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title d-flex">
                <i class="icon icon-clock"></i>
                  تفاصيل الدفع والفاتورة</h5>
            <button type="button" class="close" @click="closeModalPayment" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <Payment :Item='ItemSelect' v-if="C_active == 1"></Payment>
        </div>
    </div>
    </div>
</div>
<!-- end Payment modal -->

</div>
  
</template>
 
 

<script>

    import Multiselect from 'vue-multiselect'
    import SlidingPagination from 'vue-sliding-pagination'
     import Payment from './Payment'
       export default {
        components: { Multiselect,SlidingPagination,Payment},
       name : 'Basket',
       data(){
	       	return {
            C_active:0,
            ItemSelect:[] ,
            order_id:0,
            paid:0,
            overall_total:0,
            count_basket: 0,
            baskets: [],
            titleModal:'',
            currentPage: 0,
            totalPages: 0,
            items:[],
            languages:[],
            errors: [],
            categories: [],
            ID:'',
            keywords:'',
            keywords_product:'',
            keywords_checkout:[],
            URL:'Basket/createItem',
	       	 
            formData:{
              product_id:null,
	       	 	},

                debounceTimeout: null,
    

		    } 
       },
       methods:{

        


    debouncedFunction($detail_id , event) {
        if(event.target.value < 1){
            return false;
        }
      clearTimeout(this.debounceTimeout);
      this.debounceTimeout = setTimeout(() => {
        this.changeQuentity($detail_id,event);
      }, 1000); // 300 milliseconds delay
    },



        pageChangeHandler(selectedPage) {
            this.currentPage = selectedPage
            this.getProducts()
        },

        editQuentity($detail_id,$type){ 
            let form = new FormData();
            form.append('detail_id', $detail_id);
            form.append('type', $type);
            axios.post('Basket/editItem',form).then((response)=>{
                if(response.data.items){
                   
                    this.baskets = response.data.items  
                    this.overall_total = response.data.items[0].order.total  
                    this.count_basket = this.baskets.length        

                }else{
                    swal({
                    text: response.data.message,
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }                   
                
            })
                
            },




            changeQuentity($detail_id,event){
                // console.log('event.data');
                // console.log(event.target.value);
                // console.log(event.data);
            // setTimeout(() => {


            let form = new FormData();
            form.append('detail_id', $detail_id);
            form.append('quentity',  event.target.value);
                axios.post('Basket/editItem?change_quantity=1',form).then((response)=>{
                    if(response.data.items){
                            this.baskets = response.data.items  
                            this.overall_total = response.data.items[0].order.total  
                            this.count_basket = this.baskets.length  
                             

                    }else{
                        swal({
                        text: response.data.message,
                        icon: 'error',
                        timer: false,
                        button: true
                        });
                    }                   
                
                }) 
            // }, "3000");
            
                
            },
           
       
       


        getProducts(){
            var booking = this.$route.params.booking_id
            var search = this.keywords_product
            var search_checkout = this.keywords_checkout
            console.log(search_checkout)
            axios.get('Product/getAllItems?page='+ this.currentPage +'&search='+search +'&booking_id='+booking + 'search_checkout='+search_checkout).then(response => {
                if(response.data){ 
                  let data = response.data.items
                  this.totalPages=Math.ceil(data.total/data.per_page)
                    this.items = data;

 
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });
        },


        getBasket(){
            var booking = this.$route.params.booking_id
            axios.get('Basket/getAllItems?booking_id='+booking).then(response => {

                if(response.data){
                if(Array.isArray(response.data.items) && response.data.items.length > 0){
                  let data = response.data.items
                  console.log(data)
                    this.ItemSelect = data
                    this.baskets = data;
                    this.count_basket = data.length
                    this.overall_total = response.data.items[0].order.total
                    this.order_id = response.data.items[0].order.id
                    this.paid = response.data.items[0].order.paid
                    // alert(this.paid)
                }else{
                    this.ItemSelect = null
                    this.baskets = [];
                    this.count_basket = 0
                    this.overall_total = 0
                    this.order_id = response.data.items
                }

                }else{
                    swal({
                    text: response.data.message,
                    icon: 'warining',
                    timer: false,
                    button: true
                    }).then((result) => {
                        // this.$router.push('/subadmin/Booking')
                    });
                }
            }).catch((error)=>{

                     swal({
                    text: 'لا يوجد منتجات مضافة  على السلة',
                    icon: 'warining',
                    timer: false,
                    button: true
                    });      
            });
        },

        addToBasket($id){

            let form = new FormData();
            form.append('product_id', $id);
            form.append('booking_id', this.$route.params.booking_id);
            axios.post(this.URL,form).then((response)=>{
                if(response.data.items){
                    this.baskets = response.data.items
                    this.overall_total = response.data.items[0].order.total
                    this.count_basket = this.baskets.length  
                    this.getProducts()         

                }else{
                    swal({
                    text: response.data.message,
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }                   
                
            })
        },

        deleteFromBasket(id) { 
            swal({
                  title: "Are you sure?",
                  text: "Once deleted, you will not be able to recover this imaginary item!",
                  icon: "warning",
                  buttons: true,
                  dangerMode: true,
                }).then((result) => {
              if (result) {
                axios.delete('Basket/deleteItem/'+id)
                    .then((response)=> {
                            if(response.data.code == 200){
                                this.getProducts()
                                 this.getBasket()
                                swal(
                                  'Deleted!',
                                  'Item deleted successfully',
                                  'success'
                                )
                                          

                            }else{
                                swal({
                                  icon: 'error',
                                  title: 'Oops...',
                                  text: 'Something went wrong!',
                                })

                            }
                           
                    

                    }).catch(() => {
                        swal({
                          icon: 'error',
                          title: 'Oops...',
                          text: 'Something went wrong!',
                        })
                    })
                }

            })
        },

        deleteAllBasket(){ 
            // alert(this.order_id)
            swal({
                  title: "Are you sure?",
                  text: "Once deleted, you will not be able to recover this imaginary item!",
                  icon: "warning",
                  buttons: true,
                  dangerMode: true,
                }).then((result) => {
              if (result) {
                axios.delete('Basket/deleteAllItem/'+this.order_id)
                    .then((response)=> {
                            if(response.data.code == 200){
                                this.getProducts() 
                                this.count_basket = 0;
                                swal(
                                  'Deleted!',
                                  'Item deleted successfully',
                                  'success'
                                )
                                this.baskets = [];
                                this.overall_total = 0;          

                            }else{
                                swal({
                                  icon: 'error',
                                  title: 'Oops...',
                                  text: 'Something went wrong!',
                                })

                            }
                           
                    

                    }).catch(() => {
                        swal({
                          icon: 'error',
                          title: 'Oops...',
                          text: 'Something went wrong!',
                        })
                    })
                }

            })
        },



        getCategories(){
               var search = this.keywords
            axios.get('SubCategory/getAllItems', { params: { pagination: 0 , search : search } }).then(response => {
                if(response.data){
                    // console.log(response.data)
                  let data = response.data.items
                  this.categories = data;
                  // console.log(this.categories)
                
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });           
            }); 
        },
        

        //here you are function Payment
           closeModalPayment(){ 
                this.C_active =0
                $('#myModalPayment').modal('hide')
            }, 

            getModalPayment(){
                // this.ItemSelect = this.$route.params.booking_id 
                this.C_active = 1
                $('#myModalPayment').modal('show')
            },



       },
 
       created(){

            this.languages = JSON.parse(localStorage.getItem("languages"))
            this.getProducts()
            this.getCategories() 
            this.getBasket()
       },
       mounted(){

       },
       watch: {
        keywords(after, before) {
                this.getCategories();
            },

            keywords_product(after, before) {
                this.getProducts();
            },

            keywords_checkout(after, before) {
                this.getProducts();
            }
        }

    }


   
</script>
<style src="vue-sliding-pagination/dist/style/vue-sliding-pagination.css"></style>
<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>
<style>

.multiselect__option--highlight {
    background: #3ebdb1 !important;
    outline: none;
    color: #fff;}

    .multiselect__tag {
    background: #3ebdb1;}

    .multiselect__tag-icon:after {
    color: ##33a196;
    }




    ol, p, ul {
        line-height: 1.0;
    }


    .c-sliding-pagination__list-element {
        
        padding: 0.5em !important;
        border-radius: 0.6em !important;
        margin: 1px 2px 1px 4px !important;
    }


        .card-products-modal .card-products-wrapper {
    height: 300px;}

    

</style>