<template>   
    <div>
        <div class="row">
            <div class="col-12">
                <div class="portlet">
                    <div class="cs-breadcrumb">
                        <div class="cs-breadcrumb-right">
                            <i class="icon icon-basket"></i>

                            <ul>
                                <li>المتسوق الشخصي > المنتجات</li>
                            </ul>
                        </div> 
                        <div class="cs-breadcrumb-left">
                            <a href="" data-toggle="modal" data-target=".card-products-modal">
                                <div class="cart" @click="getBasket">
                                    <i class="icon icon-shopping-cart"></i>
                                    <p>سلتي</p>
                                    <div>
                                        <span>{{count_basket}}</span>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            
           
        </div>



 

</div>
  
</template>
 
 

<script>

       export default {
        // components: { },
       name : 'Invoice',
       data(){
	       	return {
           
            languages:[],
            errors: [],
            URL:'Invoce/getItem',

		    } 
       },
       methods:{
        getBasket(){
            var booking = this.$route.params.booking_id
            axios.get('Basket/getAllItems?booking_id='+booking).then(response => {
                if(response.data){
                  let data = response.data.items
                    this.baskets = data;
                    this.count_basket = data.length
                    this.overall_total = response.data.items[0].order.total
                    this.order_id = response.data.items[0].order.id

                }else{
                     swal({
                    text: 'لا يوجد منتجات مضافة  على السلة',
                    icon: 'warining',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                     swal({
                    text: 'لا يوجد منتجات مضافة  على السلة',
                    // icon: 'warining',
                    timer: false,
                    button: true
                    });      
            });
        },

    

       },
 
       created(){

            this.languages = JSON.parse(localStorage.getItem("languages"))
           
       },
       mounted(){

       },
       watch: {

       }
    }


   
</script>
<style>


</style>