<template>
    <div>
        <div class="container-fluid">
                  
                    <div class="row">
                        <div class="col-xl-6 col-12">
                            <div class="portlet">
                                <div class="portlet-head">
                                    <div class="portlet-head-label">
                                        <div class="portlet-head-icon">
                                            <i class="icon icon-clipboard"></i>
                                        </div>
                                        <h3 class="portlet-head-title">
                                            بيانات الطلب
                                        </h3>
                                    </div>

                                    <div class="portlet-head-btn">
                                        <a href="" class="btn btn-primary btn-icon" data-toggle="tooltip"
                                            data-placement="top" data-original-title="طباعة">
                                            <i class="icon icon-Printer"></i>
                                        </a>
                                    </div>

                                </div>
                                <div class="portlet-body">

                                    <div class="order-data">
                                        <form>
                                            <div class="form-group row mb-3">
                                                <label class="col-sm-3">طلب</label>
                                                <div class="col-sm-9">
                                                    <p>#000{{items[0].order.id}}</p>
                                                </div>
                                            </div>
                                          <div class="form-group row mb-3">
                                                <label class="col-sm-3">التاريخ/الوقت</label>
                                                <div class="col-sm-9">
                                                    <p>{{items[0].order.created_at}}</p>
                                                </div>
                                            </div>
                                            <div class="form-group row mb-3">
                                                <label class="col-sm-3">حالة الطلب</label>
                                                <div class="col-sm-9">
                                                    <p>{{items[0].order.status_text}}</p>
                                                </div>
                                            </div>
                                        </form>
                                    </div>

                                </div>
                            </div>
                        </div>


                        <div class="col-xl-6 col-12">
                            <div class="portlet">
                                <div class="portlet-head">
                                    <div class="portlet-head-label">
                                        <div class="portlet-head-icon">
                                            <i class="icon icon-clients"></i>
                                        </div>
                                        <h3 class="portlet-head-title">
                                            بيانات العميل
                                        </h3>
                                    </div>
                                </div>
                                <div class="portlet-body" style="min-height: 172px">

                                    <div class="order-data">
                                        <h3>طلب مباشر غير مرتبط بعميل </h3>
                                        <!-- <form>
                                            <div class="form-group row mb-3">
                                                <label class="col-sm-3">اسم العميل</label>
                                                <div class="col-sm-9">
                                                    <p>{{items[0].order.booking.gender}}:{{items[0].order.booking.name}}</p>
                                                </div>
                                            </div>
                                             <div class="form-group row mb-3">
                                                  <label class="col-sm-3">الجوال</label>
                                                <div class="col-sm-9">
                                                    <p>{{items[0].order.booking.mobile}}</p>
                                                </div>
                                            </div>

                                            <div class="form-group row mb-3">
                                                <label class="col-sm-3">العنوان</label>
                                                <div class="col-sm-9">
                                                    <p>{{items[0].order.booking.address}}</p>
                                                </div>
                                            </div>
                                           
                                        </form> -->
                                    </div>

                                </div>
                            </div>
                        </div>


                    </div>

                    <div class="row">
                        <div class="col-12">
                            <div class="portlet">
                                <div class="portlet-head">
                                    <div class="portlet-head-label">
                                        <div class="portlet-head-icon">
                                            <i class="icon icon-clipboard"></i>
                                        </div>
                                        <h3 class="portlet-head-title">
                                            تفاصيل الطلب
                                        </h3>
                                    </div>
                                </div>
                                <div class="portlet-body">
                                    <div class="dtable scroll">
                                        <table class="table d-table">
                                            <thead>
                                                <th>#</th>
                                                <th>اسم المنتج</th>
                                                <th>الكمية</th>
                                                <th>السعر (ريال سعودي)</th>
                                                <th>الاجمالي</th>

                                            </thead>

                                            <tbody>
                                                <tr v-for="item,index in items">
                                                    <td>{{index+1}}</td>
                                                    <td>{{item.product.name}}</td>
                                                    <td>{{item.quentity}}</td>
                                                    <td> {{item.price}} </td>
                                                    <td> {{item.total}} </td>
                                                </tr>
                                            
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-xl-6 col-12">
                            <div class="portlet">
                                <div class="portlet-head">
                                    <div class="portlet-head-label">
                                        <div class="portlet-head-icon">
                                            <i class="icon icon-report"></i>
                                        </div>
                                        <h3 class="portlet-head-title">
                                            الملخص الاجمالي
                                        </h3>
                                    </div>
                                </div>
                                <div class="portlet-body">
                                    <div class="list-order">
                                        <div class="list-order-row">
                                            <label>
                                                الإجمالي الفرعي :
                                            </label>
                                            <span>
                                               {{items[0].order.total}} ر.س
                                            </span>
                                        </div>
                                        <div class="list-order-row">
                                            <label>
                                                ض.ق.م (14%) :
                                            </label>
                                            <span>
                                               {{items[0].order.tax}} ر.س
                                            </span>
                                        </div>
                                      
                                        <div class="list-order-row ">
                                            <label>
                                                قيمة الخصم:
                                            </label>
                                            <span>
                                        <input type="number" v-model="formData.discount" class="form-control width_custom"  placeholder="ر.س">

                                            </span>
                                        </div>
                                    </div>
                                    <div class="list-order-total">
                                        <div>
                                            <label>
                                                الإجمالي الكلي :
                                            </label>
                                            <span>
                                                {{items[0].order.total_after_tax - formData.discount}} ر.س
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-6 col-12">
                            <div class="portlet">
                                <div class="portlet-head">
                                    <div class="portlet-head-label">
                                        <div class="portlet-head-icon">
                                            <i class="icon icon-report"></i>
                                        </div>
                                        <h3 class="portlet-head-title">
                                            ادفع الأن 
                                        </h3>
                                    </div>
                                </div>
                                <div class="portlet-body">
                                    
                                    <div class="list-order-total">
                                        <div>
                                            <input type="text"  v-model="formData.value_pay" class="form-control"  placeholder="ادخل المبلغ المطلوب للدفع">

                                          <!--   <input type="number" disabled v-model="formData.discount" class="form-control"  placeholder="ادخال قيمة الخصم ان وجد">


                                            <input type="number" disabled v-model="formData.code" class="form-control"  placeholder="ادخال كوبون الخصم ان وجد"> -->


                                               
                                        </div>

                                         <button class="pay-now btn btn-primary pay_custom" @click="payNow();">ادفع الان</button >



                                        <a href="#" class="btn btn-primary btn-info" @click="getModal()">
                                            <i class="icon icon-add icon-text"></i>
                                          طباعة الفاتورة
                                        </a>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

 




<!-- modal add Booking -->
<div class="modal fade main-modal add-Booking" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="width:350px;">
    <div class="modal-dialog modal-dialog-centered modal-blg" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title d-flex">
                <i class="icon icon-basket"></i>
                 فاتورة ضريبية</h5>
            <button type="button" class="close" @click="closeModal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div> 
        <div class="modal-body">
             <form  >
                <div class="row">
                    <div class="alert alert-danger" role="alert" v-if="errors.length">
                        <b style="font-weght">يرجي التاكد من البيانات  :</b>
                        <ul>
                          <li v-for="error in errors">{{ error }}</li>
                        </ul>
                    </div>
                    
                </div>

                <div v-html="items[0].order.qr_code"></div>

                <br>
                <canvas id="canvas" width="" height="500" ></canvas>


              
                <!-- <div class="btn-container">
                    <a class="btn btn-outline-light"  @click="closeModal">الغاء</a>
                    <button type="submit"
                        class="btn btn-primary">حفظ</button>
                </div> -->
            </form>
        </div>
    </div>
    </div>
</div>

<!-- end modal -->



   </div>
</template>
 

<script>

    import SlidingPagination from 'vue-sliding-pagination'

    export default {
        components: { SlidingPagination},
        name : 'PaymentOrder',
        props:['Item'],

        data(){
            return {
                
               info_company:null,
                items:[],
                languages:[],
                errors: [],
                URL:'Coupon/createItem',
                 paid:0,
                 
                formData:{
                  value_pay :null,
                  discount :0,
                  // code :null,
              
                },

                }
            },
        methods:{


            // resetItem(){
            //   this.URL = 'Coupon/createItem'
            //   this.formData.fromDate=''
            //   this.formData.endDate=''
            //   this.formData.type=''
            //   this.formData.status=''
            //   this.formData.code=''
            //   this.formData.name=''
            //   this.formData.percentage=''
            //   this.formData.value=''
            // },



             getModal(){
            $('#myModal').modal('show');
            this.titleModal = 'اضافة حجز جديد'
            this.Canav()
        },



        closeModal(){
            $('#myModal').modal('hide');
            this.URL = 'Booking/createItem'
            this.ID = null
        },


         

            getItem(){

                let booking_id = this.$route.params.booking_id
                // alert(booking_id)
                axios.get('BasketOrder/getAllItems?order_id='+booking_id).then(response => {
                    if(response.data){
                      let data = response.data.items
                      // this.totalPages=Math.ceil(data.total/data.per_page)
                      this.items = data;
                    }else{
                         swal({
                        text: 'Error happens',
                        icon: 'error',
                        timer: false,
                        button: true
                        });
                    }
                }).catch((error)=>{
                        swal({
                        text: 'Error happens',
                        icon: 'error',
                        timer: false,
                        button: true
                        });         
                });
            },


           
            payNow(){
                var value = this.formData.value_pay 
                var discount = this.formData.discount 
                var required = this.items[0].order.total_after_tax - this.formData.discount

                if(value < required){
                    swal({
                        text: 'المبلغ المدفوع أقل من المطلوب',
                        icon: 'warning',
                        timer: false,
                        button: true
                        });
                }else if(value > required){
                     swal({
                        text: 'المبلغ المدفوع أقأعلى ل من المطلوب',
                        icon: 'warning',
                        timer: false,
                        button: true
                        });
                }else{
 
                    let order_id = this.items[0].order.id;
                    let form = new FormData();
                    form.append('order_id', order_id);
                    form.append('amount', value);
                    form.append('discount', discount);

                    axios.post('Payment/createItem',form).then((response)=>{
                    if(response.data){
                        console.log(response.data);
                      let data = response.data.items
                      this.paid = this.items[0].order.paid;
                      this.$router.push('/subadmin/Order')
                      
                    }else{
                         swal({
                        text: 'Error happens',
                        icon: 'error',
                        timer: false,
                        button: true
                        });
                    }
                }).catch((error)=>{
                        swal({
                        text: 'Error happens',
                        icon: 'error',
                        timer: false,
                        button: true
                        });         
                });
                }
            },

             Canav(){

                let canvas = document.getElementById('canvas') ;
                let ctx = canvas.getContext("2d");
                ctx.font = "30px Arial";
                
               // let img = document.getElementById("scream");
               // let img = this.items[0].order.qr_code;
               //img.crossOrigin = 'anonymous';

                let order_number = this.items[0].order.id 
                this.info_company = this.items[0].order.info_company
 
               // ctx.drawImage(img, 0,10);
               ctx.font = "10px Arial";
               ctx.fillText("شركة  - "+this.info_company.name_ar +" - "+ this.info_company.name_ar, 200, 100);
               ctx.fillText("فرع - "+this.info_company.current_session_branch.name, 200, 135);
               ctx.fillText("الرقـــم الضريبي  - "+this.info_company.tax_number, 200, 160);
               ctx.font = "20px Arial";
               ctx.fillText("رقم الطلب : "+ "000"+order_number+"#", 220, 220);


               var ip = this.$store.state.user.userInfo.ip_printer;

                var printer = null;
                var ePosDev = new epson.ePOSDevice();
                ePosDev.connect(ip, 8008, cbConnect);
                     
                              
                function cbConnect(data) {
                    if(data == 'OK') {
                        ePosDev.createDevice('local_printer', ePosDev.DEVICE_TYPE_PRINTER, {'crypto' : true, 'buffer' : false}, cbCreateDevice_printer);
                    } else {
                        console.log(data);
                    }
                }
                    
                function cbCreateDevice_printer(devobj, retcode) {
                        if( retcode == 'OK' ) {
                            printer = devobj;
                            // alert('cbCreateDevice_printer');
                            executeAddedCode();
                        } else {
                            console.log(retcode);
                        }
                    }

    
                function executeAddedCode() {
//  printer.addTextLang('mul');
//  printer.addTextAlign(printer.ALIGN_LEFT);

    

    //printer.addText('الطائف,\tفرع قروى !\n');
    
    
    //printer.addBarcode('12345', printer.BARCODE_CODE39, printer.HRI_NONE, printer.FONT_A, 2, 32);
    //printer.addSymbol('9xdebugger', printer.SYMBOL_QRCODE_MODEL_2, printer.LEVEL_DEFAULT, 3, 0, 0);
    //
    try {
    printer.addImage(ctx, 0, 0,420, 1000, printer.COLOR_1);
    // alert('ok'); 
    printer.addCut(printer.CUT_FEED);    
    printer.send();
    }catch(err) {
  alert(err.message);
}
    }


            },

 
          

        },

       created(){
            this.languages = JSON.parse(localStorage.getItem("languages"))
            this.getItem()

       },
       mounted(){
       },

    }


   
</script>
<style>
 .pay_custom{
    margin-top:10px;
 }
 .width_custom{
    width:88px;
 }
</style>