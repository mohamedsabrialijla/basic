<template>
    <div>
         <div class="row">
            <div class="col-12">
                <div class="portlet parcels latest-parcels">
                    <div class="portlet-head">
                        <div class="portlet-head-label">
                            <div class="portlet-head-icon">
                                <i class="icon icon-settings"></i>
                            </div>
                            <h3 class="portlet-head-title">
                                الطلبات
                            </h3>
                        </div>

                        <div class="portlet-head-btn">
                             <router-link class="btn btn-primary btn-info"
                                                                 :to="{name:'BasketOrder'}">
                                                                 <i class="icon icon-add"></i>
                                                             اضافة </router-link>


                          
                        </div>

                    </div>
                    <div class="portlet-body">
                        <form>
                            <div class="parcels-content mt-2">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="dtable">
                                            <table class="table d-table">
                                                <thead>
                                                    <th>#</th>
                                                    <th>رقم الطلب</th>
                                                    <th>المجموع</th>
                                                    <th>الحالة </th>
                                                    <th>حالة الدفع</th>
                                                    <th>تاريخ الانشاء </th>
                                                    <th>الاجراءات</th>

                                                </thead>

                                                <tbody>
                                                    <tr v-for="item,index in items.data" :key="item.id">
                                                        <td>{{index+1}}</td>
                                                        <td>#00000{{item.id}}</td>
                                                        <td>{{item.total}}</td>
                                                        <td>
                                                            <span v-if="item.status ==1" class="badge badge-pill badge-info">
                                                                {{item.status_text}}
                                                            </span> 
                                                            <span v-else-if="item.status ==3" class="badge badge-pill badge-danger">
                                                                {{item.status_text}}
                                                            </span>

                                                            <span v-else-if="item.status ==6 || item.status ==5" class="badge badge-pill badge-success">
                                                                {{item.status_text}}
                                                            </span>

                                                            <span v-else-if="item.status ==2 || item.status ==4" class="badge badge-pill badge-warning">
                                                                {{item.status_text}}
                                                            </span>

                                                        </td>

                                                        <td>
                                                            <span v-if="item.paid ==1" class="badge badge-pill badge-success">
                                                                {{item.paid_text}}
                                                            </span>

                                                            <span v-else-if="item.paid ==0 " class="badge badge-pill badge-warning">
                                                                {{item.paid_text}}
                                                            </span>

                                                        </td>


                                                        <td>{{item.created_at}}</td>
                                                        
                                                        
                                                        <td>
                                                            <a href="#"
                                                                class="btn red-btn btn-icon"
                                                                @click="deleteOrder(item.id)"
                                                                title="" data-original-title="حذف">
                                                                <i class="icon icon-delete"></i>
                                                            </a>

                                                          
 
                                                           <!--  <span class="d-inline-block"
                                                                 data-original-title="تعديل">
                                                                <a href="#" class="btn green-btn btn-icon"
                                                                    @click="getModalEdit(item)">
                                                                    <i
                                                                        class="icon icon-pencil-edit-button"></i>
                                                                </a> 
                                                            </span>
 -->

                                                            

                                                            <router-link class="btn green-btn btn-icon"
                                                                
                                                                 :to="{name:'Basket2', params: { booking_id: item.id} }">
                                                                 <i class="icon icon-basket"></i></router-link>

                                                                 

                                                        </td>
                                                    </tr>

                                                    <tr v-if="totalPages == 0">
                                                        <td colspan="6" style="text-align:center">لا يوجد نتائج </td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>


                                            <sliding-pagination v-if="totalPages != 0"
                                              :current="currentPage"
                                              :total="totalPages"
                                              @page-change="pageChangeHandler"
                                            ></sliding-pagination>


                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>






<!-- modal add Order -->
<div class="modal fade main-modal add-Order" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-blg" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title d-flex">
                <i class="icon icon-add"></i>
                 {{titleModal}}</h5>
            <button type="button" class="close" @click="closeModal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
             <form  @submit="addEditOrder">
                <div class="row">
                    <div class="alert alert-danger" role="alert" v-if="errors.length">
                        <b style="font-weght">يرجي التاكد من البيانات  :</b>
                        <ul>
                          <li v-for="error in errors">{{ error }}</li>
                        </ul>
                    </div>
                    
                </div>

                <div class="tab-content mt-4" id="myTabContent">
                    <div class="tab-pane fade show active" id="storeInformation"
                        role="tabpanel" aria-labelledby="storeInformation-tab">

                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex">

                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      اسم صاحب الحجز

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <input type="text" class="form-control"
                                            v-model="formData.name" value=""
                                            placeholder="اسم صاحب الحجز ">
                                    </div>
                                </div>


                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      رقم جوال صاحب الحجز

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <input type="text" class="form-control"
                                            v-model="formData.mobile" value=""
                                            placeholder="رقم جوال صاحب الحجز ">
                                    </div>
                                </div>




                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      العنوان

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <input type="text" class="form-control"
                                            v-model="formData.address" value=""
                                            placeholder="العنوان بالتفصيل ">
                                    </div>
                                </div>




                             
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex">

                              <!--   <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      الفرع

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <select class="form-control select-tag "  v-model="formData.branch_id"  @change="getFloorByIdFromSelectBranch()">
                                            <option v-for="branch in branches" v-bind:value="branch.id">{{branch.name}}</option>
                                           
                                        </select>
                                        

                                    </div>
                                </div> -->


                                
                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                         الطابق
                                    </label>
                                    <div class="col-sm-12">
                                        <select class="form-control select-tag "  v-model="formData.floor_id"   @change="getTableByIdFromSelectFloor($event)">
                                            <option v-for="floor in floors" v-bind:value="floor.id"> رقم الطابق  / اسم({{floor.number_floor}}/{{floor.name_floor}})</option>
                                           
                                        </select>
                                    </div>
                                </div>


                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        الطاولة
                                    </label>
                                    <div class="col-sm-12">
                                        <select class="form-control select-tag "  v-model="formData.table_id"  >
                                            <option v-for="tabel in tables" v-bind:value="tabel.id">رقم الطاولة ({{tabel.number_table}}) / تسع ل ({{tabel.persons_number}}) أشخاص</option>
                                           
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      عدد الاشخاص

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <input type="text" class="form-control"
                                            v-model="formData.number_persons" value=""
                                            placeholder="عدد الاشخاص">
                                    </div>
                                </div>
                             
                            </div>
                        </div>

                         <div class="row">
                            <div class="col-lg-12 col-12 d-flex">

                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        الجنس
                                    </label>
                                    <div class="col-sm-12">
                                       <select class="form-control select-tag "  v-model="formData.gender"  >
                                            <option value="Ms">Ms</option>
                                            <option value="Mrs">Mrs</option>
                                           
                                        </select>
                                    </div>
                                </div> 

                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        تاريخ الحجز
                                    </label>
                                    <div class="col-sm-12">
                                       <input type="date" class="form-control datepicker" id="startData" v-model="formData.date"
                                        placeholder="تاريخ" 
                                        data-toggle="datepicker"
                                        >
                                    <span class="calendar">
                                        <i class="fa fa-calendar" aria-hidden="true"></i>
                                    </span>
                                    </div>
                                </div> 

                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      وقت الحجز

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <input type="time" v-model="formData.time" class="form-control">
                                    </div>
                                </div>   
                            </div>
                            </div>



                             <div class="row">
                            <div class="col-lg-12 col-12 d-flex">


                                 <div class="form-group col-4" v-if="ID!=''">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        الحالة
                                    </label>
                                    <div class="col-sm-12">
                                       <select class="form-control select-tag "  v-model="formData.status"  >
                                            <option value="1">جديد</option>
                                            <option value="2">مقبول</option>
                                            <option value="3">مرفوض</option>
                                            <option value="4">جاري التجهيز</option>
                                            <option value="5">مجهز</option>
                                            <option value="6">تم التسليم</option>
                                        
                                            
                                           
                                        </select>
                                    </div>
                                </div> 


                                 




                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        ملاحظات
                                    </label>
                                    <div class="col-sm-12">
                                        <div class="col-sm-12 select-tag-wrapper" >
                                        <textarea class="form-control" rows="3"
                                             v-model="formData.note" id="messageContent"
                                            placeholder="ملاحظات "></textarea>
                                        </div>
                                    </div>
                                </div>

                              
                            </div>
                        </div> 
          

                        

                    </div>
                </div>

              
                <div class="btn-container">
                    <a class="btn btn-outline-light"  @click="closeModal">الغاء</a>
                    <button type="submit"
                        class="btn btn-primary">حفظ</button>
                </div>
            </form>
        </div>
    </div>
    </div>
</div>



        <!-- end modal -->
   </div>
</template>
 
 

<script>

    import SlidingPagination from 'vue-sliding-pagination'

       export default {
        components: { SlidingPagination},
       name : 'Order',
       data(){
            return {
            C_active : 0,
            ItemSelect:{},
            titleModal:'',
            currentPage: 0,
            totalPages: 0,
            items:[],
            languages:[],
            errors: [],
            branches: [],
            floors: [],
            tables: [],
            ID:'',
            URL:'Order/createItem',
             
            formData:{
              // branch_id:null,
              name:null,
              mobile:null,
              note:null,
              gender:null,
              floor_id:null,
              table_id:null,
              address:null,
              date:null,
              time:null,
              number_persons:null,
                },
            }
       },
       methods:{
        pageChangeHandler(selectedPage) {
            this.currentPage = selectedPage
            this.getOrder()
        },
       
        isNumber: function(evt) {
          evt = (evt) ? evt : window.event;
          var charCode = (evt.which) ? evt.which : evt.keyCode;
          if ((charCode > 31 && (charCode < 48 || charCode > 57)) && charCode !== 46) {
            evt.preventDefault();
          } else {
            return true;
          }
        },

        getModal(){
            this.resetOrder();
            $('#myModal').modal('show');
            this.titleModal = 'اضافة حجز جديد'
        },


        getModalEdit(item){
            this.resetOrder();
            $('#myModal').modal('show');
            this.titleModal = 'تعديل  الحجز'
            this.ID = item.id
            this.URL = 'Order/editItem'
            this.getOrderById() 
            
        },

        closeModal(){
            $('#myModal').modal('hide');
            this.URL = 'Order/createItem'
            this.ID = null
        },

        resetOrder(){
          this.URL = 'Order/createItem'
          // this.formData.branch_id=''
          this.formData.name=''
          this.formData.mobile=''
          this.formData.note=''
          this.formData.address=''
          this.formData.gender=''
          this.formData.floor_id=''
          this.formData.table_id=''
          this.formData.number_persons=''
          this.formData.date=''
          this.formData.time=''

        },


        addEditOrder(e){

            e.preventDefault();
            axios.post(this.URL,this.formData).then((response)=>{
                if(response.data.items){
                   swal({
                    text: "تم حفظ التغييرات بنجاح",
                    icon: "success",
                    timer: 2000,
                    button: false
                    }); 
                    this.closeModal()
                    this.getOrder()           

                }else{
                    swal({
                    text: response.data.message,
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }                   
                
            })
        },


        getOrder(){
            axios.get('Order/getAllItems?page='+ this.currentPage).then(response => {
                if(response.data){
                  let data = response.data.items
                  this.totalPages=Math.ceil(data.total/data.per_page)
                    this.items = data;
                    // console.log(data)
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });
        },


        getOrderById(){
            axios.get('Order/getById', { params: { ID: this.ID } }).then(response => {
                if(response.data){
                  let data = response.data.items
                  let translations = response.data.items.translations
                   this.formData = data;
                this.getFloorByIdFromSelectBranch()
                this.getTableByIdFromSelectFloor()

                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });
        },

        deleteOrder(id) {
            swal({
                  title: "Are you sure?",
                  text: "Once deleted, you will not be able to recover this imaginary item!",
                  icon: "warning",
                  buttons: true,
                  dangerMode: true,
                }).then((result) => {
              if (result) {
                axios.delete('Order/deleteItem/'+id)
                    .then((response)=> {
                            if(response.data.code == 200){
                                swal(
                                  'Deleted!',
                                  'Item deleted successfully',
                                  'success'
                                )
                                this.getOrder()           

                            }else{
                                swal({
                                  icon: 'error',
                                  title: 'Oops...',
                                  text: 'Something went wrong!',
                                })

                            }
                           
                    

                    }).catch(() => {
                        swal({
                          icon: 'error',
                          title: 'Oops...',
                          text: 'Something went wrong!',
                        })
                    })
                }

            })
        },



        // getFloorByIdFromSelectBranch(){
        //     // axios.get('Floors/getAllByBranchID?branch_id='+ this.formData.branch_id).then(response => {
        //     axios.get('Floors/getAllItems?pagination=0').then(response => {
        //         if(response.data){
        //           let data = response.data.items
        //           console.log(data)
        //         this.floors = data;
        //         }else{
        //              swal({
        //             text: 'Error happens',
        //             icon: 'error',
        //             timer: false,
        //             button: true
        //             });
        //         }
        //     }).catch((error)=>{

        //             swal({
        //             text: 'Error happens',
        //             icon: 'error',
        //             timer: false,
        //             button: true
        //             });         
        //     });
        // },
        

        // getTableByIdFromSelectFloor(){
        //     axios.get('Table/getAllByFloorID?floor_id='+ this.formData.floor_id).then(response => {
        //         if(response.data){
        //           let data = response.data.items
        //         this.tables = data;
        //         }else{
        //              swal({
        //             text: 'Error happens',
        //             icon: 'error',
        //             timer: false,
        //             button: true
        //             });
        //         }
        //     }).catch((error)=>{

        //             swal({
        //             text: 'Error happens',
        //             icon: 'error',
        //             timer: false,
        //             button: true
        //             });         
        //     });
        // },
       


       },

       created(){

            this.languages = JSON.parse(localStorage.getItem("languages"))
            // this.$lang.setLocale('ar')
            // alert(this.$lang.getLocale())
            this.getOrder()
            // this.getFloorByIdFromSelectBranch()
            // this.getTableByIdFromSelectFloor()


            // axios.get('Branch/getAllItems', { params: { pagination: 0 } }).then(response => {
            //     if(response.data){
            //       let data = response.data.items
            //       this.branches = data;
                
            //     }else{
            //          swal({
            //         text: 'Error happens',
            //         icon: 'error',
            //         timer: false,
            //         button: true
            //         });
            //     }
            // }).catch((error)=>{

            //         swal({
            //         text: 'Error happens',
            //         icon: 'error',
            //         timer: false,
            //         button: true
            //         });         
            // });


           
       },
       mounted(){

       }
    }


   
</script>
<style src="vue-sliding-pagination/dist/style/vue-sliding-pagination.css"></style>
<style>
    ol, p, ul {
        line-height: 1.0;
    }


    .c-sliding-pagination__list-element {
        
        padding: 0.5em !important;
        border-radius: 0.6em !important;
        margin: 1px 2px 1px 4px !important;
    }


</style>