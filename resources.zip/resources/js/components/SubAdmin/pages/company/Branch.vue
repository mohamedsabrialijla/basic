<template>
    <div>
         <div class="row">
            <div class="col-12">
                <div class="portlet parcels latest-parcels">
                    <div class="portlet-head">
                        <div class="portlet-head-label">
                            <div class="portlet-head-icon">
                                <i class="icon icon-settings"></i>
                            </div>
                            <h3 class="portlet-head-title">
                                االفروع 
                            </h3>
                        </div>

                        <div class="portlet-head-btn">
                            <a href="#" class="btn btn-primary btn-info" @click="getModal()">
                                <i class="icon icon-add icon-text"></i>
                                  اضافة فرع
                            </a>
                        </div>

                    </div>
                    <div class="portlet-body">
                        <form>
                            <div class="parcels-content mt-2">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="dtable">
                                            <table class="table d-table">
                                                <thead>
                                                    <th>#</th>
                                                    <th>الاسم </th>
                                                    <th>العلامة التجارية </th>
                                                    <th>الحالة </th>
                                                    <th>التاريخ</th>
                                                    <th width="170">تفعيل الحجوزات</th>
                                                    <th width="170">تفعيل نقاط البيع</th>
                                                    <th>الاجراءات</th>

                                                </thead> 

                                                <tbody>
                                                    <tr v-for="item,index in items.data" :key="item.id">
                                                        <td>{{index+1}}</td>
                                                        <td>{{item.name}}</td>
                                                        <td>{{item.brand.name}}</td>
                                                        <td>
                                                            <span v-if="item.status =='active'" class="badge badge-pill badge-success">
                                                                {{item.status}}
                                                            </span> 
                                                            <span v-else class="badge badge-pill badge-danger">
                                                                {{item.status}}
                                                            </span> 
                                                        </td>
                                                        <td>{{item.created_at}}</td>
 
                                                        <td>
                                                            <div class="form-group col-6">
                                                                 <div class="cst-switch">
                                                                    <input v-if="item.status_reservation == 'active'" checked type="checkbox" id="activeDisStore"  v-model="formData['status_reservation_' + item.id]" @change="changeType(item.id,'reservation','not_active')">


                                                                    <input v-else="item.status_reservation == 'not_active'"  type="checkbox" id="activeDisStore"  v-model="formData['status_reservation_' + item.id]" @change="changeType(item.id,'reservation','active')">


                                                                </div>
                                                            </div>   

                                                        </td>


                                                         <td>
                                                            <div class="form-group col-6">
                                                                 <div class="cst-switch" >
                                                                    <input v-if="item.status_point_sale == 'active'" checked type="checkbox" id="activeDisStore"  v-model="formData['status_point_sale_' + item.id]" @change="changeType(item.id,'sale','not_active')">


                                                                    <input v-else="item.status_point_sale == 'not_active'"  type="checkbox" id="activeDisStore"  v-model="formData['status_point_sale_' + item.id]" @change="changeType(item.id,'sale','active')">


                                                                </div>
                                                            </div>   

                                                        </td>
                                                        
                                                        
                                                        <td>
                                                            <a href="#" v-if="item.status=='active'"
                                                                class="btn red-btn btn-icon"
                                                                @click="deleteBranch(item.id,item.status)"
                                                                 title="حذف">
                                                                <i class="icon icon-delete"></i>
                                                            </a>


                                                             <a style="background-color:#49c55f" href="#" v-if="item.status !='active'"
                                                                class="btn green-btn btn-icon"
                                                                @click="deleteBranch(item.id,item.status)"
                                                                 title="حذف">
                                                                <i class="icon icon-approval"></i>
                                                            </a>

                                                          

                                                            <span class="d-inline-block"
                                                                 title="تعديل">
                                                                <a href="#" class="btn green-btn btn-icon"
                                                                    @click="getModalEdit(item)">
                                                                    <i
                                                                        class="icon icon-pencil-edit-button"></i>
                                                                </a>
                                                            </span>


                                                            <span class="d-inline-block"
                                                                 title="أوقات العمل">
                                                                <a href="#" class="btn green-btn btn-icon" @click="getModalTimeWork(item)">
                                                                    <i
                                                                        class="icon icon-clock"></i>
                                                                </a>
                                                            </span>

                                                            <span class="d-inline-block"
                                                                 title="كوبونات الخصم">
                                                                <a href="#" class="btn green-btn btn-icon" @click="getModalCoupon(item)">
                                                                    <i
                                                                        class="icon icon-coupon"></i>
                                                                </a>
                                                            </span>

                                                        </td>
                                                    </tr>
                                                    <tr v-if="totalPages == 0">
                                                        <td colspan="6" style="text-align:center">لا يوجد نتائج </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>


                                            <sliding-pagination v-if="totalPages != 0"
                                              :current="currentPage"
                                              :total="totalPages"
                                              @page-change="pageChangeHandler"
                                            ></sliding-pagination>


                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>






<!-- modal add branch -->
<div class="modal fade main-modal add-branch" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-blg" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title d-flex">
                <i class="icon icon-add"></i>
                 {{titleModal}}</h5>
            <button type="button" class="close" @click="closeModal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
             <form  @submit="addEditBranch" enctype="multipart/form-data">
                <div class="row">
                    <div class="alert alert-danger" role="alert" v-if="errors.length">
                        <b style="font-weght">يرجي التاكد من البيانات  :</b>
                        <ul>
                          <li v-for="error in errors">{{ error }}</li>
                        </ul>
                    </div>
                    
                </div>

                <div class="tab-content mt-4" id="myTabContent">
                    <div class="tab-pane fade show active" id="storeInformation"
                        role="tabpanel" aria-labelledby="storeInformation-tab">
                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex">
                                <div class="form-group col-6" v-for="lang,index in languages">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        الاسم  ({{lang.name}})
                                    </label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control"
                                             v-model="formData['name_' + lang.lang]" value=""
                                            placeholdr="'name'+lang.name">
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex">
                               
                                <div class="form-group col-6" v-for="lang,index in languages">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        العنوان  ({{lang.name}})
                                    </label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control"
                                             v-model="formData['address_' + lang.lang]" value=""
                                            placeholdr="'address'+lang.name">
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex"> 
                                <div class="form-group col-6">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      المدينة 

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <select class="form-control select-tag "  v-model="formData.city_id"  >
                                            <option v-for="city in cities" v-bind:value="city.id">{{city.name}}</option>
                                           
                                        </select>
                                        

                                    </div>
                                </div>


                                 <div class="form-group col-6">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      العلامة التجارية 

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <select class="form-control select-tag "  v-model="formData.brand_id"  >
                                            <option v-for="brand in brands" v-bind:value="brand.id">{{brand.name}}</option>
                                           
                                        </select>
                                        

                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="row">
                       
                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        IP الطابعة
                                    </label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control"
                                             v-model="formData.ip_printer" value=""
                                            placeholdr="IP الطابعة">
                                    </div>
                                </div>


                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        فترة زمنية بين الحجزين (دقيقة)
                                    </label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control"
                                             v-model="formData.interval_booking" value=""
                                            placeholdr="الفترة الزمنية بين كل حجز والاخر">
                                    </div>
                                </div>



                                   <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        الفترة الزمنية المسموحة لكنسلة الحجز  (دقيقة)
                                    </label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control"
                                             v-model="formData.cancel_booking" value=""
                                            placeholdr="الفترة الزمنية بين كل حجز والاخر">
                                    </div>
                                </div>




                        </div>  





                              

      

                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex"> 



                                <div class="product-switch flex-label">
                           
                                    <label for="activeDisStore" style="width:200px;">السماح بدمج الطاولات بشكل اوتماتيكي </label>

                                </div>


                                <div class="form-group col-6">
                                         <div class="cst-switch">
                                        <input type="checkbox" id="activeDisStore" checked="" v-model="formData.merge">
                                    </div>
                                </div>  




                                <div class="form-group col-6">
                                    <div class="shipments-name">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="ship2552" v-model="formData.self">
                                            <label class="custom-control-label" for="ship2552">قبول آلي للطلبات</label>
                                        </div>

                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="row">

                            <!-- <AddGoogleMap /> -->


                           <!--  <h2>تحديد المكان ع الخريطة </h2>
                            <label>
                            <gmap-autocomplete @place_changed="initMarker"></gmap-autocomplete>
                            <button @click="addLocationMarker">Add</button>
                            </label>
                            <br/> -->
 

                           <!--  <gmap-map
                                :zoom="14"    
                                :center="center"
                                style="width:100%;  height: 600px;"
                              >
                              <gmap-marker
                                :key="index"
                                v-for="(m, index) in locationMarkers"
                                :position="m.position"
                                @click="center=m.position"
                              ></gmap-marker>
                            </gmap-map> -->
                        </div>
                    


                    </div>
                </div>

              
                <div class="btn-container">
                    <a class="btn btn-outline-light"  @click="closeModal">الغاء</a>
                    <button type="submit"
                        class="btn btn-primary" :disabled="value">حفظ</button>
                </div>
            </form>
        </div>
    </div>
    </div>
</div>
<!-- end branch modal -->


<!-- modal add TimeWork -->
<div class="modal fade main-modal time_work" id="myModalTimeWork" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-blg" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title d-flex">
                <i class="icon icon-clock"></i>
                  ساعات العمل </h5>
            <button type="button" class="close" @click="closeModalTime" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <TimeWork :Item='ItemSelect'></TimeWork>
        </div>
    </div>
    </div>
</div>
<!-- end TimeWork modal -->




<!-- modal add Coupon -->
<div class="modal fade main-modal coupon" id="myModalCoupon" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" ref="vuemodal">
    <div class="modal-dialog modal-dialog-centered modal-blg" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title d-flex">
                <i class="icon icon-clock"></i>
                  كوبونات الخصم  </h5>
            <button type="button" class="close" @click="closeCoupon" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <Coupon :Item='ItemSelect' v-if="C_active==1"></Coupon>
        </div>
    </div>
    </div>
</div>
<!-- end Coupon modal -->


   </div>
</template>
 
 

<script>

    import SlidingPagination from 'vue-sliding-pagination'
    import TimeWork from './TimeWork'
    import Coupon from './Coupon'

    export default {
        components: { SlidingPagination,TimeWork,Coupon},
        name : 'Branch',
        data(){
            return {
                value:false,
                count_branch : 0,
                C_active:0,
                ItemSelect:{},
                center: { 
                lat: 39.7837304,
                lng: -100.4458825
                },
                locationMarkers: [],
                locPlaces: [],
                existingPlace: null,
                titleModal:'',
                cities:[],
                brands:[],
                currentPage: 1,
                totalPages: 1,
                items:[],
                languages:[],
                errors: [],
                ID:'',
                URL:'Branch/createItem',
                URLChangeStatus:'Branch/changeTypeStatus',
                 
                formData:{
                  name_ar:null,
                  name_en:null,
                  address_ar:null,
                  address_en:null,
                  self:null,
                  city_id:null,
                  brand_id:null,
                  lon:null,
                  lan:null,
                  ip_printer:null,
                  interval_booking:null,
                  merge:null,
                  cancel_booking:null,
                  
                },

                }
            },
        methods:{
            pageChangeHandler(selectedPage) {
                this.currentPage = selectedPage
                this.getBranch()
            },
           
          
            getModal(){
                this.resetBranch();
                $('#myModal').modal('show');
                this.titleModal = 'اضافة فرع '
            },


            changeType(id,type,status){
                
                var form = new FormData();
                  form.append('id', id);
                  form.append('type', type);
                  form.append('status', status);

                axios.post(this.URLChangeStatus,form).then((response)=>{
                    if(response.data.items){
                       swal({
                        text: "تم حفظ التغييرات بنجاح",
                        icon: "success",
                        timer: 2000,
                        button: false
                        }); 
                        this.getBranch()           

                    }else{
                        swal({
                        text: response.data.message,
                        icon: 'error',
                        timer: false,
                        button: true
                        });
                    }                   
                    
                })
            },


            getModalEdit(item){
                this.resetBranch();
                $('#myModal').modal('show');
                this.titleModal = 'تعديل فرع '
                this.ID = item.id
                this.URL = 'Branch/editItem'
                this.getBranchById() 
                
            },

            closeModal(){
                $('#myModal').modal('hide');
                this.URL = 'Branch/createItem'
                this.ID = null
            },

            resetBranch(){
              this.URL = 'Branch/createItem'
              this.formData.name_ar=''
              this.formData.name_en=''
              this.formData.address_ar=''
              this.formData.address_en=''
              this.formData.self=''
              this.formData.lan=''
              this.formData.lon=''
              this.ip_printer=''
              this.interval_booking=''
              this.merge=''
              this.cancel_booking=''
            },


            addEditBranch(e){
                this.value=true
              e.preventDefault()
                axios.post(this.URL,this.formData).then((response)=>{
                    this.value=false
                    if(response.data.items){
                       swal({
                        text: "تم حفظ التغييرات بنجاح",
                        icon: "success",
                        timer: 2000,
                        button: false
                        }); 
                        this.closeModal()
                        this.getBranch()
                        location.reload() 
                        if(this.count_branch == 0){
                           location.reload()
                        }         

                    }else{
                        swal({
                        text: response.data.message,
                        icon: 'error',
                        timer: false,
                        button: true
                        });
                    }


                })
            },
 

            getBranch(){
                axios.get('Branch/getAllItems?page='+ this.currentPage).then(response => {
                    if(response.data){
                      let data = response.data.items
                      this.totalPages=Math.ceil(data.total/data.per_page)
                      this.items = data
                      this.count_branch = data.total


                    }else{
                         swal({
                        text: 'Error happens',
                        icon: 'error',
                        timer: false,
                        button: true
                        });
                    }
                }).catch((error)=>{

                        swal({
                        text: 'Error happens',
                        icon: 'error',
                        timer: false,
                        button: true
                        });         
                });
            },


            getBranchById(){
                axios.get('Branch/getById', { params: { ID: this.ID } }).then(response => {
                    if(response.data){
                      let data = response.data.items
                      let translations = response.data.items.translations
                       this.formData = data;
                        translations.forEach((element) => { 
                              this.formData['name_'+element.locale] = element.name; 
                              this.formData['address_'+element.locale] = element.address ;
                        });

                    }else{
                         swal({
                        text: 'Error happens',
                        icon: 'error',
                        timer: false,
                        button: true
                        });
                    }
                }).catch((error)=>{

                        swal({
                        text: 'Error happens',
                        icon: 'error',
                        timer: false,
                        button: true
                        });         
                });
            },

            deleteBranch(id,status) {


                var a = "هل انت متأكد من عملية الغاء التفعيل ?"
                var b = "سيتم الغاء تفعيل البراند بالكامل من اللوحة  !"
                var c ='تم الغاء التفعيل , سوف يتم تحميل فرع جديد '
                var d = 'تم الغاء التفعيل بنجاح'
                if(status=='not_active'){
                    var a = "هل انت متأكد من عملية التفعيل ?"
                    var b = "سيتم  تفعيل البراند بالكامل من اللوحة  !"
                    var c ='تم  التفعيل , سوف يتم تحميل فرع جديد '
                    var d = 'تم  التفعيل بنجاح'
                }



                swal({
                      title: a,
                      text: b,
                      icon: "warning",
                      buttons: true,
                      dangerMode: true,
                    }).then((result) => {
                  if (result) {
                    axios.delete('Branch/deleteItem/'+id)
                        .then((response)=> {
                                if(response.data.code == 200){
                                    swal(
                                 c,
                                  d,
                                  'success'
                                )
                                    // this.getBranch()  
                                    location.reload()            

                                }else{
                                    swal({
                                      icon: 'error',
                                      title: 'Oops...',
                                      text: 'Something went wrong!',
                                    })

                                }
                               
                        

                        }).catch(() => {
                            swal({
                              icon: 'error',
                              title: 'Oops...',
                              text: 'Something went wrong!',
                            })
                        })
                    }

                })
            },
            
            initMarker(loc) {
              this.existingPlace = loc;
            },
            addLocationMarker() {
              if (this.existingPlace) {
                const marker = {
                  lat: this.existingPlace.geometry.location.lat(),
                  lng: this.existingPlace.geometry.location.lng()
                };
                this.locationMarkers.push({ position: marker });
                this.locPlaces.push(this.existingPlace);
                this.center = marker;
                this.existingPlace = null;
              }
            },
            locateGeoLocation: function() {
              navigator.geolocation.getCurrentPosition(res => {
                this.center = {
                  lat: res.coords.latitude,
                  lng: res.coords.longitude
                };
              });
            },




          //here you are function time work
           closeModalTime(){
                $('#myModalTimeWork').modal('hide');
            }, 
            getModalTimeWork(item){
                this.ItemSelect = item
                $('#myModalTimeWork').modal('show');
            },


 
            //here you are function Coupon
           closeCoupon(){
                this.C_active =0
                $('#myModalCoupon').modal('hide');
            }, 
            getModalCoupon(item){
                this.ItemSelect = item
                this.C_active = 1
                $('#myModalCoupon').modal('show');
            },




        },

       created(){

            this.languages = JSON.parse(localStorage.getItem("languages"))
            this.getBranch()


            axios.get('City/getAllItems').then(response => {
                if(response.data){
                  let data = response.data.items
                  this.cities = data;
                
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });           
            }); 


            axios.get('Mark/getAllItems', { params: { pagination: 0 } }).then(response => {
                if(response.data){
                  let data = response.data.items
                  this.brands = data;
                
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });           
            });   
       }, 

       mounted(){
        this.locateGeoLocation();
        
       }
    }


   
</script>
<style src="vue-sliding-pagination/dist/style/vue-sliding-pagination.css"></style>
<style>
.custom-control {
    padding-right: 2.5rem;
    padding-left: 0;
    margin-top: 33px;
}


    ol, p, ul {
        line-height: 1.0;
    }


    .c-sliding-pagination__list-element {
        
        padding: 0.5em !important;
        border-radius: 0.6em !important;
        margin: 1px 2px 1px 4px !important;
    }


</style>