<template>
    <div>
         <div class="row">
            <div class="col-12">
                <div class="portlet parcels latest-parcels">
                    <div class="portlet-head">
                        <div class="portlet-head-label">
                            <div class="portlet-head-icon">
                                <i class="icon icon-settings"></i>
                            </div>
                            <h3 class="portlet-head-title">
                                كوبونات الخصم
                            </h3>
                        </div>

                        <div class="portlet-head-btn">
                            <a href="#" class="btn btn-primary btn-info" @click="getModalCoupon()">
                                <i class="icon icon-add icon-text"></i>
                                  اضافة  كوبون خصم
                            </a>
                        </div>

                    </div>
                    <div class="portlet-body">
                        <form>
                            <div class="parcels-content mt-2">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="dtable">
                                            <table class="table d-table">
                                                <thead>
                                                    <th>#</th>
                                                    <th>الاسم</th>
                                                    <th>الكود</th>
                                                    <th>الحالة </th>
                                                    <th>التاريخ</th>
                                                    <th>الاجراءات</th>

                                                </thead>

                                                <tbody>
                                                    <tr v-for="item,index in items.data" :key="item.id">
                                                        <td>{{index+1}}</td>
                                                        <td>{{item.name}}</td>
                                                        <td>{{item.code}}</td>
                                                        <td>
                                                            <span v-if="item.status =='active'" class="badge badge-pill badge-success">
                                                                {{item.status}}
                                                            </span> 
                                                            <span v-else class="badge badge-pill badge-danger">
                                                                {{item.status}}
                                                            </span> 
                                                        </td>
                                                        <td>{{item.fromDate}}/{{item.endDate}}</td>
                                                        
                                                        
                                                        <td>
                                                            <a href="#"
                                                                class="btn red-btn btn-icon"
                                                                @click="deleteItem(item.id)"
                                                                 title="حذف">
                                                                <i class="icon icon-delete"></i>
                                                            </a>

                                                          

                                                            <span class="d-inline-block"
                                                                 title="تعديل">
                                                                <a href="#" class="btn green-btn btn-icon"
                                                                    @click="getModalEdit(item)">
                                                                    <i
                                                                        class="icon icon-pencil-edit-button"></i>
                                                                </a>
                                                            </span>



                                                        </td>
                                                    </tr>
                                                    <tr v-if="totalPages == 0">
                                                        <td colspan="6" style="text-align:center">لا يوجد نتائج </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>


                                            <sliding-pagination v-if="totalPages != 0"
                                              :current="currentPage"
                                              :total="totalPages"
                                              @page-change="pageChangeHandler"
                                            ></sliding-pagination>


                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>






<!-- modal add Item -->
<div class="modal fade main-modal" id="myModalCouponPage" tabindex="-1" role="dialog" aria-labelledby="myModal2Label" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-MID" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title d-flex">
                <i class="icon icon-add"></i>
                 {{titleModal}}</h5>
            <button type="button" class="close" @click="closeModalCoupon" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
             <form  @submit="addEditItem" enctype="multipart/form-data">
                <div class="row">
                    <div class="alert alert-danger" role="alert" v-if="errors.length">
                        <b style="font-weght">يرجي التاكد من البيانات  :</b>
                        <ul>
                          <li v-for="error in errors">{{ error }}</li>
                        </ul>
                    </div>
                    
                </div>

                <div class="tab-content mt-4" id="myTabContent">
                    <div class="tab-pane fade show active" id="storeInformation"
                        role="tabpanel" aria-labelledby="storeInformation-tab">
                       

                        
                         <div class="row">
                        <div class="col-12">
                            <div class="portlet">
                                <div class="portlet-body">
                                        <div class="form-group row">
                                            <label for="couponsName" class="col-sm-3 flex-label">
                                                الاسم
                                            </label>
                                            <div class="col-sm-9">
                                                <input type="text" v-model="formData.name" class="form-control" id="couponsName"
                                                    placeholder="قم باضافة اسم الكوبون" required>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="couponsCode" class="col-sm-3 flex-label">
                                                الكود
                                            </label>
                                            <div class="col-sm-9">
                                                <input type="text" v-model="formData.code" class="form-control" id="couponsCode"
                                                    placeholder="قم باضافة كود الكوبون" required>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="couponsValue" class="col-sm-3 flex-label">
                                                قيمة الكوبون
                                            </label>
                                            <div class="col-sm-9">
                                                <div class="coupons-options">
                                                    <div class="coupons-value-radio">
                                                        <div class="custom-control custom-radio custom-control-inline">
                                                            <input type="radio" id="fixedAmount" name="couponValue" @change="getType(0)"
                                                                class="custom-control-input" 
                                                                checked  >
                                                            <label class="custom-control-label" for="fixedAmount">مبلغ
                                                                ثابت</label>
                                                        </div>
                                                        <div class="custom-control custom-radio custom-control-inline">
                                                            <input type="radio" id="rate"  
                                                                name="couponValue" class="custom-control-input" @change="getType(1)" >
                                                            <label class="custom-control-label" for="rate">نسبة</label>
                                                        </div>
                                                    </div>

                                                    <div class="coupons-value-quantity coupons-options-amount" v-if="formData.percentage == 0">
                                                        <div class="cs-quantity cs-quantity-price">
                                                            <span class="plus" @click="addOne">
                                                                <div>+</div>
                                                            </span>
                                                            <input type="number" v-model="formData.value"
                                                                class="input-text qty text" step="1" min="0" max=""
                                                              title="Qty" size="4" pattern="[0-9]*"
                                                                inputmode="numeric">
                                                            <div class="currency">ر.س</div>
                                                            <span class="minus" @click="minusOne">
                                                                <div>-</div>
                                                            </span>
                                                        </div>
                                                    </div>

                                                    <div class="coupons-value-quantity " v-else>
                                                        <div class="cs-quantity cs-quantity-price">
                                                            <span class="plus" @click="addOne">
                                                                <div>+</div>
                                                            </span>
                                                            <input type="number" v-model="formData.value"
                                                                class="input-text qty text" step="1" min="0" max="100"
                                                                  title="Qty" size="4"
                                                                pattern="[0-9]*" inputmode="numeric">
                                                            <div class="currency">%</div>
                                                            <span class="minus" @click="minusOne">
                                                                <div>-</div>
                                                            </span>
                                                        </div>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>

                                        <div class="form-group row">
                                        
                                            <div class="col-sm-6">
                                                <input type="date" class="form-control datepicker" id="startData" v-model="formData.fromDate"
                                                    placeholder="من تاريخ" 
                                                    data-toggle="datepicker"
                                                    >
                                                <span class="calendar">
                                                    <i class="fa fa-calendar" aria-hidden="true"></i>
                                                </span>
                                            </div>

                                            <div class="col-sm-6">
                                                <input type="date" class="form-control datepicker" id="endDate" v-model="formData.endDate" 
                                                    placeholder="الى تاريخ"
                                                    data-toggle="datepicker">
                                                <span class="calendar">
                                                    <i class="fa fa-calendar" aria-hidden="true"></i>
                                                </span>
                                            </div>
                                        </div>





                                     
                                        <div class="form-group row numberCouponUses">
                                            <label class="col-sm-5 flex-label">
                                                عدد استخدامات الكوبون
                                            </label>
                                            <div class="col-sm-7">
                                                <div class="cs-quantity cs-quantity-price">
                                                    <span class="plus">
                                                        <div>+</div>
                                                    </span>
                                                    <input type="number" id="quantity_2" class="input-text qty text" v-model="formData.uses"
                                                        step="1" min="0"    title="Qty" size="4"
                                                        pattern="[0-9]*" inputmode="numeric">

                                                    <span class="minus">
                                                        <div>-</div>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>

                                        

                                        <div class="form-group row">
                                            <label class="col-sm-3 flex-label" for="couponProducts">
                                                منتجات الكوبون
                                            </label>
                                            <div class="col-sm-9 select-tag-wrapper">
                                                <select class="form-control select-tag" id="emailTargetGroup" v-model="formData.type">
                                                    <option value="1">منتجات</option>
                                                    <option value="2">حجوزات</option>
                                                    <option value="3">توصيل</option>
                                                   
                                                </select>
                                            </div>
                                        </div>

                                    

                                </div>
                            </div>
                        </div>
                    </div>


                        <div class="product-switch flex-label">
                           
                            <label for="activeDisStore">تفعيل</label>

                        </div>


                        <div class="form-group col-6">
                                 <div class="cst-switch">
                                <input type="checkbox" id="activeDisStore" checked="" v-model="formData.status">
                            </div>
                        </div>   

                    

                    


                    </div>
                </div>

              
                <div class="btn-container">
                    <a class="btn btn-outline-light"  @click="closeModalCoupon">الغاء</a>
                    <button type="submit"
                        class="btn btn-primary">حفظ</button>
                </div>
            </form>
        </div>
    </div>
    </div>
</div>
<!-- end Item modal -->


 

   </div>
</template>
 

<script>

    import SlidingPagination from 'vue-sliding-pagination'

    export default {
        components: { SlidingPagination},
        name : 'Coupon',
        props:['Item'],

        data(){
            return {
                
                titleModal:'',
                currentPage: 1,
                totalPages: 1,
                items:[],
                languages:[],
                errors: [],
                ID:'',
                URL:'Coupon/createItem',
                 
                formData:{
                  fromDate:null,
                  endDate:null,
                  percentage:0,
                  name:null,
                  code:null,
                  type:null,
                  status:null,
                  value:5,
                  uses:5,
                },

                }
            },
        methods:{

            

            addOne(){
                this.formData.value = this.formData.value + 1 
            },
            minusOne(){
                this.formData.value = this.formData.value - 1 
            },

            addUses(){
                this.formData.uses = this.formData.uses + 1 
            },
            minusUses(){
                this.formData.uses = this.formData.uses - 1 
            },


            pageChangeHandler(selectedPage) {
                this.currentPage = selectedPage
                this.getItem()
            },
           
          
            getModalCoupon(){
                this.resetItem();
                $('#myModalCouponPage').modal('show');
                this.titleModal = 'اضافة كوبون الخصم'
                this.formData.value = 5
                this.formData.percentage = 0
            },


            getModalEdit(item){
                this.resetItem();
                $('#myModalCouponPage').modal('show');
                this.titleModal = 'تعديل كوبون الخصم'
                this.ID = item.id
                this.URL = 'Coupon/editItem'
                this.getItemById() 
                
            },

            closeModalCoupon(){
                $('#myModalCouponPage').modal('hide');
                this.URL = 'Coupon/createItem'
                this.ID = null
            },

            resetItem(){
              this.URL = 'Coupon/createItem'
              this.formData.fromDate=''
              this.formData.endDate=''
              this.formData.type=''
              this.formData.status=''
              this.formData.code=''
              this.formData.name=''
              this.formData.percentage=''
              this.formData.value=''
            },


            addEditItem(e){

              e.preventDefault()
              this.formData.branch_id = this.Item.id

                console.log(this.formData)
                axios.post(this.URL,this.formData).then((response)=>{
                    if(response.data.items){
                       swal({
                        text: "تم حفظ التغييرات بنجاح",
                        icon: "success",
                        timer: 2000,
                        button: false
                        }); 
                        this.closeModalCoupon()
                        this.getItem()           

                    }else{
                        swal({
                        text: response.data.message,
                        icon: 'error',
                        timer: false,
                        button: true
                        });
                    }                   
                    
                })
            },


            getItem(){
                axios.get('Coupon/getAllItems?branch_id='+this.Item.id +'&page='+ this.currentPage).then(response => {
                    if(response.data){
                      let data = response.data.items
                      this.totalPages=Math.ceil(data.total/data.per_page)
                      this.items = data;
                    }else{
                         swal({
                        text: 'Error happens',
                        icon: 'error',
                        timer: false,
                        button: true
                        });
                    }
                }).catch((error)=>{
                        swal({
                        text: 'Error happens',
                        icon: 'error',
                        timer: false,
                        button: true
                        });         
                });
            },


            getItemById(){
                axios.get('Coupon/getById', { params: { ID: this.ID } }).then(response => {
                    if(response.data){
                      let data = response.data.items
                       this.formData = data;
                    }else{
                         swal({
                        text: 'Error happens',
                        icon: 'error',
                        timer: false,
                        button: true
                        });
                    }
                }).catch((error)=>{

                        swal({
                        text: 'Error happens',
                        icon: 'error',
                        timer: false,
                        button: true
                        });         
                });
            },

            deleteItem(id) {
                swal({
                      title: "Are you sure?",
                      text: "Once deleted, you will not be able to recover this imaginary item!",
                      icon: "warning",
                      buttons: true,
                      dangerMode: true,
                    }).then((result) => {
                  if (result) {
                    axios.delete('Coupon/deleteItem/'+id)
                        .then((response)=> {
                                if(response.data.code == 200){
                                    swal(
                                      'Deleted!',
                                      'Item deleted successfully',
                                      'success'
                                    )
                                    this.getItem()           

                                }else{
                                    swal({
                                      icon: 'error',
                                      title: 'Oops...',
                                      text: 'Something went wrong!',
                                    })

                                }
                               
                        

                        }).catch(() => {
                            swal({
                              icon: 'error',
                              title: 'Oops...',
                              text: 'Something went wrong!',
                            })
                        })
                    }

                })
            },


          

            getType(type){
                this.formData.percentage = type;
                
            },



            
           


        },

       created(){
            this.languages = JSON.parse(localStorage.getItem("languages"))
            this.getItem()

       },
       mounted(){
       }
    }


   
</script>

<style src="vue-sliding-pagination/dist/style/vue-sliding-pagination.css"></style>
<style>
.custom-control {
    padding-right: 2.5rem;
    padding-left: 0;
    margin-top: 33px;
}


    ol, p, ul {
        line-height: 1.0;
    }


    .c-sliding-pagination__list-element {
        
        padding: 0.5em !important;
        border-radius: 0.6em !important;
        margin: 1px 2px 1px 4px !important;
    }

    .custom-control {
    margin-top: 16px !important;}

    .datepicker{
        padding-left: 47px;
    }


</style>
