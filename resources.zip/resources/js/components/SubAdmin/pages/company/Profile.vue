<template>
    <div>
        <div class="row">
            <div class="col-12">
                <div class="portlet">
                    <div class="portlet-head">
                        <div class="portlet-head-label">
                            <div class="portlet-head-icon">
                                <i class="icon icon-shop"></i>
                            </div>
                            <h3 class="portlet-head-title">
                                معلومات الشركة
                            </h3>
                        </div>
                    </div>
                    <div class="portlet-body">

                          <div class="alert alert-danger" role="alert" v-if="errors.length">
                            <b style="font-weght">يرجي التاكد من البيانات  :</b>
                            <ul>
                              <li v-for="error in errors">{{ error }}</li>
                            </ul>
                          </div>



                        <div class="row">
                            <div class="col-12">
                                <form  @submit="editInfoCompany" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="col-lg-7 col-12 mx-auto">
                                            <div class="store-img">

                                               <!--  <div class="avatar-picture">
                                                    <div class="image-input image-input-outline"
                                                        id="imgUserProfile">
                                                        <div class="image-input-wrapper"
                                                            style="background-image: url('/assets/companies/img/store-logo.jpg');">
                                                        </div>

                                                        <label class="btn" data-toggle="tooltip"
                                                            data-placement="top" title="تعديل صورة المتجر">

                                                            <i class="icon icon-pencil-edit-button"></i>
                                                            <input type="file" name="profile_avatar"
                                                                id="changeImg" accept=".png, .jpg, .jpeg">
                                                            <input type="button" value="Upload"
                                                                id="uploadButton" />


                                                        </label>

                                                    </div>
                                                </div> -->
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-7 col-12 mx-auto">
                                            <ul class="nav nav-tabs tab-nav store-info-tab" id="myTab"
                                                role="tablist">
                                                <li class="nav-item">
                                                    <a class="nav-link active" id="storeInformation-tab"
                                                        data-toggle="tab" href="#storeInformation"
                                                        role="tab" aria-controls="storeInformation"
                                                        aria-selected="true">
                                                        <i class="icon icon-shop"></i>
                                                        بيانات الشركة
                                                    </a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link" id="contactInformation-tab"
                                                        data-toggle="tab" href="#contactInformation"
                                                        role="tab" aria-controls="contactInformation"
                                                        aria-selected="false">
                                                        <i class="icon icon-call-answer"></i>
                                                        بيانات  شخصية
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>


                                    <div class="tab-content mt-4" id="myTabContent">
                                        <div class="tab-pane fade show active" id="storeInformation"
                                            role="tabpanel" aria-labelledby="storeInformation-tab">
                                            <div class="row">
                                                <div class="col-lg-7 col-12 mx-auto">
                                                    <div class="form-group row">
                                                        <label for="storeName" class="col-sm-3 flex-label">
                                                            اسم  الشركة بالعربي
                                                        </label>
                                                        <div class="col-sm-9">
                                                            <input type="text" class="form-control"
                                                                 v-model="formData.name_ar" value=""
                                                                placeholder="اسم  الشركة بالعربي">
                                                        </div>
                                                    </div>

                                                    <div class="form-group row">
                                                        <label for="storeName" class="col-sm-3 flex-label">
                                                            اسم الشركة بالانجليزي
                                                        </label>
                                                        <div class="col-sm-9">
                                                            <input type="text" class="form-control"
                                                                v-model="formData.name_en" value=""
                                                                placeholder="اسم  الشركة بالانجليزي">
                                                        </div>
                                                    </div> 

                                                  

                                                    <div class="form-group row">
                                                        <label for="storeLink" class="col-sm-3 flex-label">
                                                            رقم السجل التجاري
                                                        </label>
                                                        <div class="col-sm-9">
                                                            <input type="text" @keypress="isNumber($event)" v-model="formData.commercial_registration_number" class="form-control"
                                                                value="" id="storeLink"
                                                                placeholder="رقم السجل التجاري">
                                                        </div>
                                                    </div>


                                                     <div class="form-group row">
                                                        <label for="storeLink" class="col-sm-3 flex-label">
                                                            رقم الضريبة
                                                        </label>
                                                        <div class="col-sm-9">
                                                            <input type="text" @keypress="isNumber($event)" v-model="formData.tax_number" class="form-control"
                                                                value="" id="storeLink"
                                                                placeholder="رقم الضريبة">
                                                        </div>
                                                    </div>



                                                    <div class="form-group row">
                                                        <label for="storeLink" class="col-sm-3 flex-label">
                                                            العنوان
                                                        </label>
                                                        <div class="col-sm-9">
                                                            <input type="text" v-model="formData.address" class="form-control"
                                                                value="" id="storeLink"
                                                                placeholder="العنوان">
                                                        </div>
                                                    </div>

                                                   

                                            <div class="form-group row mb-4">
                                                <label for="personalPicture" class="col-sm-3 flex-label"> 
                                                صورة رقم السجل التجاري
                                                </label>
                                                <div class="col-sm-9">
                                                    <div class="avatar-picture">
                                                        <div class="image-input image-input-outline"
                                                            id="imgUserProfile">
                                                            <div id="preview">
                                                                <a :href="commercial_file_preview" target="_blank"><img v-if="commercial_file_preview" :src="commercial_file_preview" width="100" /></a>
                                                            </div>

                                                            <label class="btn" data-toggle="tooltip"
                                                                data-placement="top" >

                                                                <i class="icon icon-pencil-edit-button"></i>
                                                                <input type="file" name="profile_avatar" v-on:change="onFileChange"
                                                                    accept=".png, .jpg, .jpeg .pdf">
                                                                <input type="button" value="Upload" id="uploadButton" />


                                                            </label>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                             <div class="form-group row mb-4">
                                                <label for="personalPicture" class="col-sm-3 flex-label"> 
                                                صورة  الرقم القومي / الاقامة
                                                </label>
                                                <div class="col-sm-9">
                                                    <div class="avatar-picture">
                                                        <div class="image-input image-input-outline"
                                                            id="imgUserProfile">
                                                            <div id="preview">
                                                                <a :href="national_file_preview" target="_blank"><img v-if="national_file_preview" :src="national_file_preview" width="100" /></a>
                                                            </div>

                                                            <label class="btn" data-toggle="tooltip"
                                                                data-placement="top" >

                                                                <i class="icon icon-pencil-edit-button"></i>
                                                                <input type="file" name="profile_avatar" v-on:change="onFileChange2"
                                                                    accept=".png, .jpg, .jpeg .pdf">
                                                                <input type="button" value="Upload" id="uploadButton" />


                                                            </label>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>




                                            <div class="form-group row mb-4">
                                                <label for="personalPicture" class="col-sm-3 flex-label"> 
                                                صورة رقم الضريبة 
                                                </label>
                                                <div class="col-sm-9">
                                                    <div class="avatar-picture">
                                                        <div class="image-input image-input-outline"
                                                            id="imgUserProfile">
                                                            <div id="preview">
                                                                <a :href="tax_file_preview" target="_blank"><img v-if="tax_file_preview" :src="tax_file_preview" width="100"  /></a>
                                                            </div>

                                                            <label class="btn" data-toggle="tooltip"
                                                                data-placement="top" >

                                                                <i class="icon icon-pencil-edit-button"></i>
                                                                <input type="file" name="profile_avatar" v-on:change="onFileChange3"
                                                                    accept=".png, .jpg, .jpeg .pdf">
                                                                <input type="button" value="Upload" id="uploadButton" />


                                                            </label>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row mb-4">
                                                <label for="personalPicture" class="col-sm-3 flex-label"> 
                                                شعار الشركة 
                                                </label>
                                                <div class="col-sm-9">
                                                    <div class="avatar-picture">
                                                        <div class="image-input image-input-outline"
                                                            id="imgUserProfile">
                                                            <div id="preview">
                                                                <a :href="logo_file_preview" target="_blank"><img v-if="logo_file_preview" :src="logo_file_preview" width="100"  /></a>
                                                            </div>

                                                            <label class="btn" data-toggle="tooltip"
                                                                data-placement="top" >

                                                                <i class="icon icon-pencil-edit-button"></i>
                                                                <input type="file" name="profile_logo" v-on:change="onFileChange4"
                                                                    accept=".png, .jpg, .jpeg .pdf">
                                                                <input type="button" value="Upload" id="uploadButton" />


                                                            </label>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                                 
                                                </div>
                                            </div>


                                            <div class="btn-container">
                                                <router-link to="/subadmin/home" class="btn btn-outline-light">الغاء</router-link>
                                                <button type="submit"
                                                    class="btn btn-primary">حفظ</button>
                                            </div>


                                        </div>
                                        <div class="tab-pane fade " id="contactInformation" role="tabpanel"
                                            aria-labelledby="contactInformation-tab">

                                            <div class="row">
                                                <div class="col-lg-7 col-12 mx-auto">
                                                    <div class="form-group row">
                                                        <label for="phoneNumber"
                                                            class="col-sm-3 flex-label">
                                                            الاسم الاول
                                                        </label>
                                                        <div class="col-sm-9">
                                                            <input type="text" class="form-control"
                                                                 v-model="formData.first_name"
                                                                placeholder=" الاسم الاول ">
                                                        </div>
                                                    </div>

                                                    <div class="form-group row">
                                                        <label for="phoneNumber"
                                                            class="col-sm-3 flex-label">
                                                            الاسم الاخير 
                                                        </label>
                                                        <div class="col-sm-9">
                                                            <input type="text" class="form-control"
                                                                 v-model="formData.last_name"
                                                                placeholder="لاسم الاخير  ">
                                                        </div>
                                                    </div>


                                                    <div class="form-group row">
                                                        <label for="phoneNumber"
                                                            class="col-sm-3 flex-label">
                                                            رقم الجوال
                                                        </label>
                                                        <div class="col-sm-9">
                                                            <input type="text" class="form-control"
                                                                id="phoneNumber" v-model="formData.mobile"
                                                                placeholder="رقم الجوال">
                                                        </div>
                                                    </div>

                                                    <div class="form-group row">
                                                        <label for="phoneNumber"
                                                            class="col-sm-3 flex-label">
                                                            البريد الالكتروني 
                                                        </label>
                                                        <div class="col-sm-9">
                                                            <input type="email" class="form-control"
                                                                 v-model="formData.email"
                                                                placeholder="البريد الالكتروني ">
                                                        </div>
                                                    </div>

                                                   
                                                    <div class="social-media">
                                                        <p class="mb-3">سوشيال ميديا</p>

                                                        <div class="social-media-wrapper">
                                                            <div class="social-media-inner">

                                                                <select class="selectpicker">
                                                                    <option data-icon="fa fa-facebook">
                                                                    </option>
                                                                   <!--  <option data-icon="fa fa-twitter">
                                                                    </option>
                                                                    <option data-icon="fa fa-instagram">
                                                                    </option>
                                                                    <option
                                                                        data-icon="fa fa-snapchat-ghost">
                                                                    </option> -->
                                                                </select>

                                                                <input type="text" class="form-control"
                                                                    v-model="formData.facebook" placeholder="Your Facebook" >
                                                            </div>
                                                            <div class="social-media-inner">

                                                                <select class="selectpicker">
                                                                   <!--  <option data-icon="fa fa-facebook">
                                                                    </option> -->
                                                                    <option selected
                                                                        data-icon="fa fa-twitter">
                                                                    </option>
                                                                    <!-- <option data-icon="fa fa-instagram">
                                                                    </option>
                                                                    <option
                                                                        data-icon="fa fa-snapchat-ghost">
                                                                    </option> -->
                                                                </select>

                                                                <input type="text" class="form-control"
                                                                    v-model="formData.twitter" placeholder="Your Twitter">
                                                            </div>

                                                            <div class="social-media-inner">

                                                                <select class="selectpicker">
                                                                   <!--  <option data-icon="fa fa-facebook">
                                                                    </option>
                                                                    <option data-icon="fa fa-twitter">
                                                                    </option> -->
                                                                    <option selected
                                                                        data-icon="fa fa-instagram">
                                                                    </option>
                                                                   <!--  <option
                                                                        data-icon="fa fa-snapchat-ghost">
                                                                    </option> -->
                                                                </select>

                                                                <input type="text" class="form-control"
                                                                    v-model="formData.instagram" placeholder="Your Instagram">
                                                            </div>

                                                            <div class="social-media-inner">

                                                                <select class="selectpicker">
                                                                   <!--  <option data-icon="fa fa-facebook">
                                                                    </option>
                                                                    <option data-icon="fa fa-twitter">
                                                                    </option>
                                                                    <option data-icon="fa fa-instagram">
                                                                    </option> -->
                                                                    <option selected
                                                                        data-icon=" fa fa-linkedin">
                                                                    </option>
                                                                </select>

                                                                <input type="text" class="form-control"
                                                                    v-model="formData.linkedin" placeholder="Your linkedIn">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="btn-container">
                                                <router-link to="/subadmin/home" class="btn btn-outline-light">الغاء</router-link>
                                                <button type="submit"
                                                    class="btn btn-primary">حفظ</button>
                                            </div>


                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>  
   </div>
</template>

<script>
       export default {
       name : 'RegisterApp',
       data(){
	       	return {
            errors: [],
	       	 formData:{
              first_name:null,
              last_name:null,
              mobile:null,
              email:null,
              name_ar:null,
              name_en:null,
              commercial_registration_number:null,
              address:null,
              tax_number:null,
              facebook:'https://www.facebook.com/',
              twitter:'https://twitter.com/',
              instagram:'https://www.instagram.com/',
              linkedin:'https://www.linkedin.com/',
	       	 	},
            commercial_file:null,
            national_file:null,
            tax_file:null,
            logo_file:null,

            commercial_file_preview:null,
            national_file_preview:null,
            tax_file_preview:null,
            logo_file_preview:null,


	       	 	message:{
	       	 		email:{},
	       	 	}
		    }
       },
       methods:{

        onFileChange(e){
                this.commercial_file = e.target.files[0];
                this.commercial_file_preview = URL.createObjectURL(this.commercial_file);
            },

        onFileChange2(e){
            this.national_file = e.target.files[0];
            this.national_file_preview = URL.createObjectURL(this.national_file);
        },

        onFileChange3(e){
            this.tax_file = e.target.files[0];
            this.tax_file_preview = URL.createObjectURL(this.tax_file);
        },

        onFileChange4(e){
            this.logo_file = e.target.files[0];
            this.logo_file_preview = URL.createObjectURL(this.logo_file);
        },

        isNumber: function(evt) {
          evt = (evt) ? evt : window.event;
          var charCode = (evt.which) ? evt.which : evt.keyCode;
          if ((charCode > 31 && (charCode < 48 || charCode > 57)) && charCode !== 46) {
            evt.preventDefault();
          } else {
            return true;
          }
        },




       	editInfoCompany(e){

          e.preventDefault();
            const config = {
                    headers: {
                        'content-type': 'multipart/form-data'
                    }
                }


            let form = new FormData();
            form.append('commercial_file', this.commercial_file);
            form.append('national_file', this.national_file);
            form.append('tax_file', this.tax_file);
            form.append('logo_file', this.logo_file);
            form.append('first_name', this.formData.first_name);
            form.append('last_name', this.formData.last_name);
            form.append('email', this.formData.email);
            form.append('mobile', this.formData.mobile);
            form.append('name_ar', this.formData.name_ar);
            form.append('name_en', this.formData.name_en);
            form.append('commercial_registration_number', this.formData.commercial_registration_number);
            form.append('address', this.formData.address);
            form.append('tax_number', this.formData.tax_number);
            
            form.append('facebook', this.formData.facebook);
            form.append('twitter', this.formData.twitter);
            form.append('instagram', this.formData.instagram);
            form.append('linkedin', this.formData.linkedin);


            // console.log(this.formData)
            // console.log(form)

       		axios.post('editInfoCompany',form,config).then((response)=>{
                // console.log(response.data)
             if(response.data.items){
               swal({
                text: "تم حفظ التغييرات بنجاح",
                icon: "success",
                timer: 2000,
                button: false
                });
              // console.log(response.data)
             // this.errors.push(response.data.message);

            }else{
                // this.errors= [];
                // this.errors.push(response.data.message);
                swal({
                text: response.data.message,
                icon: 'error',
                timer: false,
                button: true
                });
              
            }       			
       			
       		})
       	}
       },

       created(){

        let token = localStorage.getItem('token')
         axios.get('user').then(response => {
            if(response.data){
              // console.log(response.data.items)
              let data = response.data.items
              this.formData = data
              this.commercial_file_preview = data.commercial_file
              this.national_file_preview = data.national_file
              this.tax_file_preview = data.tax_file
              this.logo_file_preview = data.logo_file
             if(this.formData.facebook == ''){
                this.formData.facebook = 'https://www.facebook.com/'
             }

             if(this.formData.twitter == ''){
                this.formData.twitter = 'https://www.twitter.com/'
             }

             if(this.formData.instagram == ''){
                this.formData.instagram = 'https://www.instagram.com/'
             }

             if(this.formData.linkedin == ''){
                this.formData.linkedin = 'https://www.linkedin.com/'
             }
              
            
            }else{
                //kfllfg
            }
             }).catch((error)=>{
                
                
             });

       }
    }


   
</script>
