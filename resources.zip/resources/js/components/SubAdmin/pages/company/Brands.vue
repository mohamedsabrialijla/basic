<template>
    <div>
         <div class="row">
            <div class="col-12">
                <div class="portlet parcels latest-parcels">
                    <div class="portlet-head">
                        <div class="portlet-head-label">
                            <div class="portlet-head-icon">
                                <i class="icon icon-settings"></i>
                            </div>
                            <h3 class="portlet-head-title">
                                العلامات التجارية
                            </h3>
                        </div>

                        <div class="portlet-head-btn">
                            <a href="#" class="btn btn-primary btn-info" @click="getModal()">
                                <i class="icon icon-add icon-text"></i>
                                  اضافة علامة
                            </a>
                        </div>

                    </div>
                    <div class="portlet-body">
                        <form>
                            <div class="parcels-content mt-2">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="dtable">
                                            <table class="table d-table">
                                                <thead>
                                                    <th>#</th>
                                                    <th>الصورة </th>
                                                    <th>الاسم </th>
                                                    <th>الجوال </th>
                                                    <th>الحالة </th>
                                                    <th>التاريخ</th>
                                                    <th>الاجراءات</th>

                                                </thead>

                                                <tbody>
                                                    <tr v-for="item,index in items.data" :key="item.id">
                                                        <td>{{index+1}}</td>
                                                        <td><img :src="item.logo" width="20"></td>
                                                        <td>{{item.name}}</td>
                                                        <td>{{item.mobile}}</td>
                                                        <td>
                                                            <span v-if="item.status =='active'" class="badge badge-pill badge-success">
                                                                {{item.status}}
                                                            </span> 
                                                            <span v-else class="badge badge-pill badge-danger">
                                                                {{item.status}}
                                                            </span> 
                                                        </td>
                                                        <td>{{item.created_at}}</td>
                                                        
                                                        
                                                        <td>
                                                            <a href="#" v-if="item.status=='active'"
                                                                class="btn red-btn btn-icon"
                                                                @click="deleteMark(item.id,item.status)"
                                                                title="" data-original-title="حذف">
                                                                <i class="icon icon-delete"></i>
                                                            </a>

                                                            <a style="background-color:#49c55f" href="#" v-if="item.status!='active'"
                                                                class="btn green-btn btn-icon"
                                                                @click="deleteMark(item.id,item.status)"
                                                                title="" data-original-title="حذف">
                                                                <i class="icon icon-approval"></i>
                                                            </a>

                                                          

                                                            <span class="d-inline-block"
                                                                 data-original-title="تعديل">
                                                                <a href="#" class="btn green-btn btn-icon"
                                                                    @click="getModalEdit(item)">
                                                                    <i
                                                                        class="icon icon-pencil-edit-button"></i>
                                                                </a>
                                                            </span>

                                                        </td>
                                                    </tr>

                                                    <tr v-if="totalPages == 0">
                                                        <td colspan="6" style="text-align:center">لا يوجد نتائج </td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>


                                            <sliding-pagination v-if="totalPages != 0"
                                              :current="currentPage"
                                              :total="totalPages"
                                              @page-change="pageChangeHandler"
                                            ></sliding-pagination>


                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>






<!-- modal add mark -->
<div class="modal fade main-modal add-mark" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-blg" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title d-flex">
                <i class="icon icon-add"></i>
                 {{titleModal}}</h5>
            <button type="button" class="close" @click="closeModal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
             <form  @submit="addEditMark" enctype="multipart/form-data">
                <div class="row">
                    <div class="alert alert-danger" role="alert" v-if="errors.length">
                        <b style="font-weght">يرجي التاكد من البيانات  :</b>
                        <ul>
                          <li v-for="error in errors">{{ error }}</li>
                        </ul>
                    </div>
                    
                    <div class="form-group col-3"></div>
                    <div class="form-group col-4">
                        <label for="personalPicture" class="col-12 flex-label" style="font-weight: bold;"> 
                          لوجو  المتجر
                        </label>
                        <div class="col-sm-9">
                            <div class="avatar-picture">
                                <div class="image-input image-input-outline"
                                    id="imgUserProfile">
                                    <div id="preview">
                                        <a :href="logo_preview" target="_blank">
                                            <img v-if="logo_preview" :src="logo_preview" width="100" height="100" />
                                            <img v-else :src="logo_preview_add" width="100" />
                                        </a>
                                    </div>

                                    <label class="btn" data-toggle="tooltip"
                                        data-placement="top" >

                                        <i class="icon icon-pencil-edit-button"></i>
                                        <input type="file" name="profile_avatar" v-on:change="onFileChange"
                                            accept=".png, .jpg, .jpeg .pdf">
                                        <input type="button" value="Upload" id="uploadButton" />


                                    </label>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group col-4">
                        <label for="personalPicture" class="col-12 flex-label" style="font-weight: bold;"> 
                            غلاف المتجر
                        </label>
                        <div class="col-sm-9">
                            <div class="avatar-picture">
                                <div class="image-input image-input-outline"
                                    id="imgUserProfile">
                                    <div id="preview">
                                        <a :href="logo_preview" target="_blank">
                                            <img v-if="cover_preview" :src="cover_preview" width="100" height="100" />
                                            <img v-else :src="cover_preview_add" width="100" />
                                        </a>
                                    </div>

                                    <label class="btn" data-toggle="tooltip"
                                        data-placement="top" >

                                        <i class="icon icon-pencil-edit-button"></i>
                                        <input type="file" name="profile_avatar" v-on:change="onFileChange2"
                                            accept=".png, .jpg, .jpeg .pdf">
                                        <input type="button" value="Upload" id="uploadButton" />


                                    </label>

                                </div>
                            </div>
                        </div>
                    </div>

                   
                    
                </div>

                <div class="tab-content mt-4" id="myTabContent">
                    <div class="tab-pane fade show active" id="storeInformation"
                        role="tabpanel" aria-labelledby="storeInformation-tab">
                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex">
                                <div class="form-group col-4" v-for="lang,index in languages">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        الاسم  ({{lang.name}})
                                    </label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control"
                                             v-model="formData['name_' + lang.lang]" value=""
                                            placeholdr="'name'+lang.name">
                                    </div>
                                </div>

                             

                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        متوسط السعر
                                    </label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" @keypress="isNumber($event)"
                                            v-model="formData.price" value=""
                                            placeholder="متوسط السعر">
                                    </div>
                                </div> 



                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex">
                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        رقم الهاتف
                                    </label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" @keypress="isNumber($event)"
                                             v-model="formData.mobile" value="" maxlength="10" 
                                            placeholder="رقم الهاتف">
                                    </div>
                                </div>

                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      رابط الموقع
                                    </label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control"
                                            v-model="formData.link" value=""
                                            placeholder="رابط الموقع">
                                    </div>
                                </div> 


                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      اللباس الواجب ارتداؤه
                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <select class="form-control" v-model="formData.clothes" >
                                            <option value=""> إختر... </option>
                                            <option :value="1">لباس رسمي</option>
                                            <option :value="2">شبه رسمي</option>
                                            <option value="3">غير رسمي</option>
                                            <option value="4">ملابس اعمال</option>
                                            <option value="5">ملابس سمارت</option>
                                            <option value="6">كاجوال</option>
                                        </select>

                                    </div>
                                </div>

                            </div>
                        </div>



                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex">
                            
                                <div class="form-group col-6">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      نوع المتجر 

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <!-- <select class="form-control select-tag"  v-model="formData.types"  multiple  on-click="kkk">
                                            <option v-for="type in types" v-bind:value="type.id">{{type.name}}</option>
                                           
                                        </select> -->
                                        <multiselect class="" v-model="formData.types" tag-placeholder="اختيار " placeholder="ابحث من هنا .." label="name" track-by="id" :options="types" :multiple="true" :taggable="true" ></multiselect>

                                    </div>
                                </div>



                                <div class="form-group col-6">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      حدد الوسوم المناسبة لك 

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <multiselect class="" v-model="formData.tags" tag-placeholder="اختيار " placeholder="ابحث من هنا .." label="name" track-by="id" :options="tags" :multiple="true" :taggable="true" ></multiselect>

                                    </div>
                                </div>


                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex">
                            
                                <div class="form-group col-6">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      حدد طرق الدفع المتاحة 

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                       <multiselect class="" v-model="formData.payments" tag-placeholder="اختيار " placeholder="ابحث من هنا .." label="name" track-by="id" :options="payments" :multiple="true" :taggable="true" ></multiselect>


                                    </div>
                                </div>


                                <div class="form-group col-6">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        مميزات المتجر
                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                       <multiselect class="" v-model="formData.features" tag-placeholder="اختيار " placeholder="ابحث من هنا .." label="name" track-by="id" :options="features" :multiple="true" :taggable="true" ></multiselect>


                                    </div>
                                </div>


                            </div>
                        </div>


                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex">
                                <div class="form-group col-6" v-for="lang,index in languages">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                       الوصف  ({{lang.name}})

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <textarea rows="6" id="messageContent" maxlength="250"
                                           v-model="formData['descriptions_' + lang.lang]" value=""
                                            placeholdr="'descriptions'+lang.name" class="form-control ">     
                                        </textarea>
                                    </div>
                                </div>

                            </div>
                        </div>



                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex">
                                <div class="form-group col-6" v-for="lang,index in languages">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                       سياسة المتجر  ({{lang.name}})

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <textarea rows="6" id="messageContent" maxlength="250"
                                           v-model="formData['privacy_' + lang.lang]" value=""
                                            placeholdr="'privacy'+lang.name" class="form-control ">     
                                        </textarea>
                                    </div>
                                </div>

                            </div>
                        </div>


                    </div>
                </div>

              
                <div class="btn-container">
                    <a class="btn btn-outline-light"  @click="closeModal">الغاء</a>
                    <button type="submit"
                        class="btn btn-primary" :disabled='value'>حفظ</button>
                </div>
            </form>
        </div>
    </div>
    </div>
</div>
        <!-- end modal -->
   </div>
</template>
 
 

<script>

    import Multiselect from 'vue-multiselect'
    import SlidingPagination from 'vue-sliding-pagination'

       export default {
        components: { Multiselect,SlidingPagination},
       name : 'Brands',
       data(){
	       	return {
                value:false,
            titleModal:'',
            currentPage: 0,
            totalPages: 0,
            items:[],
            languages:[],
            errors: [],
            types: [],
            tags: [],
            payments: [],
            features:[],
            ID:'',
            URL:'Mark/createItem',
	       	 
            formData:{
              mobile:null,
              payments:[],
              tags:[],
              types:[],
              features:[],
              name_ar:null,
              name_en:null,
              price:null,
              clothes:null,
              descriptions_en:null,
              descriptions_ar:null,
              privacy_en:null,
              privacy_ar:null,
              logo:null,
              cover:null,
            
	       	 	},

            logo:null,
            cover:null,

            logo_preview:null,
            cover_preview:null,
            logo_preview_add :'./../assets/companies/img/store-logo.jpg',
            cover_preview_add :'./../assets/companies/img/store-logo.jpg',

		    }
       },
       methods:{
        pageChangeHandler(selectedPage) {
            this.currentPage = selectedPage
            this.getMarks()
        },
       
        onFileChange(e){
            this.logo = e.target.files[0];
            this.logo_preview = URL.createObjectURL(this.logo);
        },

        onFileChange2(e){
            this.cover = e.target.files[0];
            this.cover_preview = URL.createObjectURL(this.cover);
        },

       
        isNumber: function(evt) {
          evt = (evt) ? evt : window.event;
          var charCode = (evt.which) ? evt.which : evt.keyCode;
          if ((charCode > 31 && (charCode < 48 || charCode > 57)) && charCode !== 46) {
            evt.preventDefault();
          } else {
            return true;
          }
        },

        getModal(){
            this.resetMark();
            $('#myModal').modal('show');
            this.titleModal = 'اضافة علامة تجارية'
        },


        getModalEdit(item){
            this.resetMark();
            $('#myModal').modal('show');
            this.titleModal = 'تعديل علامة تجارية'
            this.ID = item.id
            this.URL = 'Mark/editItem'
            this.getMrakById() 
            
        },

        closeModal(){
            $('#myModal').modal('hide');
            this.URL = 'Mark/createItem'
            this.ID = null
            // this.resetMark();
        },

        resetMark(){
          this.URL = 'Mark/createItem'
          this.formData.mobile=''
          this.formData.payments=[]
          this.formData.tags=[]
          this.formData.types=[]
          this.formData.features=[]
          this.formData.name_ar=''
          this.formData.name_en=''
          this.formData.price=''
          this.formData.clothes=''
          this.formData.descriptions_en=''
          this.formData.descriptions_ar=''
          this.formData.privacy_en=''
          this.formData.privacy_ar=''
          this.formData.logo=''
          this.formData.cover=''
          this.logo_preview ='./../assets/companies/img/store-logo.jpg'
          this.cover_preview ='./../assets/companies/img/store-logo.jpg'

        },


       	addEditMark(e){
            this.value = true
          e.preventDefault();

            const config = {
                    headers: {
                        'content-type': 'multipart/form-data'
                    }
                }

            // console.log(this.formData)
            // return false

            let form = new FormData();
            form.append('logo', this.logo);
            form.append('cover', this.cover);
            form.append('name_ar', this.formData.name_ar);
            form.append('name_en', this.formData.name_en);
            form.append('descriptions_ar', this.formData.descriptions_ar);
            form.append('descriptions_en', this.formData.descriptions_en);
            form.append('mobile', this.formData.mobile);
            form.append('link', this.formData.link);
            form.append('privacy_ar', this.formData.privacy_ar);
            form.append('privacy_en', this.formData.privacy_en);
            form.append('price', this.formData.price);
            form.append('clothes', this.formData.clothes);
            form.append('tags', JSON.stringify(this.formData.tags));
            form.append('payments', JSON.stringify(this.formData.payments));
            form.append('features', JSON.stringify(this.formData.features));
            form.append('types', JSON.stringify(this.formData.types));
            if(this.ID != ''){
               form.append('MarkID', this.ID);
            }
             
            // let url= this.URL
       		axios.post(this.URL,form,config).then((response)=>{
                 this.value = false
                if(response.data.items){
                   swal({
                    text: "تم حفظ التغييرات بنجاح",
                    icon: "success",
                    timer: 2000,
                    button: false
                    }); 
                    this.closeModal()
                    this.getMarks()           

                }else{
                    swal({
                    text: response.data.message,
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }       			
       			
       		})
       	},


        getMarks(){

            axios.get('Mark/getAllItems?page='+ this.currentPage).then(response => {
                if(response.data){
                  let data = response.data.items
                  this.totalPages=Math.ceil(data.total/data.per_page)
                    this.items = data;
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });
        },


        getMrakById(){
            axios.get('Mark/getById', { params: { ID: this.ID } }).then(response => {
                if(response.data){
                  let data = response.data.items
                  let translations = response.data.items.translations
                   this.formData = data;
                   this.logo_preview = data.logo;
                   this.cover_preview = data.cover;
                   // this.formData.types = response.data.items.types.map(({ id}) => (id));

                    translations.forEach((element) => { 
                          this.formData['name_'+element.locale] = element.name; 
                          this.formData['descriptions_'+element.locale] = element.descriptions ;
                          this.formData['privacy_'+element.locale] = element.privacy  ;
                    });

                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });
        },

        deleteMark(id,status) {

            var a = "هل انت متأكد من عملية الغاء التفعيل ?"
            var b = "سيتم الغاء تفعيل البراند بالكامل من اللوحة  !"
            var c ='تم الغاء التفعيل , سوف يتم تحميل فرع جديد '
            var d = 'تم الغاء التفعيل بنجاح'
            if(status=='not_active'){
                var a = "هل انت متأكد من عملية التفعيل ?"
                var b = "سيتم  تفعيل البراند بالكامل من اللوحة  !"
                var c ='تم  التفعيل , سوف يتم تحميل فرع جديد '
                var d = 'تم  التفعيل بنجاح'
            }


            swal({
                  title: a,
                  text: b,
                  icon: "warning",
                  buttons: true,
                  dangerMode: true,
                }).then((result) => {
              if (result) {
                axios.delete('Mark/deleteItem/'+id)
                    .then((response)=> {
                            if(response.data.code == 200){
                                swal(
                                  c,
                                  d,
                                  'success'
                                )
                                // this.getMarks()
                                location.reload()         

                            }else{
                                swal({
                                  icon: 'error',
                                  title: 'حدث خطأ',
                                  text: 'حدث خطأ أثناء عملية التنفيذ!',
                                })

                            }
                           
                    

                    }).catch(() => {
                        swal({
                          icon: 'error',
                          title: 'حدث خطأ',
                          text: 'حدث خطأ أثناء عملية التنفيذ!',
                        })
                    })
                }

            })
        },


       },

       created(){

            this.languages = JSON.parse(localStorage.getItem("languages"))
            // this.$lang.setLocale('ar')
            // alert(this.$lang.getLocale())
            this.getMarks()
            axios.get('getTypes').then(response => {
                if(response.data){
                  let data = response.data.items
                  this.types = data;
                
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });


            axios.get('getTags').then(response => {
                if(response.data){
                  let data = response.data.items
                  this.tags = data;
                
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{
                swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });            
            });  


            axios.get('getPayments').then(response => {
                if(response.data){
                  // console.log(response.data.items)
                  let data = response.data.items
                  this.payments = data;
                
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });           
            }); 



            axios.get('getFeatures').then(response => {
                if(response.data){
                  let data = response.data.items
                  this.features = data;
                
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });           
            });   
       },
       mounted(){

       }
    }


   
</script>
<style src="vue-sliding-pagination/dist/style/vue-sliding-pagination.css"></style>
<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>
<style>

.multiselect__option--highlight {
    background: #3ebdb1 !important;
    outline: none;
    color: #fff;}

    .multiselect__tag {
    background: #3ebdb1;}

    .multiselect__tag-icon:after {
    color: ##33a196;
    }




    ol, p, ul {
        line-height: 1.0;
    }


    .c-sliding-pagination__list-element {
        
        padding: 0.5em !important;
        border-radius: 0.6em !important;
        margin: 1px 2px 1px 4px !important;
    }


</style>