<template>
    <div>
        <div class="row">
            <div class="col-12">
                <div class="portlet">
                    <div class="portlet-head">
                        <div class="portlet-head-label">
                            <div class="portlet-head-icon">
                                <i class="icon icon-shop"></i>
                            </div>
                            <h3 class="portlet-head-title">
                                 تعديل  كلمة المرور
                            </h3>
                        </div>
                    </div>
                    <div class="portlet-body">

                          <div class="alert alert-danger" role="alert" v-if="errors.length">
                              <b style="font-weght">يرجي التاكد من البيانات  :</b>
                                <ul>
                                  <li v-for="error in errors">{{ error }}</li>
                                </ul>
                              </div>



                        <div class="row">
                            <div class="col-12">
                                <form  @submit="editInfoCompany" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="col-lg-7 col-12 mx-auto">
                                            <div class="store-img">

                                           
                                            </div>
                                        </div>
                                    </div>

                                    

                                    <div class="tab-content mt-4" id="myTabContent">
                                        <div class="tab-pane fade show active" id="storeInformation"
                                            role="tabpanel" aria-labelledby="storeInformation-tab">
                                            <div class="row">
                                                <div class="col-lg-7 col-12 mx-auto">
                                                    <div class="form-group row">
                                                        <label for="storeName" class="col-sm-3 flex-label">
                                                            كلمة المرور الجديدة
                                                        </label>
                                                        <div class="col-sm-9">
                                                            <input type="password" class="form-control"
                                                                 v-model="formData.password" value=""
                                                                placeholder="كلمة المرور الجديدة">
                                                        </div>
                                                    </div>


                                                    <div class="form-group row">
                                                        <label for="storeName" class="col-sm-3 flex-label">
                                                            تاكيد كلمة المرور
                                                        </label>
                                                        <div class="col-sm-9">
                                                            <input type="password" class="form-control"
                                                                 v-model="formData.confirm_password" value=""
                                                                placeholder="تاكيد كلمة المرور">
                                                        </div>
                                                    </div>




                                          
                                                </div>
                                            </div>


                                            <div class="btn-container">
                                                <router-link to="/subadmin/home" class="btn btn-outline-light">الغاء</router-link>
                                                <button type="submit"
                                                    class="btn btn-primary">حفظ</button>
                                            </div>


                                        </div>
                                        
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>  
   </div>
</template>

<script>
       export default {
       name : 'EditPassword',
       data(){
	       	return {
            errors: [],
	       	 formData:{
              password:null,
              confirm_password:null,
	       	 	},
		    }
       },
       methods:{


       	editInfoCompany(e){

          e.preventDefault();
            const config = {
                    headers: {
                        'content-type': 'multipart/form-data'
                    }
                }
                
            let form = new FormData();
            form.append('password', this.formData.password);
            form.append('confirm_password', this.formData.confirm_password);

       		axios.post('editPassword',form,config).then((response)=>{
             if(response.data.items){
               swal({
                text: "تم حفظ التغييرات بنجاح",
                icon: "success",
                timer: 2000,
                button: false
                });

            }else{
                
                swal({
                text: response.data.message,
                icon: 'error',
                timer: false,
                button: true
                });
              
            }       			
       			
       		})
       	}
       },

       created(){

       }
    }


   
</script>
