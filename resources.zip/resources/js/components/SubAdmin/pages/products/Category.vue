<template>
    <div>
         <div class="row">
            <div class="col-12">
                <div class="portlet parcels latest-parcels">
                    <div class="portlet-head">
                        <div class="portlet-head-label">
                            <div class="portlet-head-icon">
                                <i class="icon icon-settings"></i>
                            </div>
                            <h3 class="portlet-head-title">
                                التصنيفات الرئيسية
                            </h3>
                        </div>

                        <div class="portlet-head-btn">
                            <a href="#" class="btn btn-primary btn-info" @click="getModal()">
                                <i class="icon icon-add icon-text"></i>
                                  اضافة تصنيف
                            </a>
                        </div>

                    </div>
                    <div class="portlet-body">
                        <form>
                            <div class="parcels-content mt-2">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="dtable">
                                            <table class="table d-table">
                                                <thead>
                                                    <th>#</th>
                                                    <th>الاسم</th>
                                                    <th>الحالة </th>
                                                    <th>تاريخ الانشاء </th>
                                                    <th>الاجراءات</th>

                                                </thead>

                                                <tbody>
                                                    <tr v-for="item,index in items.data" :key="item.id">
                                                        <td>{{index+1}}</td>
                                                        <td>{{item.title}}</td>
                                                        <!-- <td>{{item.branch.name}}</td> -->
                                                        <td>
                                                             <span v-if="item.status =='active'" class="badge badge-pill badge-success">
                                                                {{item.status}}
                                                            </span> 
                                                            <span v-else class="badge badge-pill badge-danger">
                                                                {{item.status}}
                                                            </span> 

                                                        </td>
                                                        <td>{{item.created_at}}</td>
                                                        
                                                        
                                                        <td>
                                                            <a href="#"
                                                                class="btn red-btn btn-icon"
                                                                @click="deleteCategory(item.id)"
                                                                title="" data-original-title="حذف">
                                                                <i class="icon icon-delete"></i>
                                                            </a>

                                                          
 
                                                            <span class="d-inline-block"
                                                                 data-original-title="تعديل">
                                                                <a href="#" class="btn green-btn btn-icon"
                                                                    @click="getModalEdit(item)">
                                                                    <i
                                                                        class="icon icon-pencil-edit-button"></i>
                                                                </a>
                                                            </span>

                                                        </td>
                                                    </tr>

                                                    <tr v-if="totalPages == 0">
                                                        <td colspan="6" style="text-align:center">لا يوجد نتائج </td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>


                                            <sliding-pagination v-if="totalPages != 0"
                                              :current="currentPage"
                                              :total="totalPages"
                                              @page-change="pageChangeHandler"
                                            ></sliding-pagination>


                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>






<!-- modal add Booking -->
<div class="modal fade main-modal add-Booking" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-blg" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title d-flex">
                <i class="icon icon-add"></i>
                 {{titleModal}}</h5>
            <button type="button" class="close" @click="closeModal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
             <form  @submit="addEditCategory">
                <div class="row">
                    <div class="alert alert-danger" role="alert" v-if="errors.length">
                        <b style="font-weght">يرجي التاكد من البيانات  :</b>
                        <ul>
                          <li v-for="error in errors">{{ error }}</li>
                        </ul>
                    </div>
                    
                </div>

                <div class="tab-content mt-4" id="myTabContent">
                    <div class="tab-pane fade show active" id="storeInformation"
                        role="tabpanel" aria-labelledby="storeInformation-tab">


                         <div class="form-group col-4">
                        <label for="personalPicture" class="col-12 flex-label" style="font-weight: bold;"> 
                          لوجو  المنتج
                        </label>
                        <div class="col-sm-9">
                            <div class="avatar-picture">
                                <div class="image-input image-input-outline"
                                    id="imgUserProfile">
                                    <div id="preview">
                                        <a :href="logo_preview" target="_blank">
                                            <img v-if="logo_preview" :src="logo_preview" width="100" height="100" />
                                            <img v-else :src="logo_preview_add" width="100" />
                                        </a>
                                    </div>

                                    <label class="btn" data-toggle="tooltip"
                                        data-placement="top" >

                                        <i class="icon icon-pencil-edit-button"></i>
                                        <input type="file" name="profile_avatar" v-on:change="onFileChange"
                                            accept=".png, .jpg, .jpeg .pdf">
                                        <input type="button" value="Upload" id="uploadButton" />


                                    </label>

                                </div>
                            </div>
                        </div>
                    </div>



                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex">

                                 <div class="form-group col-6" v-for="lang,index in languages">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        العنوان  ({{lang.name}})
                                    </label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control"
                                             v-model="formData['title_' + lang.lang]" value=""
                                            placeholdr="'title'+lang.name">
                                    </div>
                                </div>

                             
                            </div>
                        </div>
                        

                    </div>
                </div>

              
                <div class="btn-container">
                    <a class="btn btn-outline-light"  @click="closeModal">الغاء</a>
                    <button type="submit"
                        class="btn btn-primary" :disabled="value">حفظ</button>
                </div>
            </form>
        </div>
    </div>
    </div>
</div>



        <!-- end modal -->
   </div>
</template>
 
 

<script>

    import SlidingPagination from 'vue-sliding-pagination'

       export default {
        components: { SlidingPagination},
       name : 'Category',
       data(){
	       	return {
            value:false,
            ItemSelect:{},
            titleModal:'',
            currentPage: 0,
            totalPages: 0,
            items:[],
            languages:[],
            errors: [],
            ID:'',
            URL:'Category/createItem',
	       	 
            formData:{ 
              logo:null,
              title_en:null,
              title_ar:null,
              status:null,
	       	 	}, 

                logo:null,

            logo_preview:null,
            logo_preview_add :'./../assets/companies/img/store-logo.jpg',


		    }
       },
       methods:{
        pageChangeHandler(selectedPage) {
            this.currentPage = selectedPage
            this.getCategory()
        },

         onFileChange(e){
            this.logo = e.target.files[0];
            this.logo_preview = URL.createObjectURL(this.logo);
        },
       
    

        getModal(){
            this.resetCategory();
            $('#myModal').modal('show');
            this.titleModal = 'اضافة حجز جديد'
        },


        getModalEdit(item){
            this.resetCategory();
            $('#myModal').modal('show');
            this.titleModal = 'تعديل  الحجز'
            this.ID = item.id
            this.URL = 'Category/editItem'
            this.getCategoryById() 
            
        },

        closeModal(){
            $('#myModal').modal('hide');
            this.URL = 'Category/createItem'
            this.ID = null
        },

        resetCategory(){
          this.URL = 'Category/createItem'
          this.formData.title_en=''
          this.formData.title_ar=''
          this.formData.status=''
          this.logo_preview ='./../assets/companies/img/store-logo.jpg'

        },

  
       	addEditCategory(e){
            this.value=true
            e.preventDefault();

             const config = {
                    headers: {
                        'content-type': 'multipart/form-data'
                    }
                }

            

            let form = new FormData();
            form.append('logo', this.logo);
            form.append('title_ar', this.formData.title_ar);
            form.append('title_en', this.formData.title_en);
            if(this.ID != ''){
               form.append('id', this.ID);
            }


       		axios.post(this.URL,form).then((response)=>{
                this.value=false
                if(response.data.items){
                   swal({
                    text: "تم حفظ التغييرات بنجاح",
                    icon: "success",
                    timer: 2000,
                    button: false
                    }); 
                    this.closeModal()
                    this.getCategory()           

                }else{
                    swal({
                    text: response.data.message,
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }       			
       			
       		})
       	},


        getCategory(){

            axios.get('Category/getAllItems?page='+ this.currentPage).then(response => {
                if(response.data){
                  let data = response.data.items
                  this.totalPages=Math.ceil(data.total/data.per_page)
                    this.items = data;

                    console.log(data)
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });
        },


          getCategoryById(){
                axios.get('Category/getById', { params: { ID: this.ID } }).then(response => {
                    if(response.data){
                      let data = response.data.items
                      let translations = response.data.items.translations
                       this.formData = data; 
                       this.logo_preview = data.logo;
                        translations.forEach((element) => { 
                              this.formData['title_'+element.locale] = element.title; 
                        });

                    }else{
                         swal({
                        text: 'Error happens',
                        icon: 'error',
                        timer: false,
                        button: true
                        });
                    }
                }).catch((error)=>{

                        swal({
                        text: 'Error happens',
                        icon: 'error',
                        timer: false,
                        button: true
                        });         
                });
            },

        deleteCategory(id) {
            swal({
                  title: "Are you sure?",
                  text: "Once deleted, you will not be able to recover this imaginary item!",
                  icon: "warning",
                  buttons: true,
                  dangerMode: true,
                }).then((result) => {
              if (result) {
                axios.delete('Category/deleteItem/'+id)
                    .then((response)=> {
                            if(response.data.code == 200){
                                swal(
                                  'Deleted!',
                                  'Item deleted successfully',
                                  'success'
                                )
                                this.getCategory()           

                            }else{
                                swal({
                                  icon: 'error',
                                  title: 'Oops...',
                                  text: 'Something went wrong!',
                                })

                            }
                           
                    

                    }).catch(() => {
                        swal({
                          icon: 'error',
                          title: 'Oops...',
                          text: 'Something went wrong!',
                        })
                    })
                }

            })
        },
        

   


       },

       created(){

            this.languages = JSON.parse(localStorage.getItem("languages"))
            this.getCategory()

       

           
       },
       mounted(){

       }
    }


   
</script>
<style src="vue-sliding-pagination/dist/style/vue-sliding-pagination.css"></style>
<style>
    ol, p, ul {
        line-height: 1.0;
    }


    .c-sliding-pagination__list-element {
        
        padding: 0.5em !important;
        border-radius: 0.6em !important;
        margin: 1px 2px 1px 4px !important;
    }


</style>