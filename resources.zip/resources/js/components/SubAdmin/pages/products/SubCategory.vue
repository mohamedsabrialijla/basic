<template>
    <div>
         <div class="row">
            <div class="col-12">
                <div class="portlet parcels latest-parcels">
                    <div class="portlet-head">
                        <div class="portlet-head-label">
                            <div class="portlet-head-icon">
                                <i class="icon icon-settings"></i>
                            </div>
                            <h3 class="portlet-head-title">
                                التصنيفات الفرعية
                            </h3>
                        </div>

                        <div class="portlet-head-btn">
                            <a href="#" class="btn btn-primary btn-info" @click="getModal()">
                                <i class="icon icon-add icon-text"></i>
                                  اضافة تصنيف
                            </a>
                        </div>

                    </div>
                    <div class="portlet-body">
                        <form>
                            <div class="parcels-content mt-2">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="dtable">
                                            <table class="table d-table">
                                                <thead>
                                                    <th>#</th>
                                                    <th>التصنيف الرئيسي</th>
                                                    <th>الاسم</th>
                                                    <th>الحالة </th>
                                                    <th>تاريخ الانشاء </th>
                                                    <th>الاجراءات</th>

                                                </thead>

                                                <tbody>
                                                    <tr v-for="item,index in items.data" :key="item.id">
                                                        <td>{{index+1}}</td>
                                                        <td><p v-if="item.category">{{item.category.title}}</p> <p v-else>لا يوجد </p></td>
                                                        <td>{{item.title}}</td>
                                                        <!-- <td>{{item.branch.name}}</td> -->
                                                        <td>
                                                             <span v-if="item.status =='active'" class="badge badge-pill badge-success">
                                                                {{item.status}}
                                                            </span> 
                                                            <span v-else class="badge badge-pill badge-danger">
                                                                {{item.status}}
                                                            </span> 

                                                        </td>
                                                        <td>{{item.created_at}}</td>
                                                        
                                                        
                                                        <td>
                                                            <a href="#"
                                                                class="btn red-btn btn-icon"
                                                                @click="deleteCategory(item.id)"
                                                                title="" data-original-title="حذف">
                                                                <i class="icon icon-delete"></i>
                                                            </a>

                                                          
 
                                                            <span class="d-inline-block"
                                                                 data-original-title="تعديل">
                                                                <a href="#" class="btn green-btn btn-icon"
                                                                    @click="getModalEdit(item)">
                                                                    <i
                                                                        class="icon icon-pencil-edit-button"></i>
                                                                </a>
                                                            </span>

                                                        </td>
                                                    </tr>

                                                    <tr v-if="totalPages == 0">
                                                        <td colspan="6" style="text-align:center">لا يوجد نتائج </td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>


                                            <sliding-pagination v-if="totalPages != 0"
                                              :current="currentPage"
                                              :total="totalPages"
                                              @page-change="pageChangeHandler"
                                            ></sliding-pagination>


                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>






<!-- modal add Booking -->
<div class="modal fade main-modal add-Booking" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-blg" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title d-flex">
                <i class="icon icon-add"></i>
                 {{titleModal}}</h5>
            <button type="button" class="close" @click="closeModal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
             <form  @submit="addEditCategory">
                <div class="row">
                    <div class="alert alert-danger" role="alert" v-if="errors.length">
                        <b style="font-weght">يرجي التاكد من البيانات  :</b>
                        <ul>
                          <li v-for="error in errors">{{ error }}</li>
                        </ul>
                    </div>
                    
                </div>

                <div class="tab-content mt-4" id="myTabContent">
                    <div class="tab-pane fade show active" id="storeInformation"
                        role="tabpanel" aria-labelledby="storeInformation-tab">

                        <div class="row">

                             <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        التصنيف الرئيسي
                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <select class="form-control select-tag "  v-model="formData.category_id"  >
                                            <option v-for="category in categories" v-bind:value="category.id">{{category.title}}</option>
                                           
                                        </select>
                                        

                                    </div>
                                </div>




                            <div class="col-lg-8 col-8 d-flex">

                                 <div class="form-group col-6" v-for="lang,index in languages">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        العنوان  ({{lang.name}})
                                    </label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control"
                                             v-model="formData['title_' + lang.lang]" value=""
                                            placeholdr="'title'+lang.name">
                                    </div>
                                </div>

                             
                            </div>



                        </div>
                        

                    </div>
                </div>

              
                <div class="btn-container">
                    <a class="btn btn-outline-light"  @click="closeModal">الغاء</a>
                    <button type="submit"
                        class="btn btn-primary" :disabled="value">حفظ</button>
                </div>
            </form>
        </div>
    </div>
    </div>
</div>



        <!-- end modal -->
   </div>
</template>
 
 

<script>

    import SlidingPagination from 'vue-sliding-pagination'

       export default {
        components: { SlidingPagination},
       name : 'SubCategory',
       data(){
	       	return {
                value:false,
            ItemSelect:{},
            titleModal:'',
            currentPage: 0,
            totalPages: 0,
            items:[],
            languages:[],
            errors: [],
            ID:'',
            URL:'SubCategory/createItem',
            categories:[],
	       	 
            formData:{ 
              category_id:null,
              title_en:null,
              title_ar:null,
              status:null,
            
	       	 	},
		    }
       },
       methods:{
        pageChangeHandler(selectedPage) {
            this.currentPage = selectedPage
            this.getCategory()
        },
       
    

        getModal(){
            this.resetCategory();
            $('#myModal').modal('show');
            this.titleModal = 'اضافة حجز جديد'
        },


        getModalEdit(item){
            this.resetCategory();
            $('#myModal').modal('show');
            this.titleModal = 'تعديل  الحجز'
            this.ID = item.id
            this.URL = 'SubCategory/editItem'
            this.getCategoryById() 
            
        },

        closeModal(){
            $('#myModal').modal('hide');
            this.URL = 'SubCategory/createItem'
            this.ID = null
        },

        resetCategory(){
          this.URL = 'SubCategory/createItem'
          this.formData.branch_id=''
          this.formData.title_en=''
          this.formData.title_ar=''
          this.formData.status=''

        },

 
       	addEditCategory(e){
            this.value=true
            e.preventDefault();
       		axios.post(this.URL,this.formData).then((response)=>{
                 this.value=false
                if(response.data.items){
                   swal({
                    text: "تم حفظ التغييرات بنجاح",
                    icon: "success",
                    timer: 2000,
                    button: false
                    }); 
                    this.closeModal()
                    this.getCategory()           

                }else{
                    swal({
                    text: response.data.message,
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }       			
       			
       		})
       	},


        getCategory(){

            axios.get('SubCategory/getAllItems?page='+ this.currentPage).then(response => {
                if(response.data){
                  let data = response.data.items
                  this.totalPages=Math.ceil(data.total/data.per_page)
                    this.items = data;
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });
        },


          getCategoryById(){
                axios.get('SubCategory/getById', { params: { ID: this.ID } }).then(response => {
                    if(response.data){
                      let data = response.data.items
                      let translations = response.data.items.translations
                       this.formData = data; 
                        translations.forEach((element) => { 
                              this.formData['title_'+element.locale] = element.title; 
                        });

                    }else{
                         swal({
                        text: 'Error happens',
                        icon: 'error',
                        timer: false,
                        button: true
                        });
                    }
                }).catch((error)=>{

                        swal({
                        text: 'Error happens',
                        icon: 'error',
                        timer: false,
                        button: true
                        });         
                });
            },

        deleteCategory(id) {
            swal({
                  title: "Are you sure?",
                  text: "Once deleted, you will not be able to recover this imaginary item!",
                  icon: "warning",
                  buttons: true,
                  dangerMode: true,
                }).then((result) => {
              if (result) {
                axios.delete('SubCategory/deleteItem/'+id)
                    .then((response)=> {
                            if(response.data.code == 200){
                                swal(
                                  'Deleted!',
                                  'Item deleted successfully',
                                  'success'
                                )
                                this.getCategory()           

                            }else{
                                swal({
                                  icon: 'error',
                                  title: 'Oops...',
                                  text: 'Something went wrong!',
                                })

                            }
                           
                    

                    }).catch(() => {
                        swal({
                          icon: 'error',
                          title: 'Oops...',
                          text: 'Something went wrong!',
                        })
                    })
                }

            })
        },
        

   


       },

       created(){

            this.languages = JSON.parse(localStorage.getItem("languages"))
            this.getCategory()

            axios.get('Category/getAllItems', { params: { pagination: 0 } }).then(response => {
                if(response.data){
                  let data = response.data.items
                  this.categories = data;
                
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });           
            });   

       

           
       },
       mounted(){

       }
    }


   
</script>
<style src="vue-sliding-pagination/dist/style/vue-sliding-pagination.css"></style>
<style>
    ol, p, ul {
        line-height: 1.0;
    }


    .c-sliding-pagination__list-element {
        
        padding: 0.5em !important;
        border-radius: 0.6em !important;
        margin: 1px 2px 1px 4px !important;
    }


</style>