<template>
    <div>
         <div class="row">
            <div class="col-12">
                <div class="portlet parcels latest-parcels">
                    <div class="portlet-head">
                        <div class="portlet-head-label">
                            <div class="portlet-head-icon">
                                <i class="icon icon-settings"></i>
                            </div>
                            <h3 class="portlet-head-title">
                                المنتجات
                            </h3>
                        </div>

                        <div class="portlet-head-btn">
                            <a href="#" class="btn btn-primary btn-info" @click="getModal()">
                                <i class="icon icon-add icon-text"></i>
                                  اضافة منتج
                            </a>
                        </div>

                    </div>
                    <div class="portlet-body">
                        <form>
                            <div class="parcels-content mt-2">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="dtable">
                                            <table class="table d-table">
                                                <thead>
                                                    <th>#</th>
                                                    <th>صنف فرعي</th>
                                                    <th>الصورة </th>
                                                    <th>الاسم </th>
                                                    <th>السعر</th>
                                                    <th>الحالة </th>
                                                    <th>التاريخ</th>
                                                    <th>الاجراءات</th>

                                                </thead>
 
                                                <tbody>
                                                    <tr v-for="item,index in items.data" :key="item.id">
                                                        <td>{{index+1}}</td>
                                                        <td>{{item.category.title}}</td>
                                                        <td><a :href="item.logo" target="_blank"><img :src="item.logo" width="20"></a></td>
                                                        <td>{{item.name}}</td>
                                                        <td>{{item.price}}</td>
                                                        <td>
                                                            <span v-if="item.status =='active'" class="badge badge-pill badge-success">
                                                                {{item.status}}
                                                            </span> 
                                                            <span v-else class="badge badge-pill badge-danger">
                                                                {{item.status}}
                                                            </span> 
                                                        </td>
                                                        <td>{{item.created_at}}</td>
                                                        
                                                        
                                                        <td>
                                                            <a href="#"
                                                                class="btn red-btn btn-icon"
                                                                @click="deleteProduct(item.id)"
                                                                title="" data-original-title="حذف">
                                                                <i class="icon icon-delete"></i>
                                                            </a>

                                                          

                                                            <span class="d-inline-block"
                                                                 data-original-title="تعديل">
                                                                <a href="#" class="btn green-btn btn-icon"
                                                                    @click="getModalEdit(item)">
                                                                    <i
                                                                        class="icon icon-pencil-edit-button"></i>
                                                                </a>
                                                            </span>

                                                        </td>
                                                    </tr>

                                                    <tr v-if="totalPages == 0">
                                                        <td colspan="6" style="text-align:center">لا يوجد نتائج </td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>


                                            <sliding-pagination v-if="totalPages != 0"
                                              :current="currentPage"
                                              :total="totalPages"
                                              @page-change="pageChangeHandler"
                                            ></sliding-pagination>


                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>






<!-- modal add Product -->
<div class="modal fade main-modal add-product" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-blg" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title d-flex">
                <i class="icon icon-add"></i>
                 {{titleModal}}</h5>
            <button type="button" class="close" @click="closeModal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
             <form  @submit="addEditProduct" enctype="multipart/form-data">
                <div class="row">
                    <div class="alert alert-danger" role="alert" v-if="errors.length">
                        <b style="font-weght">يرجي التاكد من البيانات  :</b>
                        <ul>
                          <li v-for="error in errors">{{ error }}</li>
                        </ul>
                    </div>
                    
                    <div class="form-group col-3"></div>
                    <div class="form-group col-4">
                        <label for="personalPicture" class="col-12 flex-label" style="font-weight: bold;"> 
                          لوجو  المنتج
                        </label>
                        <div class="col-sm-9">
                            <div class="avatar-picture">
                                <div class="image-input image-input-outline"
                                    id="imgUserProfile">
                                    <div id="preview">
                                        <a :href="logo_preview" target="_blank">
                                            <img v-if="logo_preview" :src="logo_preview" width="100" height="100" />
                                            <img v-else :src="logo_preview_add" width="100" />
                                        </a>
                                    </div>

                                    <label class="btn" data-toggle="tooltip"
                                        data-placement="top" >

                                        <i class="icon icon-pencil-edit-button"></i>
                                        <input type="file" name="profile_avatar" v-on:change="onFileChange"
                                            accept=".png, .jpg, .jpeg .pdf">
                                        <input type="button" value="Upload" id="uploadButton" />


                                    </label>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group col-4">
                        <label for="personalPicture" class="col-12 flex-label" style="font-weight: bold;"> 
                            غلاف المنتج
                        </label>
                        <div class="col-sm-9">
                            <div class="avatar-picture">
                                <div class="image-input image-input-outline"
                                    id="imgUserProfile">
                                    <div id="preview">
                                        <a :href="logo_preview" target="_blank">
                                            <img v-if="cover_preview" :src="cover_preview" width="100" height="100" />
                                            <img v-else :src="cover_preview_add" width="100" />
                                        </a>
                                    </div>

                                    <label class="btn" data-toggle="tooltip"
                                        data-placement="top" >

                                        <i class="icon icon-pencil-edit-button"></i>
                                        <input type="file" name="profile_avatar" v-on:change="onFileChange2"
                                            accept=".png, .jpg, .jpeg .pdf">
                                        <input type="button" value="Upload" id="uploadButton" />


                                    </label>

                                </div>
                            </div>
                        </div>
                    </div>

                   
                    
                </div>

                <div class="tab-content mt-4" id="myTabContent">
                    <div class="tab-pane fade show active" id="storeInformation"
                        role="tabpanel" aria-labelledby="storeInformation-tab">
                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex">

                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      التصنيف 

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <multiselect class="" v-model="formData.category" tag-placeholder="اختيار " placeholder="ابحث من هنا .." label="title" track-by="id"  :options="categories" :multiple="false" :taggable="true" :allow-empty="false"></multiselect>

                                    </div>
                                </div>




                                <div class="form-group col-4" v-for="lang,index in languages">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                        الاسم  ({{lang.name}})
                                    </label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control"
                                             v-model="formData['name_' + lang.lang]" value=""
                                            placeholdr="'name'+lang.name">
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex">

                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                         السعر
                                    </label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" @keypress="isNumber($event)"
                                            v-model="formData.price" value=""
                                            placeholder="متوسط السعر">
                                    </div>
                                </div> 



                               <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                         سعر عرض
                                    </label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" @keypress="isNumber($event)"
                                            v-model="formData.offer" value=""
                                            placeholder="سعر العرض">
                                    </div>
                                </div> 

                             
                                <!-- <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      نوع التسليم
                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <select class="form-control" v-model="formData.delivery_status" >
                                            <option value=""> إختر... </option>
                                            <option :value="1">بيك أب</option>
                                            <option :value="2">ديلفري</option>
                                            <option value="3">داخل المطعم</option>
                                           
                                        </select>


                                    </div>
                                </div> -->


                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                      حدد الوسوم المناسبة لك 

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                         <multiselect class="" v-model="formData.delivery_status" tag-placeholder="اختيار " placeholder="ابحث من هنا .." label="name" track-by="id" :options="delivery_status" :multiple="true" :taggable="true" ></multiselect>

                                    </div>
                                </div>




                            </div>
                        </div> 

  



                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex">
                                <div class="form-group col-6" v-for="lang,index in languages">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                       الوصف  ({{lang.name}})

                                    </label>
                                    <div class="col-sm-12 select-tag-wrapper" >
                                        <textarea rows="6" id="messageContent" maxlength="250"
                                           v-model="formData['descriptions_' + lang.lang]" value=""
                                            placeholdr="'descriptions'+lang.name" class="form-control ">     
                                        </textarea>
                                    </div>
                                </div>

                            </div>
                        </div>



                        <div class="row">
                            <div class="col-lg-12 col-12 d-flex">
                                <div class="form-group col-4">
                                    <label for="storeName" class="col-sm-12 flex-label">
                                         ترتيب عرض المنتج
                                    </label>
                                    <div class="col-sm-12">
                                        <input type="number" class="form-control"
                                            v-model="formData.order_number" value=""
                                            placeholder="ترتيب  ظهور المنتج">
                                    </div>
                                </div> 
                            </div>


                               <div class="product-switch flex-label">
                           
                            <label for="activeDisStore">تفعيل</label>

                        </div>


                        <div class="form-group col-6">
                                 <div class="cst-switch">
                                <input type="checkbox" id="activeDisStore" checked="checked" v-model="formData.status">
                            </div>
                        </div>   

                    


                        </div>


                    </div>
                </div>

              
                <div class="btn-container">
                    <a class="btn btn-outline-light"  @click="closeModal">الغاء</a>
                    <button type="submit"
                        class="btn btn-primary" :disabled='value'>حفظ</button>
                </div>
            </form>
        </div>
    </div>
    </div>
</div>
        <!-- end modal -->
   </div>
</template>
 
 

<script>

    import Multiselect from 'vue-multiselect'
    import SlidingPagination from 'vue-sliding-pagination'

       export default {
        components: { Multiselect,SlidingPagination},
       name : 'Product',
       data(){
	       	return {
            value:false,
            titleModal:'',
            currentPage: 0,
            totalPages: 0,
            items:[],
            languages:[],
            errors: [],
            categories: [],
            delivery_status:[],
            ID:'',
            URL:'Product/createItem',
	       	 
            formData:{
              delivery_status:null,
              category:null,
              name_ar:null,
              name_en:null,
              price:null,
              offer:null,
              descriptions_en:null,
              descriptions_ar:null,
              logo:null,
              cover:null,
              order_number:null,
              status:'active',
              delivery_status:[],
	       	 	},

            logo:null,
            cover:null,

            logo_preview:null,
            cover_preview:null,
            logo_preview_add :'./../assets/companies/img/store-logo.jpg',
            cover_preview_add :'./../assets/companies/img/store-logo.jpg',

		    }
       },
       methods:{
        pageChangeHandler(selectedPage) {
            this.currentPage = selectedPage
            this.getProducts()
        },
       
        onFileChange(e){
            this.logo = e.target.files[0];
            this.logo_preview = URL.createObjectURL(this.logo);
        },

        onFileChange2(e){
            this.cover = e.target.files[0];
            this.cover_preview = URL.createObjectURL(this.cover);
        },

       
        isNumber: function(evt) {
          evt = (evt) ? evt : window.event;
          var charCode = (evt.which) ? evt.which : evt.keyCode;
          if ((charCode > 31 && (charCode < 48 || charCode > 57)) && charCode !== 46) {
            evt.preventDefault();
          } else {
            return true;
          }
        },

        getModal(){
            this.resetProduct();
            $('#myModal').modal('show');
            this.titleModal = 'اضافة علامة تجارية'
        },


        getModalEdit(item){
            this.resetProduct();
            $('#myModal').modal('show');
            this.titleModal = 'تعديل علامة تجارية'
            this.ID = item.id
            this.URL = 'Product/editItem'
            this.getProductById() 
            
        },

        closeModal(){
            $('#myModal').modal('hide');
            this.URL = 'Product/createItem'
            this.ID = null
            // this.resetMark();
        },

        resetProduct(){
          this.URL = 'Product/createItem'
          this.formData.offer=''        
          this.formData.name_ar=''
          this.formData.name_en=''
          this.formData.price=''
          this.formData.order_number=''
          this.formData.descriptions_en=''
          this.formData.descriptions_ar=''
          this.formData.delivery_status=[]
          this.formData.logo=''
          this.formData.cover=''
          this.formData.status='active'
          this.logo_preview ='./../assets/companies/img/store-logo.jpg'
          this.cover_preview ='./../assets/companies/img/store-logo.jpg'

        },


       	addEditProduct(e){
           this.value=true
          e.preventDefault();

            const config = {
                    headers: {
                        'content-type': 'multipart/form-data'
                    }
                }
 

            if(!this.formData.category){
                this.value=false
                 swal({
                    text: 'يرجى التاكد من  المدخلات',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                 return false
            }


            let form = new FormData();
            form.append('logo', this.logo);
            form.append('cover', this.cover);
            form.append('name_ar', this.formData.name_ar);
            form.append('name_en', this.formData.name_en);
            form.append('descriptions_ar', this.formData.descriptions_ar);
            form.append('descriptions_en', this.formData.descriptions_en);
            form.append('offer', this.formData.offer);
            form.append('price', this.formData.price);
            form.append('category_id', this.formData.category.id);
            form.append('delivery_status', JSON.stringify(this.formData.delivery_status));
            form.append('order_number', this.formData.order_number);
            form.append('status', this.formData.status);
            if(this.ID != ''){
               form.append('ProductID', this.ID);
            }
             
            // let url= this.URL
            // console.log(form)
       		axios.post(this.URL,form,config).then((response)=>{
                this.value=false
                if(response.data.items){
                   swal({
                    text: "تم حفظ التغييرات بنجاح",
                    icon: "success",
                    timer: 2000,
                    button: false
                    }); 
                    this.closeModal()
                    this.getProducts()           

                }else{
                    swal({
                    text: response.data.message,
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }       			
       			
       		})
       	},


        getProducts(){

            axios.get('Product/getAllItems?page='+ this.currentPage).then(response => {
                if(response.data){
                  let data = response.data.items
                  this.totalPages=Math.ceil(data.total/data.per_page)
                    this.items = data;
                    console.log(data)
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            }); 
        },


        getProductById(){
            axios.get('Product/getById', { params: { ID: this.ID } }).then(response => {
                if(response.data){
                  let data = response.data.items
                  let translations = response.data.items.translations
                   this.formData = data;
                   console.log(this.formData);
                   this.logo_preview = data.logo;
                   this.cover_preview = data.cover;
                   // this.formData.types = response.data.items.types.map(({ id}) => (id));

                    translations.forEach((element) => { 
                          this.formData['name_'+element.locale] = element.name; 
                          this.formData['descriptions_'+element.locale] = element.descriptions ;
                    });

                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });
        },

        deleteProduct(id) {
            swal({
                  title: "Are you sure?",
                  text: "Once deleted, you will not be able to recover this imaginary item!",
                  icon: "warning",
                  buttons: true,
                  dangerMode: true,
                }).then((result) => {
              if (result) {
                axios.delete('Product/deleteItem/'+id)
                    .then((response)=> {
                            if(response.data.code == 200){
                                swal(
                                  'Deleted!',
                                  'Item deleted successfully',
                                  'success'
                                )
                                this.getProducts()           

                            }else{
                                swal({
                                  icon: 'error',
                                  title: 'Oops...',
                                  text: 'Something went wrong!',
                                })

                            }
                           
                    

                    }).catch(() => {
                        swal({
                          icon: 'error',
                          title: 'Oops...',
                          text: 'Something went wrong!',
                        })
                    })
                }

            })
        },
        



       },

       created(){

            this.languages = JSON.parse(localStorage.getItem("languages"))
            // this.$lang.setLocale('ar')
            // alert(this.$lang.getLocale())
            this.getProducts()

             axios.get('SubCategory/getAllItems', { params: { pagination: 0 } }).then(response => {
                if(response.data){
                  let data = response.data.items
                  this.categories = data;
                
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });           
            }); 


            axios.get('Options/getAllItems?type=status_delivered_status').then(response => {
                if(response.data){
                  let data = response.data.items
                  this.delivery_status = data;
                
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });           
            });  

           
             
       },
       mounted(){

       }
    }


   
</script>
<style src="vue-sliding-pagination/dist/style/vue-sliding-pagination.css"></style>
<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>
<style>

.multiselect__option--highlight {
    background: #3ebdb1 !important;
    outline: none;
    color: #fff;}

    .multiselect__tag {
    background: #3ebdb1;}

    .multiselect__tag-icon:after {
    color: ##33a196;
    }




    ol, p, ul {
        line-height: 1.0;
    }


    .c-sliding-pagination__list-element {
        
        padding: 0.5em !important;
        border-radius: 0.6em !important;
        margin: 1px 2px 1px 4px !important;
    }


</style>