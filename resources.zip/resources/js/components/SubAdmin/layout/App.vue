<template>
    <div>
       
    <div class="page-wrapper">

        <div class="overlay"> </div>

        <!-- side bar (aside) -->
       <siderbar-subadmin></siderbar-subadmin>

        <!-- page content -->
        <div class="content-area">

            <!-- Header Conetnt -->
            <header-subadmin></header-subadmin>
            <!-- End Header -->

          

            <!-- Main Content -->
            <main class="content">
                <div class="container-fluid">
                    <help-subadmin></help-subadmin>

                      <router-view></router-view>

                </div>
            </main>
        </div>
    </div>

    </div>
   

 

</template>

<script>
    import axios from 'axios';
    import { mapGetters} from 'vuex'

    import Header from './Header'

    export default {
       components: { Header},
       name : 'App',
        data(){
          return {
           

        }
        
       }, 



 
       created(){
        let token = localStorage.getItem('token')
        axios.get('user').then(response => {
            if(response.data){
              // console.log(response.data.items.name_ar)
              let status = response.data.status
              let user = response.data.items
              localStorage.setItem('token',token)
              localStorage.setItem('user',user)
              localStorage.setItem('status',status)
              this.$store.dispatch('user',user)
              this.$store.dispatch('status',status)

            }else{
                let url = window.location.origin ;
                window.open(url+'/loginApp',"_self")
            }
             }).catch((error)=>{
                this.$store.dispatch('user','')
                this.$store.dispatch('status','')
                let url = window.location.origin ;
                window.open(url+'/loginApp',"_self")
                
             });
       


        axios.get('getLanguages').then(response => {
            if(response.data){
                  let langs = response.data.items
                  this.languages = langs
                  this.$store.dispatch('currLanguage',this.$lang.getLocale())
                  this.$store.dispatch('setLanguages',langs)
                  localStorage.setItem('languages',JSON.stringify(langs))
                  this.currentLanguage = this.$lang.getLocale()
                  // console.log(this.$store.state.user.Languages)
            }
            }).catch((error)=>{
            // this.$store.dispatch('user','')
            // this.$store.dispatch('status','')
               
                
        });




        



       },



       computed:{
        // ...mapGetters(['user']),
        // ...mapGetters(['status']),
       }
    }
</script>
