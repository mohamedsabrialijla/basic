<template>
    <div>
    
   	 <header>
    <!-- Toggle Menue -->
    <div class="toggle-sidebar">
        <span></span>
        <span></span>
        <span></span>
    </div>


    <!-- header right -->
    <div class="header-right">

        <!-- header Search -->
        <div class="header-search" id="headerSearch">
            <form class="header-search-form">
                <span class="times-icon" id="closeSearch">
                </span>
                <div class="header-search-container">
                    <input type="text" class="form-control header-search-input" placeholder="ابحث عما تريد">
                    <button type="submit" class="header-search-btn">
                        <span class="icon-search"></span>
                    </button>
                </div>

                <div class="header-search-select">
                    <select class="selectpicker">
                        <option>الطلبات</option>
                        <option>المنتجات</option>
                        <option>العملاء</option>
                    </select>
                </div>

            </form>
        </div>
    </div>

    <!-- header left -->
    <div class="header-left">

        <div class="search-toggle">
            <button class="btn btn-primary" id="searchToggle">
                <i class="icon icon-search"></i>
            </button>
        </div>
        
        <div class="header-left-dropdown filter-option">
            <treeselect v-model="selectBranch" placeholder="يجب اختيار فرع معين ..."  :multiple="false" :options="options" @select="selectedBranch" :disable-branch-nodes="true" :show-count="true" search-nested :value="selectBranch"/>

       



        </div>


        <div class="header-left-dropdown account-wrapper">
            <div class="btn-group" role="group">
                <button id="accountList" type="button" 
                    class="btn btn-secondary dropdown-toggle header-dropdown-btn account-list-btn"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <div class="account-list-img'">
                        <img :src="'./img/user-img.jpg'" alt="">
                    </div>
                    <span class="account-list-name" >
                        {{getLocale}}
                    </span>
                </button>
                <div class="dropdown-menu account-list-dropdown" aria-labelledby="accountList">
                    
                    <a class="dropdown-item" href="#" v-for="lang in languages" >
                        <i class="icon icon-information"></i>
                        <span>{{lang.lang}}</span>
                    </a>
                    
                </div>
            </div>
        </div>

       


        <!-- notification dropdown -->
        <div class="header-left-dropdown notification-wrapper">
            <div class="btn-group" role="group">
                <button id="notification" type="button"
                    class="btn btn-secondary dropdown-toggle header-dropdown-btn notification-btn"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="icon-Notification-Icon"></i>
                    <span></span>
                </button>
                <div class="dropdown-menu dropdown-notification" aria-labelledby="notification">
                    <ul class="list-unstyled mb-0">
                        <li class="dropdown-notification-head">الاشعارات</li>
                        <ul class="list-unstyled dropdown-notification-list">
                            <li>
                                <a href="" class="dropdown-item">
                                    <div class="notification-item-img'">
                                        <img :src="'./img/notification-truck.svg'" alt="">
                                    </div>
                                    <div class="dropdown-item-content">
                                        <p>نص افتراضي للاشعار داخل الموقع نص افتراضي للاشعار نص افتراضي
                                            للاشعار داخل الموقع نص افتراضي للاشعار </p>
                                        <span class="time">4 min ago</span>
                                    </div>

                                </a>
                            </li>
                            <li>
                                <a href="" class="dropdown-item">
                                    <div class="notification-item-img'">
                                        <img :src="'./img/notification-box.svg'" alt="">
                                    </div>
                                    <div class="dropdown-item-content">
                                        <p>نص افتراضي للاشعار داخل الموقع نص افتراضي للاشعار </p>
                                        <span class="time">4 min ago</span>
                                    </div>

                                </a>
                            </li>
                            <li>
                                <a href="" class="dropdown-item">
                                    <div class="notification-item-img'">
                                        <img :src="'./img/notification-mony.svg'" alt="">
                                    </div>
                                    <div class="dropdown-item-content">
                                        <p>نص افتراضي للاشعار داخل الموقع نص افتراضي للاشعار </p>
                                        <span class="time">4 min ago</span>
                                    </div>

                                </a>
                            </li>

                            <li>
                                <a href="" class="dropdown-item">
                                    <div class="notification-item-img'">
                                        <img :src="'./img/notification-truck.svg'" alt="">
                                    </div>
                                    <div class="dropdown-item-content">
                                        <p>نص افتراضي للاشعار داخل الموقع نص افتراضي للاشعار نص افتراضي
                                            للاشعار داخل الموقع نص افتراضي للاشعار </p>
                                        <span class="time">4 min ago</span>
                                    </div>

                                </a>
                            </li>
                        </ul>

                        <li class="dropdown-notification-footer">
                            <a href="">تعليم الكل كمقروء</a>
                            <a href="notifications.html">عرض كل الاشعارات</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>


        <!-- account List dropdown -->
        <div class="header-left-dropdown account-wrapper">
            <div class="btn-group" role="group">
                <button id="accountList" type="button"
                    class="btn btn-secondary dropdown-toggle header-dropdown-btn account-list-btn"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <div class="account-list-img'">
                        <img :src="'./img/user-img.jpg'" alt="">
                    </div>
                    <span class="account-list-name">
                        {{getName}}
                    </span>
                </button>
                <div class="dropdown-menu account-list-dropdown" aria-labelledby="accountList">
                    <a class="dropdown-item" href="profile-account.html">
                        <i class="icon icon-information"></i>
                        <span>الحساب الشخصي</span>
                    </a>
                    <a class="dropdown-item" href="packages-subscriptions.html">
                        <i class="icon icon-pack"></i>
                        <span>الاشتراكات والباقات</span>
                    </a>
                    <a class="dropdown-item" href="#" @click="logout">
                        <i class="icon icon-logout"></i>
                        <span>تسجيل الخروج</span>
                    </a>
                </div>


            </div>
        </div>




        <!-- icon show lang and currancy -->
        <div class="lang-currency-toggle" id="langCurrencyToggle">
            <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
        </div>
    </div>
</header> 



<div class="mobile-header-botoom">
    
    <div class="header-left-dropdown">
        <div class="btn-group" role="group">
            <button id="langBtn" type="button" class="btn btn-secondary dropdown-toggle header-dropdown-btn"
                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 {{currentLanguage}}
            </button>
            <div class="dropdown-menu" aria-labelledby="langBtn" v-for="lang in languages" @click="changeLanguage">
               <a class="dropdown-item" href="#">{{lang.name}}</a>
            </div>
        </div>
    </div>

</div>



    </div>
</template>

<script>

  import Treeselect from '@riophae/vue-treeselect'
  import '@riophae/vue-treeselect/dist/vue-treeselect.css'


    export default {
       components: { Treeselect },
       name : 'Header',
       props:['Item'],
       data(){
          return {
            languages : [],
            currentLanguage : null,
            status : false,
            user : {},

            selectBranch: null,
            options: [],


        }
        
       }, 
 
       created(){
        let token = localStorage.getItem('token')
        this.languages = JSON.parse(localStorage.getItem("languages"))

        // let branchID = localStorage.getItem('branchID')

        this.getBrands()
        this.defulteSession()

        // this.selectBranch = branchID
 
       },

       methods:{
        logout(){

            axios.post('logOut',localStorage.getItem('token')).then((response)=>{
            if(response.data){
              localStorage.setItem('token','')
              localStorage.setItem('status','')
              localStorage.setItem('branch','')
              localStorage.setItem('branchItemSession','')
              localStorage.setItem('branchID','')
              localStorage.removeItem('token')
              localStorage.removeItem('status')
              localStorage.removeItem('branch')
              localStorage.removeItem('branchItemSession')
              localStorage.removeItem('branchID')
               
               this.$store.dispatch('user','')
               this.$store.dispatch('status','')
               this.$store.dispatch('branch','')
               this.$store.dispatch('branchItemSession','')
               // this.$router.push('/loginApp')
              let url = window.location.origin ;
              window.open(url+'/',"_self")

            } 
                
            })
        },

        changeLanguage(){

        }, 

        getBrands(){             
            axios.get('Mark/getAllItems?pagination=0&statusMark=1').then(response => {
                if(response.data){
                  let data = response.data.items
                    this.options = data;
                    // this.selectBranch = data[0].children[0].id

                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });
        },

        selectedBranch(value){
            var form = new FormData();
            form.append('branch_id', value.id);
            axios.post('Branch/changeSession',form).then(response => {
                if(response){
                  let data = response.data.items

                  this.selectBranch = value.id 
                  location.reload()
                     
                }else{
                     swal({
                    text: 'Error happens',
                    icon: 'success',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'تم تغيير الفرع بنجاح',
                    icon: 'success',
                    timer: false,
                    button: true
                    });         
            });

        }, 
 
        defulteSession(){ 
            axios.get('Branch/getDefaulteSession').then(response => {
                if(response.data){
                    if( response.data.items && response.data.items != ''){
                         let data = response.data.items
                        this.selectBranch = data.id
                        localStorage.setItem('branch',this.selectBranch)
                        localStorage.setItem('branchID',this.selectBranch)
                        this.$store.dispatch('branch',this.selectBranch)
 

                    }else{
                         swal({
                        text: 'يجب عليك اضافة علامه تجارية واحد ع الاقل , ومن ثم اضافة فرع واحد لتتمكن من بدء إستخدام النظام',
                        icon: 'error',
                        timer: false,
                        button: true
                        });
                    }
  
                }else{
                     swal({
                    text: 'يجب عليك اضافة علامه تجارية واحد ع الاقل , ومن ثم اضافة فرع واحد لتتمكن من بدء إستخدام النظام',
                    icon: 'error',
                    timer: false,
                    button: true
                    });
                }
            }).catch((error)=>{

                    swal({
                    text: 'Error happens',
                    icon: 'error',
                    timer: false,
                    button: true
                    });         
            });
        },


       },
        computed: {
            getName() {
            return this.$store.state.user.userInfo.name;
            },


            getLocale(){
                return this.$store.state.user.currentLanguage;
            }
    },

       
  }
   
    
</script>

<style>
.vue-treeselect__control{
    border:none !important
}

.vue-treeselect--single .vue-treeselect__input {
    width: 41%;
    }

    .vue-treeselect__x-container{
        display:none
    }


</style>