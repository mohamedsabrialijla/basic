<template>
    <div>
        <div class="sidebar">
            <aside>
                <span class="times-icon" id="toggleSidebar">
                </span> 
                <div class="logo-area">
                    <router-link class="" to="/subadmin/home">
                         <div class="logo-area__wrapper">
                            <div class="store-logo">
                                <img v-if="companyImage" :src="companyImage" alt="store logo" id="scream">
                                <img v-else :src="companyImageA" alt="store logo" id="scream">
                            </div>
                            <p style="margin-right:50px;">  {{getName}} </p>
                        </div>
                    </router-link>
                </div>
                <ul class="sidebar-menu list-unstyled">
                    <li class="active">
                        <router-link class="" to="/subadmin/home">
                            <div class="sidebar-icon">
                                <i class="icon icon-dashboard"></i>
                            </div>
                            <span>نظرة عامة</span>
                        </router-link>
                    </li>

                    <li>
                        <a href="javascript:;" class="toggle-submenu">

                            <div class="sidebar-icon">
                                <i class="icon icon-shop"></i>
                            </div>
                            <span>إعدادت الشركة</span>
                            <i class="arrow-right arrow"></i>
                        </a>
                        <ul class="child-links list-unstyled">
                            <li>
                                <router-link class="" to="/subadmin/profile"> بيانات الشركة </router-link>
                            </li>

                            <li>
                                <router-link class="" to="/subadmin/editPassword"> كلمة المرور </router-link>
                            </li>
                            

                            
                            <li><router-link class="" to="/subadmin/brands">العلامات التجارية</router-link></li>

                             <li><router-link class="" to="/subadmin/branch">الفروع</router-link></li>

                        </ul>
                    </li>

                    <li>
                        <a href="javascript:;" class="toggle-submenu">

                            <div class="sidebar-icon">
                                <i class="icon icon-shop"></i>
                            </div>
                            <span>اعدادات المطعم</span>
                            <i class="arrow-right arrow"></i>
                        </a>
                        <ul class="child-links list-unstyled" v-if="default_session != 0">
                            <li>
                                <router-link class="" to="/subadmin/floors"> سيكشنات المطعم </router-link>
                            </li>

                            <li>
                                <router-link class="" to="/subadmin/mergeTable"> دمج الطاولات </router-link>
                            </li>
                           

                        </ul>
                    </li>

 
                    


                   



                    <li >
                        <a href="javascript:;" class="toggle-submenu">

                            <div class="sidebar-icon">
                                <i class="icon icon-shop"></i>
                            </div>
                            <span>الطلبات  </span>
                            <i class="arrow-right arrow"></i>
                        </a>
                        <ul class="child-links list-unstyled" v-if="default_session != 0" >

                             <li>
                                <router-link class="" to="/subadmin/Booking"> 
                                    
                                    <span> الحجوزات</span>
                                </router-link>
                            </li>


                            <li>
                                <router-link class="" to="/subadmin/BookingWaiting"> 
                                    
                                    <span> قائمة انتظار</span>
                                </router-link>
                            </li>



                             <li >
                        <router-link class="" to="/subadmin/Order"> 
                            
                            <span> نقاط البيع</span>
                        </router-link>
                    </li>



                           

                        </ul>
                    </li>





                    <li >
                        <a href="javascript:;" class="toggle-submenu">

                            <div class="sidebar-icon">
                                <i class="icon icon-shop"></i>
                            </div>
                            <span>المنتجات </span>
                            <i class="arrow-right arrow"></i>
                        </a>
                        <ul class="child-links list-unstyled" v-if="default_session != 0" >

                             <li>
                                <router-link class="" to="/subadmin/Category">التصنيفات الرئيسية </router-link>
                            </li>


                            <li>
                                <router-link class="" to="/subadmin/SubCategory">التصنيفات  الفرعية </router-link>
                            </li>


                            <li>
                                <router-link class="" to="/subadmin/Product">المنتجات </router-link>
                            </li>

                           

                        </ul>
                    </li>


               

                

                   <!--  <li>
                        <a href="javascript:;" class="toggle-submenu">

                            <div class="sidebar-icon">
                                <i class="icon icon-shop"></i>
                            </div>
                            <span>المتسوق الشخصي</span>
                            <i class="arrow-right arrow"></i>
                        </a>
                        <ul class="child-links list-unstyled">
                            <li><a href="shopper.html">المنتجات</a></li>
                            <li><a href="shopper-order.html">طلباتي</a></li>
                            <li><a href="shopper-purchases-reports.html">تقارير المشتريات</a></li>
                        </ul>
                    </li>

                    <li>
                        <a href="shipments.html">
                            <div class="sidebar-icon">
                                <i class="icon icon-shipments"></i>

                            </div>
                            <span>الشحنات</span>
                        </a>
                    </li>

                    <li>
                        <a href="parcel.html">
                            <div class="sidebar-icon">
                                <i class="icon icon-packages"></i>
                            </div>
                            <span>الطرود</span>
                        </a>
                    </li>

                    <li>
                        <a href="sellerorder.html">

                            <div class="sidebar-icon">
                                <i class="icon icon-orders"></i>

                            </div>
                            <span>الطلبات</span>
                        </a>
                    </li>
                    <li>
                        <a href="warehouses.html">
                            <div class="sidebar-icon">
                                <i class="icon icon-boxes"></i>
                            </div>
                            <span>المستودعات</span>
                        </a>
                    </li>

                    <li>
                        <a href="billing.html">
                            <div class="sidebar-icon">
                                <i class="icon icon-money"></i>

                            </div>
                            <span>المالية</span>
                        </a>
                    </li>

                    <li>
                        <a href="javascript:;" class="toggle-submenu">

                            <div class="sidebar-icon">
                                <i class="icon icon-shop"></i>
                            </div>
                            <span>إعدادت المتجر</span>
                            <i class="arrow-right arrow"></i>
                        </a>
                        <ul class="child-links list-unstyled">
                            <li><a href="store-settings.html">معلومات متجري</a></li>
                            <li><a href="store-design.html">تصميم متجري</a></li>
                            <li><a href="customize-store.html">تخصيص متجري</a></li>
                            <li><a href="store-articles.html">مقالات متجري</a></li>
                        </ul>
                    </li>

                    <li>
                        <a href="employees.html">
                            <div class="sidebar-icon">
                                <i class="icon icon-employee"></i>
                            </div>
                            <span>الموظفين</span>
                        </a>
                    </li>

                    <li>
                        <a href="customer.html">
                            <div class="sidebar-icon">
                                <i class="icon icon-clients"></i>
                            </div>
                            <span>العملاء</span>
                        </a>
                    </li>

                    <li>
                        <a href="reports.html">
                            <div class="sidebar-icon">
                                <i class="icon icon-File"></i>
                            </div>
                            <span>التقارير</span>
                        </a>
                    </li>

                    <li>
                        <a href="advanced-services.html">
                            <div class="sidebar-icon">
                                <i class="icon icon-star"></i>
                            </div>
                            <span>خدمات متقدمة</span>
                        </a>
                    </li>

                    <li>
                        <a href="javascript:;" class="toggle-submenu">
                            <div class="sidebar-icon">
                                <i class="icon icon-marketing"></i>
                            </div>
                            <span>التسويق الإلكتروني</span>
                            <i class="arrow-right arrow"></i>
                        </a>
                        <ul class="child-links list-unstyled">
                            <li><a href="emarketing-newsletters.html">النشرات البريدية</a></li>
                            <li><a href="emarketing-sms-message.html">رسائل SMS</a></li>
                            <li><a href="emarketing-marketing-campaigns.html">الحملات التسويقية</a></li>
                            <li><a href="emarketing-coupons.html">الكوبونات</a></li>
                            <li><a href="emarketing-offers.html">العروض</a></li>
                            <li><a href="emarketing-media.html">نافذة اعلامية</a></li>
                            <li><a href="emarketing-affiliate-marketing.html">التسويق بالعمولة</a></li>
                        </ul>
                    </li>

                    <li>
                        <a href="tickets.html">
                            <div class="sidebar-icon">
                                <i class="icon icon-membership"></i>
                            </div>
                            <span>التذاكر</span>
                        </a>
                    </li>

                    <li>
                        <a href="javascript:;" class="toggle-submenu">
                            <div class="sidebar-icon">
                                <i class="icon icon-rating"></i>
                            </div>
                            <span>الاستفسارات والتقييمات</span>
                            <i class="arrow-right arrow"></i>
                        </a>
                        <ul class="child-links list-unstyled">
                            <li><a href="seller-contact-list.html">استفسارات العملاء</a></li>
                            <li><a href="seller-review.html">التقييمات</a></li>
                        </ul>
                    </li> -->
                </ul>
            </aside>
        </div>
    </div>
</template>

<script>
    export default {
       name : 'Siderbar',
       data(){
          return {
            status : false,
            default_session : 0,
            companyName:null,
          }
        
       },


       created(){


        // this.defulteSession()
        // console.log(this.$store.state.user)
        // this.branchDefault = localStorage.getItem('branch')
        // alert(this.branchDefault)
 
        // this.branch_id = 1

       },



       methods:{


        


       },

       ready() {

        },

       mounted() {
                axios.get('Branch/getAllItems?pagination=0').then(response => {
                    if(response.data){
                      let data = response.data.items
                      this.default_session = 0 
                      data.forEach((item) => {
                          if(item.session==1){
                            this.default_session = item.id 
                           }
                        });


                    }else{
                         swal({
                        text: 'Error happens23',
                        icon: 'error',
                        timer: false,
                        button: true
                        });
                    }
                }).catch((error)=>{

                        swal({
                        text: 'Error happens24',
                        icon: 'error',
                        timer: false,
                        button: true
                        });         
                });


        },






         computed: {
            getName() {
            return this.$store.state.user.userInfo.name_ar;
            },

            companyImage(){
                return this.$store.state.user.userInfo.logo_file;
            },

            companyImageA(){
                return this.$store.state.user.userInfo.national_file;
            }

         

          
    },

      

 

       

       
  }
   
    
</script>
