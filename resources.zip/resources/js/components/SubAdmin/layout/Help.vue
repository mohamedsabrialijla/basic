<template>
    <div>
 		<div class="help-row">
                        <a href="" class="btn assist-btn" data-toggle="modal" data-target=".assist-modal">
                            <i class="icon icon-question icon-text"></i>
                            <span>مساعدة</span>
                        </a>
                    </div>






                     <div class="modal fade main-modal assist-modal" role="dialog" aria-labelledby="assist" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">مركز المساعدة</h5>

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="assist-wrapper">
                        <div class="assist-wrapper-form">
                            <form>
                                <div class="assist-form-group">
                                    <button class="btn btn-primary" type="submit">
                                        <span class="icon icon-search"></span>
                                    </button>
                                    <input type="text" class="" placeholder="هل تبحث عن موضوع مخصص؟">
                                </div>

                            </form>
                        </div>
                        <div class="assist-wrapper-info">
                            <div class="assist-wrapper-info-head">
                                <i class="fa fa-question-circle"></i>
                                <h5>الأسئلة الأكثر شيوعاً</h5>
                            </div>

                            <div class="assist-wrapper-info-inner">
                                <a href="help-center-article.html" class="assist-question">
                                    <span> كيف يمكنني إيجاد قائمة المبيعات؟</span>
                                    <i class="fa fa-angle-left"></i>
                                </a>
                                <a href="help-center-article.html" class="assist-question">
                                    <span> كيف يمكنني إيجاد قائمة المبيعات؟</span>
                                    <i class="fa fa-angle-left"></i>
                                </a>
                                <a href="help-center-article.html" class="assist-question">
                                    <span> كيف يمكنني إيجاد قائمة المبيعات؟</span>
                                    <i class="fa fa-angle-left"></i>
                                </a>
                                <a href="help-center-article.html" class="assist-question">
                                    <span> كيف يمكنني إيجاد قائمة المبيعات؟</span>
                                    <i class="fa fa-angle-left"></i>
                                </a>
                                <a href="help-center-article.html" class="assist-question">
                                    <span> كيف يمكنني إيجاد قائمة المبيعات؟</span>
                                    <i class="fa fa-angle-left"></i>
                                </a>
                                <a href="help-center-article.html" class="assist-question">
                                    <span> كيف يمكنني إيجاد قائمة المبيعات؟</span>
                                    <i class="fa fa-angle-left"></i>
                                </a>
                                <a href="help-center-article.html" class="assist-question">
                                    <span> كيف يمكنني إيجاد قائمة المبيعات؟</span>
                                    <i class="fa fa-angle-left"></i>
                                </a>
                                <a href="help-center-article.html" class="assist-question">
                                    <span> كيف يمكنني إيجاد قائمة المبيعات؟</span>
                                    <i class="fa fa-angle-left"></i>
                                </a>
                            </div>

                            <div class="assist-wrapper-info-more">
                                <a href="help-center.html" class="btn btn-outline-primary">عرض المزيد</a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</template>

<script>
    export default {
       name : 'Help',
       data(){
          return {
            success : 0,
          }
        
       },

       methods:{
    
       }

       
  }
   
    
</script>
