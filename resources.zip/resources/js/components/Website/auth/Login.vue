<template>
  <div>
    <h1>Login</h1>
    <form @submit.prevent="login">
      <input v-model="formData.email" type="email" placeholder="Email">
      <input v-model="formData.password" type="password" placeholder="Password">
      <button type="submit">Login</button>
    </form>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      errors: [],
      formData:{
        email:null,
        password:null,
      },
    };
  },
  methods: {

    async login() {
      try {
        const response = await axios.post('login',this.formData);
        localStorage.setItem('authToken',response.data.items.token);

            this.$router.push('/'+ this.$route.params.locale +'/dashboard');  // تأكد من المسار الصحيح
      } catch (error) {
        alert('Login failed');
      }
    }
  }
};
</script>
