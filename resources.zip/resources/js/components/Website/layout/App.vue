<template>
    <div id="app">
        <header-website></header-website>
        <router-view></router-view>
        <footer-website></footer-website>
    </div>
</template>

<script>
import HeaderWebsite from './Header.vue';
import FooterWebsite from './Footer.vue';

export default {
    components: {
        HeaderWebsite,
        FooterWebsite,
    },
};
</script>

