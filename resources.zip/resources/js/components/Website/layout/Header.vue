<template>
  <div>
    <p>Header here</p>
    <router-link :to="`/${locale}/login`">
      <div class="sidebar-icon">
        <i class="icon icon-dashboard"></i>
      </div>
      <span>تسجيل الدخول</span>
    </router-link>
  </div>
</template>

<script>
export default {
  name: 'Header',
  data() {
    return {
      success: 0,
      currentLocale: 'en' // القيمة الافتراضية إذا لم تجد لغة محددة
    }
  },
  created() {
    
  },
  methods: {
    
  },
  computed: {
    locale() {
      return this.$route.params.locale; // أخذ اللغة مباشرة من الـ route
    }
  }
}
</script>
