<template>
    <div>


      <p>Footer here </p>


  
    </div>
</template>

<script>
    export default {
       name : 'Home'
    }
</script>
