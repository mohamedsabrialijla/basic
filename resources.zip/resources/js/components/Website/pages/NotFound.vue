<template>
    <div>
        <p>NotFound</p>
    </div>
</template>

<script>
    export default {
       name : 'NotFound'
    }
</script>
