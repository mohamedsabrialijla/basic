<template>
    <div>
     
      <h1>{{ message }}</h1>
    </div>

</template>

<script>
    export default {
        name : 'Home',

        data() {
            return {
              message: this.$route.params.locale === 'ar' ? 'مرحباً' : 'Welcome'
            }
          },



        created(){

           
       },

       methods:{

        
       }

    }

</script>
