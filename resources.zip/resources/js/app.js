import './bootstrap';
import './axios';

import { createApp } from 'vue';
import Router from './routes.js'; 
import { createStore } from 'vuex';
import store from './store.js'; 


// import user from './modules/user';

// const store = createStore({
//     modules: {
//         user,
//     }
// });

import App from './components/Website/layout/App.vue';
import HeaderWebsite from './components/Website/layout/Header.vue';
import FooterWebsite from './components/Website/layout/Footer.vue';

import AppPanel from './components/SubAdmin/layout/App.vue';
import HeaderPanel from './components/SubAdmin/layout/Header.vue';
import FooterPanel from './components/SubAdmin/layout/Footer.vue';
// import Slider from './components/Website/layout/Slider.vue';

const app = createApp(App);
 
app.use(Router); 
app.use(store); 

// تسجيل المكونات (Components)
app.component('header-website', HeaderWebsite);
app.component('footer-website', FooterWebsite);
// app.component('slider', Slider);

app.component('header-panel', HeaderPanel);
app.component('footer-panel', FooterPanel);

app.mount('#app');


