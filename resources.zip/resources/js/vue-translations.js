module.exports = {
"ar.auth":
{
	"failed":"dgwergwerg.",
	"password":"The provided password is incorrect.",
	"throttle":"Too many login attempts. Please try again in :seconds seconds.",
	"rr":"rr many login attempts. Please try again in :seconds seconds."
},


"en.auth":
{
"failed":"These credentials do not match our records.",
"password":"The provided password is incorrect.",
"throttle":"Too many login attempts. Please try again in :seconds seconds.",
"rr":"Too many login attempts. Please try again in :seconds seconds."
},



};