import { createRouter, createWebHistory } from 'vue-router';



import Landing from './components/Website/pages/Landing.vue';
import Login from './components/Website/auth/Login.vue';
import Dashboard from './components/SubAdmin/pages/Dashboard.vue';

const routes = [
    { path: '/:locale/', component: Landing },
    { path: '/:locale/login', component: Login },
    { path: '/:locale/dashboard', component: Dashboard, meta: { requiresAuth: true } },
];

const router = createRouter({
    history: createWebHistory(),
    routes,
});

// Middleware للتحقق من اللغة قبل توجيه كل مسار
router.beforeEach((to, from, next) => {
    const locale = to.params.locale; // الحصول على اللغة من الـ URL

    // التحقق من أن اللغة صحيحة (ar أو en)
    if (!['en', 'ar'].includes(locale)) {
        return next('/en'); // إذا كانت اللغة غير موجودة، إعادة التوجيه للغة الافتراضية
    }

    // التحقق من المصادقة إذا كانت مطلوبة
    const isAuthenticated = localStorage.getItem('authToken');
    if (to.meta.requiresAuth && !isAuthenticated) {
        return next(`/${locale}/login`);
    }

    next();
});

export default router;
